using System.Windows;
using System.Windows.Controls;
using ApiTester.ViewModels;
using ApiTester.Models;

namespace ApiTester
{
    public partial class MainWindow : Window
    {
        private MainViewModel _viewModel;

        public MainWindow()
        {
            InitializeComponent();
            _viewModel = new MainViewModel();
            DataContext = _viewModel;
        }

        private void ImportCurl_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new ImportCurlDialog();
            if (dialog.ShowDialog() == true)
            {
                _viewModel.CurlImportText = dialog.CurlText;
                _viewModel.ImportCurlCommand.Execute(null);
            }
        }

        private void Environment_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var comboBox = sender as ComboBox;
            if (comboBox?.SelectedValue is string environmentId)
            {
                _viewModel.SelectEnvironment(environmentId);
            }
        }

        private void History_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var listBox = sender as ListBox;
            if (listBox?.SelectedItem is ApiRequest request)
            {
                _viewModel.LoadRequestFromHistory(request);
            }
        }
    }
}
