using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using ApiTester.Models;
using ApiTester.Services;

namespace ApiTester.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly HttpService _httpService;
        private readonly CurlParser _curlParser;
        private readonly EnvironmentService _environmentService;
        private readonly StorageService _storageService;

        private ApiRequest _currentRequest;
        private ApiResponse? _currentResponse;
        private string _selectedMethod = "GET";
        private string _url = string.Empty;
        private string _requestBody = string.Empty;
        private string _responseBody = string.Empty;
        private string _headersText = string.Empty;
        private string _curlImportText = string.Empty;
        private bool _isLoading = false;
        private string _statusText = "Ready";
        private RequestCollection? _selectedCollection;

        public MainViewModel()
        {
            _httpService = new HttpService();
            _curlParser = new CurlParser();
            _environmentService = new EnvironmentService();
            _storageService = new StorageService();

            _currentRequest = new ApiRequest();

            // Initialize collections
            Collections = new ObservableCollection<RequestCollection>();
            Environments = new ObservableCollection<Models.Environment>();
            RequestHistory = new ObservableCollection<ApiRequest>();

            // Load saved data
            LoadCollections();
            LoadEnvironments();

            // Commands
            SendRequestCommand = new RelayCommand(async _ => await SendRequest());
            ImportCurlCommand = new RelayCommand(_ => ImportCurl());
            SaveRequestCommand = new RelayCommand(_ => SaveRequest());
            NewCollectionCommand = new RelayCommand(_ => CreateNewCollection());
            NewEnvironmentCommand = new RelayCommand(_ => CreateNewEnvironment());
            ClearResponseCommand = new RelayCommand(_ => ClearResponse());
        }

        // Properties
        public string Url
        {
            get => _url;
            set => SetProperty(ref _url, value);
        }

        public string SelectedMethod
        {
            get => _selectedMethod;
            set => SetProperty(ref _selectedMethod, value);
        }

        public string RequestBody
        {
            get => _requestBody;
            set => SetProperty(ref _requestBody, value);
        }

        public string ResponseBody
        {
            get => _responseBody;
            set => SetProperty(ref _responseBody, value);
        }

        public string HeadersText
        {
            get => _headersText;
            set => SetProperty(ref _headersText, value);
        }

        public string CurlImportText
        {
            get => _curlImportText;
            set => SetProperty(ref _curlImportText, value);
        }

        public bool IsLoading
        {
            get => _isLoading;
            set => SetProperty(ref _isLoading, value);
        }

        public string StatusText
        {
            get => _statusText;
            set => SetProperty(ref _statusText, value);
        }

        public ObservableCollection<RequestCollection> Collections { get; }
        public ObservableCollection<Models.Environment> Environments { get; }
        public ObservableCollection<ApiRequest> RequestHistory { get; }

        public List<string> AvailableMethods { get; } = new List<string>
        {
            "GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"
        };

        // Commands
        public ICommand SendRequestCommand { get; }
        public ICommand ImportCurlCommand { get; }
        public ICommand SaveRequestCommand { get; }
        public ICommand NewCollectionCommand { get; }
        public ICommand NewEnvironmentCommand { get; }
        public ICommand ClearResponseCommand { get; }

        // Methods
        private async System.Threading.Tasks.Task SendRequest()
        {
            try
            {
                IsLoading = true;
                StatusText = "Sending request...";

                // Build request from UI
                _currentRequest.Url = Url;
                _currentRequest.Method = Enum.Parse<HttpMethod>(SelectedMethod);
                _currentRequest.Body = RequestBody;

                // Parse headers
                ParseHeaders();

                // Replace environment variables
                var requestToSend = _environmentService.ReplaceVariablesInRequest(_currentRequest);

                // Send request
                _currentResponse = await _httpService.SendRequestAsync(requestToSend);

                // Display response
                ResponseBody = FormatResponseBody(_currentResponse.Body);
                StatusText = $"Status: {_currentResponse.StatusCode} {_currentResponse.StatusDescription} | Time: {_currentResponse.ResponseTime}ms | Size: {_currentResponse.ContentLength} bytes";

                // Add to history
                RequestHistory.Insert(0, new ApiRequest
                {
                    Name = $"{_currentRequest.Method} {GetDomainFromUrl(_currentRequest.Url)}",
                    Url = _currentRequest.Url,
                    Method = _currentRequest.Method,
                    Body = _currentRequest.Body,
                    Headers = new Dictionary<string, string>(_currentRequest.Headers)
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Request Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                StatusText = $"Error: {ex.Message}";
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void ImportCurl()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(CurlImportText))
                {
                    MessageBox.Show("Please enter a cURL command", "Import cURL", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var request = _curlParser.ParseCurl(CurlImportText);
                
                // Update UI
                Url = request.Url;
                SelectedMethod = request.Method.ToString();
                RequestBody = request.Body;
                
                // Build headers text
                HeadersText = string.Join("\n", request.Headers.Select(h => $"{h.Key}: {h.Value}"));

                _currentRequest = request;
                CurlImportText = string.Empty;

                MessageBox.Show("cURL imported successfully!", "Import cURL", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to import cURL: {ex.Message}", "Import Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveRequest()
        {
            if (_selectedCollection == null)
            {
                MessageBox.Show("Please select a collection first", "Save Request", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _currentRequest.Url = Url;
            _currentRequest.Method = Enum.Parse<HttpMethod>(SelectedMethod);
            _currentRequest.Body = RequestBody;
            ParseHeaders();

            _selectedCollection.Requests.Add(_currentRequest);
            _storageService.SaveCollection(_selectedCollection);

            MessageBox.Show("Request saved successfully!", "Save Request", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void CreateNewCollection()
        {
            var collection = new RequestCollection
            {
                Name = $"Collection {Collections.Count + 1}"
            };

            Collections.Add(collection);
            _storageService.SaveCollection(collection);
            _selectedCollection = collection;

            MessageBox.Show($"Collection '{collection.Name}' created!", "New Collection", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void CreateNewEnvironment()
        {
            var env = new Models.Environment
            {
                Name = $"Environment {Environments.Count + 1}"
            };

            // Add some example variables
            env.Variables["base_url"] = "https://api.example.com";
            env.Variables["api_key"] = "your-api-key-here";

            Environments.Add(env);
            _environmentService.AddEnvironment(env);
            _storageService.SaveEnvironment(env);

            MessageBox.Show($"Environment '{env.Name}' created!\n\nExample variables:\n{{{{base_url}}}} = {env.Variables["base_url"]}\n{{{{api_key}}}} = {env.Variables["api_key"]}", 
                "New Environment", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ClearResponse()
        {
            ResponseBody = string.Empty;
            StatusText = "Ready";
            _currentResponse = null;
        }

        private void ParseHeaders()
        {
            _currentRequest.Headers.Clear();
            
            if (string.IsNullOrWhiteSpace(HeadersText))
                return;

            var lines = HeadersText.Split('\n');
            foreach (var line in lines)
            {
                var parts = line.Split(new[] { ':' }, 2);
                if (parts.Length == 2)
                {
                    var key = parts[0].Trim();
                    var value = parts[1].Trim();
                    if (!string.IsNullOrEmpty(key))
                    {
                        _currentRequest.Headers[key] = value;
                    }
                }
            }
        }

        private string FormatResponseBody(string body)
        {
            if (string.IsNullOrEmpty(body))
                return string.Empty;

            try
            {
                // Try to format as JSON
                if (body.TrimStart().StartsWith("{") || body.TrimStart().StartsWith("["))
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject(body);
                    return Newtonsoft.Json.JsonConvert.SerializeObject(obj, Newtonsoft.Json.Formatting.Indented);
                }
            }
            catch { }

            return body;
        }

        private void LoadCollections()
        {
            var collections = _storageService.LoadAllCollections();
            foreach (var collection in collections)
            {
                Collections.Add(collection);
            }
        }

        private void LoadEnvironments()
        {
            var environments = _storageService.LoadAllEnvironments();
            foreach (var env in environments)
            {
                Environments.Add(env);
                _environmentService.AddEnvironment(env);
            }
        }

        private string GetDomainFromUrl(string url)
        {
            try
            {
                var uri = new Uri(url);
                return uri.Host;
            }
            catch
            {
                return "Unknown";
            }
        }

        public void SelectEnvironment(string environmentId)
        {
            _environmentService.SetActiveEnvironment(environmentId);
            StatusText = $"Active environment: {_environmentService.ActiveEnvironment?.Name ?? "None"}";
        }

        public void LoadRequestFromHistory(ApiRequest request)
        {
            Url = request.Url;
            SelectedMethod = request.Method.ToString();
            RequestBody = request.Body;
            HeadersText = string.Join("\n", request.Headers.Select(h => $"{h.Key}: {h.Value}"));
            _currentRequest = request;
        }
    }
}
