using System.Collections.Generic;

namespace ApiTester.Models
{
    public class Environment
    {
        public string Id { get; set; } = System.Guid.NewGuid().ToString();
        public string Name { get; set; } = "New Environment";
        public Dictionary<string, string> Variables { get; set; } = new Dictionary<string, string>();
        public bool IsActive { get; set; } = false;
    }
}
