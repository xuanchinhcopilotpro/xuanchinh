using System;
using System.Collections.Generic;

namespace ApiTester.Models
{
    public class ApiRequest
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; } = "New Request";
        public string Url { get; set; } = string.Empty;
        public HttpMethod Method { get; set; } = HttpMethod.GET;
        public Dictionary<string, string> Headers { get; set; } = new Dictionary<string, string>();
        public Dictionary<string, string> QueryParams { get; set; } = new Dictionary<string, string>();
        public string Body { get; set; } = string.Empty;
        public BodyType BodyType { get; set; } = BodyType.None;
        public AuthType AuthType { get; set; } = AuthType.None;
        public string AuthValue { get; set; } = string.Empty;
    }

    public enum HttpMethod
    {
        GET,
        POST,
        PUT,
        DELETE,
        PATCH,
        HEAD,
        OPTIONS
    }

    public enum BodyType
    {
        None,
        Raw,
        JSON,
        XML,
        FormData,
        FormUrlEncoded
    }

    public enum AuthType
    {
        None,
        BearerToken,
        BasicAuth,
        ApiKey
    }
}
