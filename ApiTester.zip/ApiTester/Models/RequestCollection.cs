using System.Collections.Generic;

namespace ApiTester.Models
{
    public class RequestCollection
    {
        public string Id { get; set; } = System.Guid.NewGuid().ToString();
        public string Name { get; set; } = "New Collection";
        public List<ApiRequest> Requests { get; set; } = new List<ApiRequest>();
    }
}
