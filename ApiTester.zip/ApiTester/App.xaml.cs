using System.Windows;

namespace ApiTester
{
    public partial class App : Application
    {
    }
}
