using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using ApiTester.Models;

namespace ApiTester.Services
{
    public class CurlParser
    {
        public ApiRequest ParseCurl(string curlCommand)
        {
            var request = new ApiRequest();

            try
            {
                // Remove 'curl' at the beginning
                curlCommand = curlCommand.Trim();
                if (curlCommand.StartsWith("curl", StringComparison.OrdinalIgnoreCase))
                {
                    curlCommand = curlCommand.Substring(4).Trim();
                }

                // Parse URL
                var urlMatch = Regex.Match(curlCommand, @"['""]?(https?://[^\s'""]+)['""]?");
                if (urlMatch.Success)
                {
                    request.Url = urlMatch.Groups[1].Value.Trim('\'', '"');
                }

                // Parse Method
                var methodMatch = Regex.Match(curlCommand, @"-X\s+([A-Z]+)", RegexOptions.IgnoreCase);
                if (methodMatch.Success)
                {
                    if (Enum.TryParse<HttpMethod>(methodMatch.Groups[1].Value.ToUpper(), out var method))
                    {
                        request.Method = method;
                    }
                }
                else
                {
                    // Check for --request
                    methodMatch = Regex.Match(curlCommand, @"--request\s+([A-Z]+)", RegexOptions.IgnoreCase);
                    if (methodMatch.Success)
                    {
                        if (Enum.TryParse<HttpMethod>(methodMatch.Groups[1].Value.ToUpper(), out var method))
                        {
                            request.Method = method;
                        }
                    }
                }

                // Parse Headers
                var headerMatches = Regex.Matches(curlCommand, @"-H\s+['""]([^:]+):\s*([^'""]+)['""]");
                foreach (Match match in headerMatches)
                {
                    var key = match.Groups[1].Value.Trim();
                    var value = match.Groups[2].Value.Trim();
                    request.Headers[key] = value;

                    // Check for Authorization header
                    if (key.Equals("Authorization", StringComparison.OrdinalIgnoreCase))
                    {
                        if (value.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
                        {
                            request.AuthType = AuthType.BearerToken;
                            request.AuthValue = value.Substring(7).Trim();
                        }
                        else if (value.StartsWith("Basic ", StringComparison.OrdinalIgnoreCase))
                        {
                            request.AuthType = AuthType.BasicAuth;
                            request.AuthValue = value.Substring(6).Trim();
                        }
                    }
                }

                // Parse --header format
                var headerMatches2 = Regex.Matches(curlCommand, @"--header\s+['""]([^:]+):\s*([^'""]+)['""]");
                foreach (Match match in headerMatches2)
                {
                    var key = match.Groups[1].Value.Trim();
                    var value = match.Groups[2].Value.Trim();
                    request.Headers[key] = value;
                }

                // Parse Body/Data
                var dataMatch = Regex.Match(curlCommand, @"(?:-d|--data|--data-raw)\s+['""](.+?)['""](?:\s|$)");
                if (dataMatch.Success)
                {
                    request.Body = dataMatch.Groups[1].Value;
                    request.BodyType = BodyType.Raw;

                    // Try to detect if it's JSON
                    if (request.Body.TrimStart().StartsWith("{") || request.Body.TrimStart().StartsWith("["))
                    {
                        request.BodyType = BodyType.JSON;
                    }
                }

                // Parse --data-binary
                var dataBinaryMatch = Regex.Match(curlCommand, @"--data-binary\s+['""](.+?)['""](?:\s|$)");
                if (dataBinaryMatch.Success)
                {
                    request.Body = dataBinaryMatch.Groups[1].Value;
                    request.BodyType = BodyType.Raw;
                }

                // If method not specified but has data, assume POST
                if (request.Method == HttpMethod.GET && !string.IsNullOrEmpty(request.Body))
                {
                    request.Method = HttpMethod.POST;
                }

                request.Name = $"Imported from cURL - {request.Method} {GetDomainFromUrl(request.Url)}";
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to parse cURL command: {ex.Message}");
            }

            return request;
        }

        private string GetDomainFromUrl(string url)
        {
            try
            {
                var uri = new Uri(url);
                return uri.Host;
            }
            catch
            {
                return "Unknown";
            }
        }
    }
}
