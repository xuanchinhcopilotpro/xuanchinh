using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace ApiTester.Services
{
    public class EnvironmentService
    {
        private List<Models.Environment> _environments = new List<Models.Environment>();
        private Models.Environment? _activeEnvironment;

        public List<Models.Environment> Environments => _environments;
        public Models.Environment? ActiveEnvironment => _activeEnvironment;

        public void AddEnvironment(Models.Environment environment)
        {
            _environments.Add(environment);
        }

        public void RemoveEnvironment(string id)
        {
            var env = _environments.FirstOrDefault(e => e.Id == id);
            if (env != null)
            {
                _environments.Remove(env);
                if (_activeEnvironment?.Id == id)
                {
                    _activeEnvironment = null;
                }
            }
        }

        public void SetActiveEnvironment(string id)
        {
            // Deactivate all
            foreach (var env in _environments)
            {
                env.IsActive = false;
            }

            // Activate selected
            var environment = _environments.FirstOrDefault(e => e.Id == id);
            if (environment != null)
            {
                environment.IsActive = true;
                _activeEnvironment = environment;
            }
        }

        public string ReplaceVariables(string input)
        {
            if (string.IsNullOrEmpty(input) || _activeEnvironment == null)
                return input;

            var result = input;

            // Replace variables in format {{variable_name}}
            var matches = Regex.Matches(input, @"\{\{([^}]+)\}\}");
            foreach (Match match in matches)
            {
                var variableName = match.Groups[1].Value.Trim();
                if (_activeEnvironment.Variables.TryGetValue(variableName, out var value))
                {
                    result = result.Replace(match.Value, value);
                }
            }

            return result;
        }

        public Models.ApiRequest ReplaceVariablesInRequest(Models.ApiRequest request)
        {
            if (_activeEnvironment == null)
                return request;

            var modifiedRequest = new Models.ApiRequest
            {
                Id = request.Id,
                Name = request.Name,
                Url = ReplaceVariables(request.Url),
                Method = request.Method,
                Body = ReplaceVariables(request.Body),
                BodyType = request.BodyType,
                AuthType = request.AuthType,
                AuthValue = ReplaceVariables(request.AuthValue),
                Headers = new Dictionary<string, string>(),
                QueryParams = new Dictionary<string, string>()
            };

            foreach (var header in request.Headers)
            {
                modifiedRequest.Headers[header.Key] = ReplaceVariables(header.Value);
            }

            foreach (var param in request.QueryParams)
            {
                modifiedRequest.QueryParams[param.Key] = ReplaceVariables(param.Value);
            }

            return modifiedRequest;
        }
    }
}
