using System;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using ApiTester.Models;

namespace ApiTester.Services
{
    public class HttpService
    {
        private readonly HttpClient _httpClient;

        public HttpService()
        {
            var handler = new HttpClientHandler
            {
                AllowAutoRedirect = true,
                MaxAutomaticRedirections = 10
            };
            _httpClient = new HttpClient(handler);
            _httpClient.Timeout = TimeSpan.FromSeconds(30);
        }

        public async Task<ApiResponse> SendRequestAsync(ApiRequest request)
        {
            var stopwatch = Stopwatch.StartNew();
            var response = new ApiResponse();

            try
            {
                // Build full URL with query parameters
                var url = BuildUrl(request.Url, request.QueryParams);

                // Create HTTP request message
                var httpRequest = new HttpRequestMessage
                {
                    RequestUri = new Uri(url),
                    Method = GetHttpMethod(request.Method)
                };

                // Add headers
                foreach (var header in request.Headers)
                {
                    try
                    {
                        if (header.Key.Equals("Content-Type", StringComparison.OrdinalIgnoreCase))
                            continue; // Will be set with content
                        httpRequest.Headers.TryAddWithoutValidation(header.Key, header.Value);
                    }
                    catch { }
                }

                // Add authentication
                AddAuthentication(httpRequest, request);

                // Add body if needed
                if (request.Method != Models.HttpMethod.GET && 
                    request.Method != Models.HttpMethod.HEAD && 
                    !string.IsNullOrEmpty(request.Body))
                {
                    var contentType = GetContentType(request.BodyType);
                    httpRequest.Content = new StringContent(request.Body, Encoding.UTF8, contentType);
                }

                // Send request
                var httpResponse = await _httpClient.SendAsync(httpRequest);
                stopwatch.Stop();

                // Parse response
                response.StatusCode = (int)httpResponse.StatusCode;
                response.StatusDescription = httpResponse.ReasonPhrase ?? string.Empty;
                response.ResponseTime = stopwatch.ElapsedMilliseconds;
                response.IsSuccess = httpResponse.IsSuccessStatusCode;

                // Get response headers
                foreach (var header in httpResponse.Headers)
                {
                    response.Headers[header.Key] = string.Join(", ", header.Value);
                }

                if (httpResponse.Content != null)
                {
                    foreach (var header in httpResponse.Content.Headers)
                    {
                        response.Headers[header.Key] = string.Join(", ", header.Value);
                    }

                    response.Body = await httpResponse.Content.ReadAsStringAsync();
                    response.ContentLength = response.Body.Length;
                }
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                response.IsSuccess = false;
                response.ErrorMessage = ex.Message;
                response.ResponseTime = stopwatch.ElapsedMilliseconds;
            }

            return response;
        }

        private string BuildUrl(string baseUrl, System.Collections.Generic.Dictionary<string, string> queryParams)
        {
            if (queryParams == null || queryParams.Count == 0)
                return baseUrl;

            var queryString = string.Join("&", queryParams.Select(kv => $"{Uri.EscapeDataString(kv.Key)}={Uri.EscapeDataString(kv.Value)}"));
            var separator = baseUrl.Contains("?") ? "&" : "?";
            return $"{baseUrl}{separator}{queryString}";
        }

        private System.Net.Http.HttpMethod GetHttpMethod(Models.HttpMethod method)
        {
            return method switch
            {
                Models.HttpMethod.GET => System.Net.Http.HttpMethod.Get,
                Models.HttpMethod.POST => System.Net.Http.HttpMethod.Post,
                Models.HttpMethod.PUT => System.Net.Http.HttpMethod.Put,
                Models.HttpMethod.DELETE => System.Net.Http.HttpMethod.Delete,
                Models.HttpMethod.PATCH => System.Net.Http.HttpMethod.Patch,
                Models.HttpMethod.HEAD => System.Net.Http.HttpMethod.Head,
                Models.HttpMethod.OPTIONS => System.Net.Http.HttpMethod.Options,
                _ => System.Net.Http.HttpMethod.Get
            };
        }

        private string GetContentType(BodyType bodyType)
        {
            return bodyType switch
            {
                BodyType.JSON => "application/json",
                BodyType.XML => "application/xml",
                BodyType.FormData => "multipart/form-data",
                BodyType.FormUrlEncoded => "application/x-www-form-urlencoded",
                _ => "text/plain"
            };
        }

        private void AddAuthentication(HttpRequestMessage request, ApiRequest apiRequest)
        {
            if (apiRequest.AuthType == AuthType.None || string.IsNullOrEmpty(apiRequest.AuthValue))
                return;

            switch (apiRequest.AuthType)
            {
                case AuthType.BearerToken:
                    request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", apiRequest.AuthValue);
                    break;
                case AuthType.BasicAuth:
                    var bytes = Encoding.UTF8.GetBytes(apiRequest.AuthValue);
                    request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(bytes));
                    break;
                case AuthType.ApiKey:
                    request.Headers.TryAddWithoutValidation("X-API-Key", apiRequest.AuthValue);
                    break;
            }
        }
    }
}
