using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace ApiTester.Services
{
    public class StorageService
    {
        private readonly string _appDataPath;
        private readonly string _collectionsPath;
        private readonly string _environmentsPath;

        public StorageService()
        {
            _appDataPath = Path.Combine(
                System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData),
                "ApiTester"
            );

            _collectionsPath = Path.Combine(_appDataPath, "collections");
            _environmentsPath = Path.Combine(_appDataPath, "environments");

            Directory.CreateDirectory(_appDataPath);
            Directory.CreateDirectory(_collectionsPath);
            Directory.CreateDirectory(_environmentsPath);
        }

        // Collections
        public void SaveCollection(Models.RequestCollection collection)
        {
            var filePath = Path.Combine(_collectionsPath, $"{collection.Id}.json");
            var json = JsonConvert.SerializeObject(collection, Formatting.Indented);
            File.WriteAllText(filePath, json);
        }

        public List<Models.RequestCollection> LoadAllCollections()
        {
            var collections = new List<Models.RequestCollection>();

            if (!Directory.Exists(_collectionsPath))
                return collections;

            foreach (var file in Directory.GetFiles(_collectionsPath, "*.json"))
            {
                try
                {
                    var json = File.ReadAllText(file);
                    var collection = JsonConvert.DeserializeObject<Models.RequestCollection>(json);
                    if (collection != null)
                    {
                        collections.Add(collection);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error loading collection from {file}: {ex.Message}");
                }
            }

            return collections;
        }

        public void DeleteCollection(string id)
        {
            var filePath = Path.Combine(_collectionsPath, $"{id}.json");
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
        }

        // Environments
        public void SaveEnvironment(Models.Environment environment)
        {
            var filePath = Path.Combine(_environmentsPath, $"{environment.Id}.json");
            var json = JsonConvert.SerializeObject(environment, Formatting.Indented);
            File.WriteAllText(filePath, json);
        }

        public List<Models.Environment> LoadAllEnvironments()
        {
            var environments = new List<Models.Environment>();

            if (!Directory.Exists(_environmentsPath))
                return environments;

            foreach (var file in Directory.GetFiles(_environmentsPath, "*.json"))
            {
                try
                {
                    var json = File.ReadAllText(file);
                    var environment = JsonConvert.DeserializeObject<Models.Environment>(json);
                    if (environment != null)
                    {
                        environments.Add(environment);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error loading environment from {file}: {ex.Message}");
                }
            }

            return environments;
        }

        public void DeleteEnvironment(string id)
        {
            var filePath = Path.Combine(_environmentsPath, $"{id}.json");
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
        }

        public string ExportCollection(Models.RequestCollection collection, string exportPath)
        {
            var json = JsonConvert.SerializeObject(collection, Formatting.Indented);
            File.WriteAllText(exportPath, json);
            return exportPath;
        }

        public Models.RequestCollection? ImportCollection(string importPath)
        {
            if (!File.Exists(importPath))
                return null;

            var json = File.ReadAllText(importPath);
            var collection = JsonConvert.DeserializeObject<Models.RequestCollection>(json);
            
            if (collection != null)
            {
                // Generate new ID to avoid conflicts
                collection.Id = Guid.NewGuid().ToString();
                SaveCollection(collection);
            }

            return collection;
        }
    }
}
