using System.Collections.ObjectModel;

namespace PostmanTool.Models
{
    public class SavedRequest
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; } = "";
        public string Method { get; set; } = "GET";
        public string Url { get; set; } = "";
        public string Body { get; set; } = "";
        public List<HeaderItem> Headers { get; set; } = new();
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime ModifiedAt { get; set; } = DateTime.Now;
    }

    public class RequestCollection
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; } = "";
        public List<SavedRequest> Requests { get; set; } = new();
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }

    public class Environment
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; } = "";
        public Dictionary<string, string> Variables { get; set; } = new();
        public bool IsActive { get; set; } = false;
    }

    public class AppData
    {
        public List<RequestCollection> Collections { get; set; } = new();
        public List<Environment> Environments { get; set; } = new();
        public List<SavedRequest> History { get; set; } = new();
    }
}
