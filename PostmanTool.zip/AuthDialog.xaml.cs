using System.Windows;

namespace PostmanTool
{
    public partial class AuthDialog : Window
    {
        public string AuthType { get; private set; } = "";
        public string Token { get; private set; } = "";
        public string KeyName { get; private set; } = "X-API-Key";

        public AuthDialog()
        {
            InitializeComponent();
            AuthTypeComboBox.SelectedIndex = 0;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedType = (AuthTypeComboBox.SelectedItem as System.Windows.Controls.ComboBoxItem)?.Content.ToString();
            AuthType = selectedType ?? "";
            Token = TokenTextBox.Text.Trim();

            if (AuthType == "API Key")
            {
                KeyName = KeyNameTextBox.Text.Trim();
                if (string.IsNullOrWhiteSpace(KeyName))
                {
                    MessageBox.Show("Vui lòng nhập tên của API Key!", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }

            if (string.IsNullOrWhiteSpace(Token))
            {
                MessageBox.Show("Vui lòng nhập token/key!", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void AuthTypeComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (KeyNamePanel != null)
            {
                var selectedType = (AuthTypeComboBox.SelectedItem as System.Windows.Controls.ComboBoxItem)?.Content.ToString();
                KeyNamePanel.Visibility = selectedType == "API Key" ? Visibility.Visible : Visibility.Collapsed;
            }
        }
    }
}
