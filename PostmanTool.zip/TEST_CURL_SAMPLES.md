# cURL Test Cases - 25 Samples

## ✅ Test Coverage

### 1. Simple GET
```bash
curl https://api.example.com/users
```
**Expected:** Method=GET, URL extracted, No body

---

### 2. GET with Headers
```bash
curl https://api.example.com/users -H 'Authorization: Bearer token123'
```
**Expected:** Method=GET, 1 header (Authorization)

---

### 3. POST Simple JSON
```bash
curl -X POST "https://api.example.com/posts" -H "Content-Type: application/json" -d '{"title":"Test"}'
```
**Expected:** Method=POST, Body contains "title"

---

### 4. POST with Escaped Quotes
```bash
curl -X POST "https://jsonplaceholder.typicode.com/posts" -H "Content-Type: application/json" -d "{\"title\":\"Test Post\",\"body\":\"This is a test.\",\"userId\":10}"
```
**Expected:** Method=POST, Body has properly un-escaped JSON: `{"title":"Test Post","body":"This is a test.","userId":10}`

---

### 5. POST with Form Data
```bash
curl --location 'https://login.microsoftonline.com/token' --form 'client_id="abc123"' --form 'client_secret="secret"' --form 'grant_type="client_credentials"'
```
**Expected:** Method=POST, Body=`client_id=abc123&client_secret=secret&grant_type=client_credentials`, Content-Type header added

---

### 6. POST with Data-Urlencode
```bash
curl --location 'https://api.twilio.com/Messages.json' --data-urlencode 'To=+84399797142' --data-urlencode 'From=+14064127513' --data-urlencode 'Body=Hello World'
```
**Expected:** Method=POST, Body=`To=%2B84399797142&From=%2B14064127513&Body=Hello+World`

---

### 7. Multiple Headers
```bash
curl https://api.example.com/data -H 'Authorization: Bearer token' -H 'Content-Type: application/json' -H 'X-Custom-Header: value123'
```
**Expected:** 3 headers extracted

---

### 8. PUT Request
```bash
curl -X PUT 'https://api.example.com/users/1' -H 'Content-Type: application/json' -d '{"name":"Updated Name"}'
```
**Expected:** Method=PUT, Body contains "name"

---

### 9. DELETE Request
```bash
curl -X DELETE 'https://api.example.com/users/1' -H 'Authorization: Bearer token'
```
**Expected:** Method=DELETE, 1 header

---

### 10. PATCH Request
```bash
curl -X PATCH 'https://api.example.com/users/1' -d '{"status":"active"}'
```
**Expected:** Method=PATCH, Body contains "status"

---

### 11. URL with Query Parameters
```bash
curl 'https://api.example.com/search?q=test&limit=10&offset=0'
```
**Expected:** Full URL with query params preserved

---

### 12. Header with Colon in Value
```bash
curl https://api.example.com -H 'Authorization: Basic dXNlcjpwYXNzd29yZA=='
```
**Expected:** Header value includes everything after first colon

---

### 13. Long URL with Path Segments
```bash
curl 'https://api.example.com/v1/resources/1234567890/subitems/9876543210/details?include=all&format=json'
```
**Expected:** Full long URL extracted

---

### 14. Multi-line JSON (Formatted)
```bash
curl -X POST 'https://api.example.com/posts' -H 'Content-Type: application/json' --data-raw '{
    "title": "Test Post",
    "body": "This is a test body.",
    "userId": 10
}'
```
**Expected:** Body preserves newlines and formatting

---

### 15. Cookie Header
```bash
curl https://api.example.com -H 'Cookie: sessionId=abc123; userId=456; theme=dark'
```
**Expected:** Full cookie string in header value

---

### 16. Form with Special Characters
```bash
curl --location 'https://api.example.com/login' --form 'email="user@example.com"' --form 'password="P@ssw0rd!"'
```
**Expected:** Body=`email=user%40example.com&password=P%40ssw0rd%21` (URL-encoded)

---

### 17. No Method Specified (Auto-detect POST)
```bash
curl https://api.example.com/posts -d '{"title":"Auto POST"}'
```
**Expected:** Method auto-detected as POST (because of -d flag)

---

### 18. --location Flag
```bash
curl --location 'https://api.example.com/redirect' -H 'Authorization: Bearer token'
```
**Expected:** URL extracted from --location flag

---

### 19. Mixed Quote Types
```bash
curl -X POST "https://api.example.com/posts" -H 'Authorization: Bearer token' -d "{\"title\":\"Test\"}"
```
**Expected:** Both single and double quotes handled correctly

---

### 20. Empty Body
```bash
curl -X POST 'https://api.example.com/action' -H 'Content-Type: application/json' -d ''
```
**Expected:** Method=POST, Body is empty string

---

### 21. Complex Nested JSON
```bash
curl -X POST 'https://api.example.com/data' -H 'Content-Type: application/json' -d '{"user":{"name":"John","age":30,"address":{"city":"NYC","zip":"10001"}}}'
```
**Expected:** Full nested JSON structure in body

---

### 22. OAuth Token Request (Real World)
```bash
curl --location 'https://login.microsoftonline.com/a428df7b-e867-4cbb-95ef-612cc84885c4/oauth2/token' --header 'Cookie: fpc=xyz' --form 'client_id="6075437d-aa98-4cd7-b9fa-2ec0db641a9b"' --form 'client_secret="Ghf8Q~5uphCDfQTP4NECSC3ZDc8.yPnwR8rpma-0"' --form 'grant_type="client_credentials"' --form 'resource="https://org176b616e.crm5.dynamics.com"'
```
**Expected:** 
- Method=POST
- Body has client_id, client_secret, grant_type, resource (URL-encoded)
- Headers should NOT contain client_id, grant_type (they're form fields, not headers)
- Only Cookie header should remain

---

### 23. Array in JSON
```bash
curl -X POST 'https://api.example.com/bulk' -d '{"items":["item1","item2","item3"]}'
```
**Expected:** Body contains array structure

---

### 24. Bearer Token (Long JWT)
```bash
curl --location 'https://api.example.com/data' --header 'Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IjNQYUs0RWZ5Qk5RdTNDdGpZc2EzWW1oUTVFMCJ9.eyJhdWQiOiJodHRwczovL2V4YW1wbGUuY29tLyIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LyJ9.signature'
```
**Expected:** Full JWT token in header value

---

### 25. Request with Line Continuation (Backslashes)
```bash
curl -X POST 'https://api.example.com/path' \
-H 'Content-Type: application/json' \
-d '{"key":"value"}'
```
**Expected:** Backslashes normalized, all flags recognized

---

## 🧪 How to Test

1. Open PostmanTool application
2. Click **"Import cURL"** button
3. Paste each cURL command above
4. Click **OK**
5. Verify:
   - ✅ URL is correct
   - ✅ Method is correct
   - ✅ Headers are populated (check Headers tab)
   - ✅ Body is populated (check Body tab)
6. Click **"Send"** to test actual API call (for public APIs)

## 📊 Expected Results Summary

| Test # | Method | URL Pattern | Headers | Body | Special Notes |
|--------|--------|-------------|---------|------|---------------|
| 1 | GET | example.com/users | 0 | Empty | Simple GET |
| 2 | GET | example.com/users | 1 | Empty | Auth header |
| 3 | POST | example.com/posts | 1 | JSON | Simple JSON |
| 4 | POST | jsonplaceholder | 1 | JSON | Escaped quotes |
| 5 | POST | microsoftonline | 1 | Form | Form data |
| 6 | POST | twilio | 0 | Encoded | URL encoding |
| 7 | GET | example.com/data | 3 | Empty | Multiple headers |
| 8 | PUT | example.com/users/1 | 1 | JSON | PUT method |
| 9 | DELETE | example.com/users/1 | 1 | Empty | DELETE method |
| 10 | PATCH | example.com/users/1 | 0 | JSON | PATCH method |
| 11 | GET | example.com/search? | 0 | Empty | Query params |
| 12 | GET | example.com | 1 | Empty | Basic auth |
| 13 | GET | Long path with IDs | 0 | Empty | Complex URL |
| 14 | POST | example.com/posts | 1 | Multiline | Formatted JSON |
| 15 | GET | example.com | 1 | Empty | Cookie header |
| 16 | POST | example.com/login | 1 | Form | Special chars |
| 17 | POST | example.com/posts | 0 | JSON | Auto-detect POST |
| 18 | GET | example.com/redirect | 1 | Empty | --location flag |
| 19 | POST | example.com/posts | 1 | JSON | Mixed quotes |
| 20 | POST | example.com/action | 1 | Empty | Empty body |
| 21 | POST | example.com/data | 1 | JSON | Nested JSON |
| 22 | POST | microsoftonline OAuth | 1 | Form | Real OAuth (form fields not in headers) |
| 23 | POST | example.com/bulk | 0 | JSON | JSON array |
| 24 | GET | example.com/data | 1 | Empty | Long JWT |
| 25 | POST | example.com/path | 1 | JSON | Line continuation |

---

## 🐛 Known Issues to Watch For

1. **Escaped quotes**: Should be un-escaped in body (`\"` → `"`)
2. **Form fields as headers**: OAuth params (client_id, grant_type) should be in body, NOT headers
3. **Content-Type conflict**: Should not be in both headers grid AND content
4. **Multi-line JSON**: Newlines should be preserved
5. **URL encoding**: `+` becomes `%2B`, `@` becomes `%40`, etc.
6. **Quote matching**: Must find correct closing quote (skip escaped `\"`)

---

## 🎯 Success Criteria

- ✅ All 25 test cases import without errors
- ✅ Method, URL, Headers, Body are correctly populated
- ✅ Sending requests works (for public APIs like JSONPlaceholder)
- ✅ No crashes or exceptions during import
- ✅ Debug console shows correct parsing logs
