using System;
using System.Collections.ObjectModel;
using System.Net.Http;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PostmanTool.Services;
using PostmanTool.Models;
using PostmanTool.Dialogs;

namespace PostmanTool
{
    public partial class MainWindow : Window
    {
        private readonly HttpClient _httpClient;
        public ObservableCollection<HeaderItem> Headers { get; set; }
        private readonly StorageService _storageService;
        private readonly EnvironmentService _environmentService;
        private AppData _appData;
        
        public MainWindow()
        {
            InitializeComponent();
            _httpClient = new HttpClient();
            _httpClient.Timeout = TimeSpan.FromSeconds(30);
            
            Headers = new ObservableCollection<HeaderItem>();
            HeadersDataGrid.ItemsSource = Headers;
            
            // Set default method
            MethodComboBox.SelectedIndex = 0;

            // Initialize services
            _storageService = new StorageService();
            _environmentService = new EnvironmentService();
            _appData = _storageService.LoadData();

            // Load saved data
            LoadCollections();
            UpdateEnvironmentStatus();
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var url = UrlTextBox.Text.Trim();
                
                if (string.IsNullOrWhiteSpace(url))
                {
                    MessageBox.Show("Vui lòng nhập URL!", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Replace environment variables in URL
                url = _environmentService.ReplaceVariables(url);
                
                // Disable button during request
                SendButton.IsEnabled = false;
                SendButton.Content = "Đang gửi...";
                StatusText.Text = "Đang gửi request...";
                ResponseBodyTextBox.Clear();
                ResponseHeadersTextBox.Clear();

                // Clear and add headers (skip Content-Type, it will be set on content)
                _httpClient.DefaultRequestHeaders.Clear();
                foreach (var header in Headers)
                {
                    if (header.Enabled && !string.IsNullOrWhiteSpace(header.Key))
                    {
                        // Skip Content-Type - it will be set on StringContent
                        if (header.Key.Equals("Content-Type", StringComparison.OrdinalIgnoreCase))
                        {
                            continue;
                        }
                        
                        try
                        {
                            var headerValue = _environmentService.ReplaceVariables(header.Value);
                            _httpClient.DefaultRequestHeaders.Add(header.Key, headerValue);
                        }
                        catch (Exception ex)
                        {
                            StatusText.Text = $"Lỗi header '{header.Key}': {ex.Message}";
                        }
                    }
                }

                var method = (MethodComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
                var startTime = DateTime.Now;
                HttpResponseMessage? response = null;

                switch (method)
                {
                    case "GET":
                        response = await _httpClient.GetAsync(url);
                        break;
                    case "POST":
                        response = await SendWithBodyAsync(url, HttpMethod.Post);
                        break;
                    case "PUT":
                        response = await SendWithBodyAsync(url, HttpMethod.Put);
                        break;
                    case "DELETE":
                        response = await _httpClient.DeleteAsync(url);
                        break;
                    case "PATCH":
                        response = await SendWithBodyAsync(url, HttpMethod.Patch);
                        break;
                }

                var duration = (DateTime.Now - startTime).TotalMilliseconds;

                if (response != null)
                {
                    await DisplayResponseAsync(response, duration);
                }
            }
            catch (HttpRequestException ex)
            {
                StatusText.Text = $"❌ Lỗi kết nối: {ex.Message}";
                MessageBox.Show($"Lỗi kết nối: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (TaskCanceledException)
            {
                StatusText.Text = "❌ Request timeout!";
                MessageBox.Show("Request timeout! Vui lòng thử lại.", "Timeout", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                StatusText.Text = $"❌ Lỗi: {ex.Message}";
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                SendButton.IsEnabled = true;
                SendButton.Content = "Send";
            }
        }

        private async Task<HttpResponseMessage> SendWithBodyAsync(string url, HttpMethod method)
        {
            StringContent? content = null;
            var bodyText = BodyTextBox.Text.Trim();

            // Replace environment variables
            bodyText = _environmentService.ReplaceVariables(bodyText);

            if (!string.IsNullOrWhiteSpace(bodyText))
            {
                // Check if user specified Content-Type in headers
                var userContentType = HeadersDataGrid.ItemsSource?.Cast<HeaderItem>()
                    .FirstOrDefault(h => h.Key?.Equals("Content-Type", StringComparison.OrdinalIgnoreCase) == true);

                string contentType = "application/json"; // default

                if (userContentType != null && !string.IsNullOrWhiteSpace(userContentType.Value))
                {
                    // User specified Content-Type, use it!
                    contentType = userContentType.Value;
                    System.Diagnostics.Debug.WriteLine($"Using user-specified Content-Type: {contentType}");
                }
                else
                {
                    // Auto-detect: try to parse as JSON
                    try
                    {
                        JToken.Parse(bodyText);
                        contentType = "application/json";
                    }
                    catch (JsonReaderException)
                    {
                        contentType = "text/plain";
                    }
                }

                content = new StringContent(bodyText, Encoding.UTF8, contentType);
                System.Diagnostics.Debug.WriteLine($"Body Content-Type: {contentType}");
                System.Diagnostics.Debug.WriteLine($"Body length: {bodyText.Length} chars");
            }

            var request = new HttpRequestMessage(method, url)
            {
                Content = content
            };

            return await _httpClient.SendAsync(request);
        }

        private async Task DisplayResponseAsync(HttpResponseMessage response, double duration)
        {
            // Display Status
            var statusIcon = response.IsSuccessStatusCode ? "✓" : "✗";
            StatusText.Text = $"{statusIcon} {(int)response.StatusCode} {response.StatusCode} - {duration:F2}ms";
            
            // Display Headers
            var headersSb = new StringBuilder();
            headersSb.AppendLine($"Status: {(int)response.StatusCode} {response.StatusCode}");
            headersSb.AppendLine($"Time: {duration:F2}ms");
            headersSb.AppendLine();
            
            foreach (var header in response.Headers)
            {
                headersSb.AppendLine($"{header.Key}: {string.Join(", ", header.Value)}");
            }
            if (response.Content.Headers != null)
            {
                foreach (var header in response.Content.Headers)
                {
                    headersSb.AppendLine($"{header.Key}: {string.Join(", ", header.Value)}");
                }
            }
            ResponseHeadersTextBox.Text = headersSb.ToString();
            
            // Display Body
            var content = await response.Content.ReadAsStringAsync();
            
            System.Diagnostics.Debug.WriteLine($"=== Response Body Debug ===");
            System.Diagnostics.Debug.WriteLine($"Content length: {content?.Length ?? 0}");
            System.Diagnostics.Debug.WriteLine($"First 200 chars: {(content?.Length > 0 ? content.Substring(0, Math.Min(200, content.Length)) : "empty")}");
            
            if (!string.IsNullOrWhiteSpace(content))
            {
                // Update body size
                var sizeInBytes = System.Text.Encoding.UTF8.GetByteCount(content);
                if (sizeInBytes < 1024)
                {
                    BodySizeText.Text = $"{sizeInBytes} bytes";
                }
                else if (sizeInBytes < 1024 * 1024)
                {
                    BodySizeText.Text = $"{sizeInBytes / 1024.0:F2} KB";
                }
                else
                {
                    BodySizeText.Text = $"{sizeInBytes / (1024.0 * 1024.0):F2} MB";
                }
                
                // Try to format as JSON
                try
                {
                    var jsonObject = JToken.Parse(content);
                    var formattedJson = jsonObject.ToString(Formatting.Indented);
                    ResponseBodyTextBox.Text = formattedJson;
                    ResponseBodyTextBox.Tag = content; // Store raw version
                    System.Diagnostics.Debug.WriteLine("✓ JSON parsed and formatted successfully");
                }
                catch (JsonReaderException jsonEx)
                {
                    // Not JSON, display as-is
                    System.Diagnostics.Debug.WriteLine($"✗ Not valid JSON: {jsonEx.Message}");
                    ResponseBodyTextBox.Text = content;
                    ResponseBodyTextBox.Tag = content;
                }
                catch (Exception ex)
                {
                    // Other error, still display content
                    System.Diagnostics.Debug.WriteLine($"✗ Error parsing: {ex.GetType().Name} - {ex.Message}");
                    ResponseBodyTextBox.Text = $"Error displaying response:\n{ex.Message}\n\n--- Raw Content ---\n{content}";
                    ResponseBodyTextBox.Tag = content;
                }
            }
            else
            {
                ResponseBodyTextBox.Text = "(Empty body)";
                ResponseBodyTextBox.Tag = "";
                BodySizeText.Text = "0 bytes";
                System.Diagnostics.Debug.WriteLine("Empty response body");
            }
        }

        private void BodyFormatCombo_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (ResponseBodyTextBox == null || ResponseBodyTextBox.Tag == null)
                return;

            var rawContent = ResponseBodyTextBox.Tag.ToString();
            if (string.IsNullOrWhiteSpace(rawContent))
                return;

            if (BodyFormatCombo.SelectedIndex == 0) // Pretty
            {
                try
                {
                    var jsonObject = JToken.Parse(rawContent);
                    ResponseBodyTextBox.Text = jsonObject.ToString(Formatting.Indented);
                }
                catch (JsonReaderException)
                {
                    ResponseBodyTextBox.Text = rawContent;
                }
            }
            else // Raw
            {
                ResponseBodyTextBox.Text = rawContent;
            }
        }

        private void AddHeaderButton_Click(object sender, RoutedEventArgs e)
        {
            Headers.Add(new HeaderItem { Enabled = true, Key = "", Value = "" });
        }

        private void RemoveHeaderButton_Click(object sender, RoutedEventArgs e)
        {
            if (HeadersDataGrid.SelectedItem is HeaderItem selectedHeader)
            {
                Headers.Remove(selectedHeader);
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            ResponseBodyTextBox.Clear();
            ResponseHeadersTextBox.Clear();
            StatusText.Text = "Ready";
            BodySizeText.Text = "0 bytes";
        }

        private void CopyResponseButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(ResponseBodyTextBox.Text))
                {
                    Clipboard.SetText(ResponseBodyTextBox.Text);
                    MessageBox.Show("Response body copied to clipboard!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("No response to copy!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error copying: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void FormatJsonButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var json = BodyTextBox.Text.Trim();
                if (!string.IsNullOrWhiteSpace(json))
                {
                    var jsonObject = JToken.Parse(json);
                    BodyTextBox.Text = jsonObject.ToString(Formatting.Indented);
                    MessageBox.Show("JSON đã được format!", "Thành công", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (JsonReaderException ex)
            {
                MessageBox.Show($"JSON không hợp lệ: {ex.Message}", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void PresetAuthButton_Click(object sender, RoutedEventArgs e)
        {
            var authWindow = new AuthDialog();
            if (authWindow.ShowDialog() == true)
            {
                if (authWindow.AuthType == "Bearer")
                {
                    Headers.Add(new HeaderItem 
                    { 
                        Enabled = true, 
                        Key = "Authorization", 
                        Value = $"Bearer {authWindow.Token}" 
                    });
                }
                else if (authWindow.AuthType == "API Key")
                {
                    Headers.Add(new HeaderItem 
                    { 
                        Enabled = true, 
                        Key = authWindow.KeyName, 
                        Value = authWindow.Token 
                    });
                }
            }
        }

        private void SaveRequestButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new SaveRequestDialog(_appData.Collections);
            if (dialog.ShowDialog() == true)
            {
                var savedRequest = new SavedRequest
                {
                    Name = dialog.RequestName,
                    Method = (MethodComboBox.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "GET",
                    Url = UrlTextBox.Text.Trim(),
                    Body = BodyTextBox.Text.Trim(),
                    Headers = new List<HeaderItem>(Headers),
                    ModifiedAt = DateTime.Now
                };

                if (dialog.CreateNewCollection)
                {
                    var newCollection = new RequestCollection
                    {
                        Name = dialog.CollectionName,
                        Requests = new List<SavedRequest> { savedRequest }
                    };
                    _appData.Collections.Add(newCollection);
                }
                else
                {
                    var collection = _appData.Collections.FirstOrDefault(c => c.Name == dialog.CollectionName);
                    if (collection != null)
                    {
                        collection.Requests.Add(savedRequest);
                    }
                }

                _storageService.SaveData(_appData);
                LoadCollections();
                MessageBox.Show("Request đã được lưu!", "Thành công", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ImportCurlButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new ImportCurlDialog();
            if (dialog.ShowDialog() == true)
            {
                var result = CurlParser.Parse(dialog.CurlCommand);
                
                // Debug: Show what was parsed
                var debugMsg = $"Parse result:\n" +
                              $"Success: {result.Success}\n" +
                              $"URL: {result.Url}\n" +
                              $"Method: {result.Method}\n" +
                              $"Headers: {result.Headers.Count}\n" +
                              $"Body: {(string.IsNullOrEmpty(result.Body) ? "(empty)" : result.Body.Substring(0, Math.Min(50, result.Body.Length)))}\n" +
                              $"Error: {result.ErrorMessage}";
                
                System.Diagnostics.Debug.WriteLine(debugMsg);
                
                if (result.Success)
                {
                    UrlTextBox.Text = result.Url;
                    
                    // Set method
                    var methodItem = MethodComboBox.Items.Cast<ComboBoxItem>()
                        .FirstOrDefault(item => item.Content.ToString() == result.Method);
                    if (methodItem != null)
                    {
                        MethodComboBox.SelectedItem = methodItem;
                    }

                    // Set headers
                    Headers.Clear();
                    foreach (var header in result.Headers)
                    {
                        Headers.Add(new HeaderItem { Enabled = true, Key = header.Key, Value = header.Value });
                    }

                    // Set body
                    BodyTextBox.Text = result.Body;

                    MessageBox.Show($"Import thành công!\n\nURL: {result.Url}\nMethod: {result.Method}\nHeaders: {result.Headers.Count}\nBody: {(string.IsNullOrEmpty(result.Body) ? "None" : "Yes")}", 
                        "Thành công", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show($"Lỗi parse cURL: {result.ErrorMessage}\n\nCommand:\n{dialog.CurlCommand}", 
                        "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void EnvironmentButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new EnvironmentDialog(_appData.Environments);
            if (dialog.ShowDialog() == true && dialog.SelectedEnvironment != null)
            {
                // Deactivate all environments
                foreach (var env in _appData.Environments)
                {
                    env.IsActive = false;
                }

                // Activate selected environment
                dialog.SelectedEnvironment.IsActive = true;
                _environmentService.SetActiveEnvironment(dialog.SelectedEnvironment.Variables);
                
                _storageService.SaveData(_appData);
                UpdateEnvironmentStatus();
                
                MessageBox.Show($"Environment '{dialog.SelectedEnvironment.Name}' đã được kích hoạt!", 
                    "Thành công", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void LoadCollections()
        {
            CollectionsTreeView.Items.Clear();
            
            foreach (var collection in _appData.Collections)
            {
                var collectionItem = new TreeViewItem
                {
                    Header = $"📁 {collection.Name} ({collection.Requests.Count})",
                    Tag = collection
                };

                foreach (var request in collection.Requests)
                {
                    var requestItem = new TreeViewItem
                    {
                        Header = $"{GetMethodIcon(request.Method)} {request.Name}",
                        Tag = request
                    };
                    collectionItem.Items.Add(requestItem);
                }

                CollectionsTreeView.Items.Add(collectionItem);
            }
        }

        private string GetMethodIcon(string method)
        {
            return method switch
            {
                "GET" => "🔵",
                "POST" => "🟢",
                "PUT" => "🟡",
                "DELETE" => "🔴",
                "PATCH" => "🟠",
                _ => "⚪"
            };
        }

        private void CollectionsTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (CollectionsTreeView.SelectedItem is TreeViewItem item && item.Tag is SavedRequest request)
            {
                LoadRequest(request);
            }
        }

        private void LoadRequest(SavedRequest request)
        {
            UrlTextBox.Text = request.Url;
            
            var methodItem = MethodComboBox.Items.Cast<ComboBoxItem>()
                .FirstOrDefault(item => item.Content.ToString() == request.Method);
            if (methodItem != null)
            {
                MethodComboBox.SelectedItem = methodItem;
            }

            Headers.Clear();
            foreach (var header in request.Headers)
            {
                Headers.Add(new HeaderItem 
                { 
                    Enabled = header.Enabled, 
                    Key = header.Key, 
                    Value = header.Value 
                });
            }

            BodyTextBox.Text = request.Body;
        }

        private void UpdateEnvironmentStatus()
        {
            var activeEnv = _appData.Environments.FirstOrDefault(e => e.IsActive);
            if (activeEnv != null)
            {
                EnvironmentStatusText.Text = $"🌍 {activeEnv.Name}";
                EnvironmentStatusText.Foreground = System.Windows.Media.Brushes.Green;
            }
            else
            {
                EnvironmentStatusText.Text = "No Environment";
                EnvironmentStatusText.Foreground = System.Windows.Media.Brushes.Gray;
            }
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            base.OnClosing(e);
            _storageService.SaveData(_appData);
        }
    }

    public class HeaderItem
    {
        public bool Enabled { get; set; }
        public string Key { get; set; } = "";
        public string Value { get; set; } = "";
    }
}
