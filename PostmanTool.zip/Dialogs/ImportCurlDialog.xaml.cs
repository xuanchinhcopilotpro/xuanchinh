using System.Windows;

namespace PostmanTool.Dialogs
{
    public partial class ImportCurlDialog : Window
    {
        public string CurlCommand { get; private set; } = "";

        public ImportCurlDialog()
        {
            InitializeComponent();
        }

        private void ImportButton_Click(object sender, RoutedEventArgs e)
        {
            CurlCommand = CurlTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(CurlCommand))
            {
                MessageBox.Show("Vui lòng nhập cURL command!", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void PasteButton_Click(object sender, RoutedEventArgs e)
        {
            if (Clipboard.ContainsText())
            {
                CurlTextBox.Text = Clipboard.GetText();
            }
        }
    }
}
