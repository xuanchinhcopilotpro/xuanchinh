using System.Windows;
using PostmanTool.Models;

namespace PostmanTool.Dialogs
{
    public partial class SaveRequestDialog : Window
    {
        public string RequestName { get; private set; } = "";
        public string CollectionName { get; private set; } = "";
        public bool CreateNewCollection { get; private set; } = true;

        public SaveRequestDialog(List<RequestCollection> existingCollections)
        {
            InitializeComponent();
            
            // Populate existing collections
            CollectionComboBox.Items.Add("(Tạo Collection mới)");
            foreach (var collection in existingCollections)
            {
                CollectionComboBox.Items.Add(collection.Name);
            }
            CollectionComboBox.SelectedIndex = 0;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            RequestName = RequestNameTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(RequestName))
            {
                MessageBox.Show("Vui lòng nhập tên request!", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (CollectionComboBox.SelectedIndex == 0)
            {
                CreateNewCollection = true;
                CollectionName = NewCollectionTextBox.Text.Trim();
                
                if (string.IsNullOrWhiteSpace(CollectionName))
                {
                    MessageBox.Show("Vui lòng nhập tên collection mới!", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }
            else
            {
                CreateNewCollection = false;
                CollectionName = CollectionComboBox.SelectedItem.ToString() ?? "";
            }

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void CollectionComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            NewCollectionPanel.Visibility = CollectionComboBox.SelectedIndex == 0 ? Visibility.Visible : Visibility.Collapsed;
        }
    }
}
