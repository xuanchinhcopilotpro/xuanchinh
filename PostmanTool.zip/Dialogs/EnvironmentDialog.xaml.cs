using System.Windows;
using PostmanTool.Models;
using SysEnv = System.Environment;

namespace PostmanTool.Dialogs
{
    public partial class EnvironmentDialog : Window
    {
        public Models.Environment? SelectedEnvironment { get; private set; }
        private List<Models.Environment> _environments;

        public EnvironmentDialog(List<Models.Environment> environments)
        {
            InitializeComponent();
            _environments = environments;
            LoadEnvironments();
        }

        private void LoadEnvironments()
        {
            EnvironmentListBox.Items.Clear();
            foreach (var env in _environments)
            {
                EnvironmentListBox.Items.Add($"{env.Name} ({env.Variables.Count} vars)");
            }
        }

        private void NewEnvironmentButton_Click(object sender, RoutedEventArgs e)
        {
            var newEnv = new Models.Environment { Name = $"Environment {_environments.Count + 1}" };
            _environments.Add(newEnv);
            LoadEnvironments();
            EnvironmentListBox.SelectedIndex = _environments.Count - 1;
        }

        private void DeleteEnvironmentButton_Click(object sender, RoutedEventArgs e)
        {
            if (EnvironmentListBox.SelectedIndex >= 0)
            {
                var result = MessageBox.Show("Bạn có chắc muốn xóa environment này?", 
                    "Xác nhận", MessageBoxButton.YesNo, MessageBoxImage.Question);
                
                if (result == MessageBoxResult.Yes)
                {
                    _environments.RemoveAt(EnvironmentListBox.SelectedIndex);
                    LoadEnvironments();
                    VariablesDataGrid.ItemsSource = null;
                }
            }
        }

        private void EnvironmentListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (EnvironmentListBox.SelectedIndex >= 0 && EnvironmentListBox.SelectedIndex < _environments.Count)
            {
                var env = _environments[EnvironmentListBox.SelectedIndex];
                EnvNameTextBox.Text = env.Name;
                
                var varList = env.Variables.Select(kvp => new EnvironmentVariable 
                { 
                    Key = kvp.Key, 
                    Value = kvp.Value 
                }).ToList();
                
                VariablesDataGrid.ItemsSource = varList;
            }
        }

        private void AddVariableButton_Click(object sender, RoutedEventArgs e)
        {
            if (VariablesDataGrid.ItemsSource is List<EnvironmentVariable> vars)
            {
                vars.Add(new EnvironmentVariable { Key = "", Value = "" });
                VariablesDataGrid.Items.Refresh();
            }
        }

        private void SelectButton_Click(object sender, RoutedEventArgs e)
        {
            if (EnvironmentListBox.SelectedIndex >= 0)
            {
                var env = _environments[EnvironmentListBox.SelectedIndex];
                
                // Update name
                env.Name = EnvNameTextBox.Text.Trim();
                
                // Update variables
                if (VariablesDataGrid.ItemsSource is List<EnvironmentVariable> vars)
                {
                    env.Variables.Clear();
                    foreach (var v in vars.Where(v => !string.IsNullOrWhiteSpace(v.Key)))
                    {
                        env.Variables[v.Key] = v.Value;
                    }
                }
                
                SelectedEnvironment = env;
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một environment!", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }

    public class EnvironmentVariable
    {
        public string Key { get; set; } = "";
        public string Value { get; set; } = "";
    }
}
