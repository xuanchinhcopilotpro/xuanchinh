using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace PostmanTool.Services
{
    public class EnvironmentService
    {
        private Dictionary<string, string> _activeVariables = new();

        public void SetActiveEnvironment(Dictionary<string, string> variables)
        {
            _activeVariables = new Dictionary<string, string>(variables);
        }

        public void ClearActiveEnvironment()
        {
            _activeVariables.Clear();
        }

        public string ReplaceVariables(string input)
        {
            if (string.IsNullOrWhiteSpace(input) || _activeVariables.Count == 0)
                return input;

            // Replace {{variableName}} with actual values
            var result = input;
            var matches = Regex.Matches(input, @"\{\{([^}]+)\}\}");

            foreach (Match match in matches)
            {
                var variableName = match.Groups[1].Value.Trim();
                if (_activeVariables.TryGetValue(variableName, out var value))
                {
                    result = result.Replace(match.Value, value);
                }
            }

            return result;
        }

        public List<string> GetVariableNames()
        {
            return _activeVariables.Keys.ToList();
        }

        public bool HasActiveEnvironment()
        {
            return _activeVariables.Count > 0;
        }

        public Dictionary<string, string> GetActiveVariables()
        {
            return new Dictionary<string, string>(_activeVariables);
        }
    }
}
