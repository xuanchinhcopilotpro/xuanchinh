using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace PostmanTool.Services
{
    public class CurlParser
    {
        public static CurlParseResult Parse(string curlCommand)
        {
            var result = new CurlParseResult();

            try
            {
                // Save original for body extraction
                string originalCommand = curlCommand;
                
                // Normalize line breaks and trim for parsing (but keep original for body)
                curlCommand = curlCommand.Replace("\r\n", "\n").Replace("\\\n", " ").Trim();
                
                // Remove "curl" command if present
                if (curlCommand.StartsWith("curl ", StringComparison.OrdinalIgnoreCase))
                {
                    curlCommand = curlCommand.Substring(5).Trim();
                    originalCommand = originalCommand.Substring(originalCommand.IndexOf("curl", StringComparison.OrdinalIgnoreCase) + 4).Trim();
                }
                else if (curlCommand.StartsWith("curl", StringComparison.OrdinalIgnoreCase))
                {
                    curlCommand = curlCommand.Substring(4).Trim();
                    originalCommand = originalCommand.Substring(originalCommand.IndexOf("curl", StringComparison.OrdinalIgnoreCase) + 4).Trim();
                }

                // Normalize for parsing (collapse spaces but preserve newlines in data)
                string normalizedForParsing = Regex.Replace(curlCommand, @"[ \t]+", " ");
                
                System.Diagnostics.Debug.WriteLine("=== cURL Parser Debug ===");
                System.Diagnostics.Debug.WriteLine($"Normalized command: {normalizedForParsing.Substring(0, Math.Min(200, normalizedForParsing.Length))}...");

                // Extract URL - try multiple patterns
                string url = ExtractUrl(normalizedForParsing);
                if (!string.IsNullOrWhiteSpace(url))
                {
                    result.Url = url;
                    System.Diagnostics.Debug.WriteLine($"URL: {url}");
                }

                // Extract method (-X or --request or --location implies GET by default)
                var methodMatch = Regex.Match(normalizedForParsing, @"(?:-X|--request)\s+['""]?(\w+)['""]?", RegexOptions.IgnoreCase);
                if (methodMatch.Success)
                {
                    result.Method = methodMatch.Groups[1].Value.ToUpper();
                }
                else
                {
                    // Check if there's form data or body data
                    if (Regex.IsMatch(normalizedForParsing, @"(?:--form|-F|--data-urlencode)", RegexOptions.IgnoreCase))
                    {
                        result.Method = "POST";
                    }
                    else if (Regex.IsMatch(normalizedForParsing, @"(?:-d|--data|--data-raw|--data-binary)", RegexOptions.IgnoreCase))
                    {
                        result.Method = "POST";
                    }
                    else
                    {
                        result.Method = "GET";
                    }
                }
                System.Diagnostics.Debug.WriteLine($"Method: {result.Method}");

                // Extract form data FIRST (--form or -F) - to know which headers to skip
                // Handle both: --form 'key=value' and --form 'key="value"'
                var formMatches = Regex.Matches(normalizedForParsing,
                    @"(?:--form|-F)\s+['""](\w+)=['""]([^'""]+)['""]",
                    RegexOptions.IgnoreCase);
                
                // Track form field names to skip them from headers
                var formFieldNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                
                if (formMatches.Count > 0)
                {
                    // Build form body as URL-encoded format (standard for OAuth)
                    var formPairs = new List<string>();
                    foreach (Match match in formMatches)
                    {
                        string key = match.Groups[1].Value.Trim();
                        string value = match.Groups[2].Value.Trim();
                        
                        formFieldNames.Add(key);
                        
                        // URL encode the value
                        string encodedValue = Uri.EscapeDataString(value);
                        formPairs.Add($"{key}={encodedValue}");
                        System.Diagnostics.Debug.WriteLine($"Form field: {key} = {value}");
                    }
                    
                    // Join with & for URL-encoded format
                    result.Body = string.Join("&", formPairs);
                    System.Diagnostics.Debug.WriteLine($"Form body (URL-encoded): {result.Body}");
                    
                    // Add Content-Type header if not present
                    if (!result.Headers.Any(h => h.Key.Equals("Content-Type", StringComparison.OrdinalIgnoreCase)))
                    {
                        result.Headers.Add(new KeyValuePair<string, string>("Content-Type", "application/x-www-form-urlencoded"));
                    }
                }
                else
                {
                    // Check for --data-urlencode (URL-encoded form data)
                    var dataUrlencodeMatches = Regex.Matches(normalizedForParsing,
                        @"--data-urlencode\s+['""]([^=]+)=([^'""]+)['""]",
                        RegexOptions.IgnoreCase);
                    
                    if (dataUrlencodeMatches.Count > 0)
                    {
                        // Build URL-encoded body from --data-urlencode fields
                        var dataPairs = new List<string>();
                        foreach (Match match in dataUrlencodeMatches)
                        {
                            string key = match.Groups[1].Value.Trim();
                            string value = match.Groups[2].Value.Trim();
                            
                            // URL encode both key and value
                            string encodedKey = Uri.EscapeDataString(key);
                            string encodedValue = Uri.EscapeDataString(value);
                            dataPairs.Add($"{encodedKey}={encodedValue}");
                            System.Diagnostics.Debug.WriteLine($"Data-urlencode field: {key} = {value}");
                        }
                        
                        result.Body = string.Join("&", dataPairs);
                        System.Diagnostics.Debug.WriteLine($"Data-urlencode body: {result.Body}");
                        System.Diagnostics.Debug.WriteLine($"Total fields parsed: {dataUrlencodeMatches.Count}");
                    }
                    else
                    {
                        // Extract regular data/body (-d, --data, --data-raw) if no form data
                        // Use ORIGINAL command to preserve newlines in JSON
                        string body = ExtractBody(originalCommand);
                        if (!string.IsNullOrWhiteSpace(body))
                        {
                            result.Body = body;
                            System.Diagnostics.Debug.WriteLine($"Body: {body.Substring(0, Math.Min(100, body.Length))}...");
                        }
                    }
                }

                // Extract headers (-H or --header) - AFTER we know form fields
                var headerMatches = Regex.Matches(normalizedForParsing, 
                    @"(?:-H|--header)\s+['""]([^'""]+?)['""]", 
                    RegexOptions.IgnoreCase);
                foreach (Match match in headerMatches)
                {
                    string headerLine = match.Groups[1].Value.Trim();
                    var headerParts = headerLine.Split(new[] { ':' }, 2);
                    if (headerParts.Length == 2)
                    {
                        string key = headerParts[0].Trim();
                        string value = headerParts[1].Trim();
                        
                        // Skip if it's a form field (OAuth params like client_id, grant_type should be in body, not headers)
                        if (!formFieldNames.Contains(key) && !key.Contains("="))
                        {
                            result.Headers.Add(new KeyValuePair<string, string>(key, value));
                            System.Diagnostics.Debug.WriteLine($"Header: {key} = {value}");
                        }
                        else if (formFieldNames.Contains(key))
                        {
                            System.Diagnostics.Debug.WriteLine($"Skipped header (is form field): {key}");
                        }
                    }
                }

                result.Success = !string.IsNullOrWhiteSpace(result.Url);
                
                if (!result.Success)
                {
                    result.ErrorMessage = "Không tìm thấy URL trong cURL command";
                }
                
                System.Diagnostics.Debug.WriteLine($"Parse result: Success={result.Success}, Headers={result.Headers.Count}, Body length={result.Body?.Length ?? 0}");
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = ex.Message;
            }

            return result;
        }

        private static string ExtractUrl(string curlCommand)
        {
            // Try --location 'url' first
            var locationMatch = Regex.Match(curlCommand, @"--location\s+['""]([^'""]+)['""]");
            if (locationMatch.Success)
            {
                return locationMatch.Groups[1].Value;
            }

            // Try quoted URL
            var quotedUrlMatch = Regex.Match(curlCommand, @"['""]((https?://[^""']+))['""]");
            if (quotedUrlMatch.Success && quotedUrlMatch.Groups[1].Value.Contains("://"))
            {
                return quotedUrlMatch.Groups[1].Value;
            }

            // Try URL without quotes
            var urlMatch = Regex.Match(curlCommand, @"(https?://[^\s'""]+)");
            if (urlMatch.Success)
            {
                return urlMatch.Groups[1].Value;
            }

            return "";
        }

        private static string ExtractBody(string curlCommand)
        {
            // Try to find --data-raw '...' or --data-raw "..." or -d "..."
            // First, find the flag position
            var flagMatch = Regex.Match(curlCommand, @"(--data-raw|--data-binary|--data|-d)\s+", RegexOptions.IgnoreCase);
            
            if (!flagMatch.Success)
            {
                return "";
            }

            int startPos = flagMatch.Index + flagMatch.Length;
            
            // Check what quote type is used
            if (startPos >= curlCommand.Length)
            {
                return "";
            }

            char quoteChar = curlCommand[startPos];
            
            if (quoteChar == '\'' || quoteChar == '"')
            {
                // Find matching closing quote, skipping escaped quotes
                int currentPos = startPos + 1;
                bool foundClosing = false;
                
                while (currentPos < curlCommand.Length)
                {
                    if (curlCommand[currentPos] == quoteChar)
                    {
                        // Check if it's escaped
                        int backslashCount = 0;
                        int checkPos = currentPos - 1;
                        
                        while (checkPos >= 0 && curlCommand[checkPos] == '\\')
                        {
                            backslashCount++;
                            checkPos--;
                        }
                        
                        // If even number of backslashes (or zero), quote is NOT escaped
                        if (backslashCount % 2 == 0)
                        {
                            foundClosing = true;
                            break;
                        }
                    }
                    currentPos++;
                }
                
                if (foundClosing && currentPos > startPos)
                {
                    string body = curlCommand.Substring(startPos + 1, currentPos - startPos - 1);
                    
                    // Un-escape the body (remove backslashes before quotes)
                    body = body.Replace("\\\"", "\"").Replace("\\'", "'");
                    
                    // Log for debugging
                    System.Diagnostics.Debug.WriteLine($"Body extracted: {body.Length} chars");
                    System.Diagnostics.Debug.WriteLine($"First 100 chars: {body.Substring(0, Math.Min(100, body.Length))}");
                    
                    return body;
                }
            }
            else
            {
                // No quotes, get until next space or end
                var match = Regex.Match(curlCommand.Substring(startPos), @"^([^\s]+)");
                if (match.Success)
                {
                    return match.Groups[1].Value;
                }
            }

            return "";
        }
    }

    public class CurlParseResult
    {
        public bool Success { get; set; }
        public string Url { get; set; } = "";
        public string Method { get; set; } = "GET";
        public List<KeyValuePair<string, string>> Headers { get; set; } = new();
        public string Body { get; set; } = "";
        public string ErrorMessage { get; set; } = "";
    }
}
