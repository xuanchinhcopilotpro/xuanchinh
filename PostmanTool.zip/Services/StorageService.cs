using System;
using System.IO;
using Newtonsoft.Json;
using PostmanTool.Models;

namespace PostmanTool.Services
{
    public class StorageService
    {
        private static readonly string AppDataFolder = Path.Combine(
            System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData),
            "PostmanTool"
        );
        
        private static readonly string DataFile = Path.Combine(AppDataFolder, "data.json");

        public StorageService()
        {
            if (!Directory.Exists(AppDataFolder))
            {
                Directory.CreateDirectory(AppDataFolder);
            }
        }

        public AppData LoadData()
        {
            try
            {
                if (File.Exists(DataFile))
                {
                    var json = File.ReadAllText(DataFile);
                    return JsonConvert.DeserializeObject<AppData>(json) ?? new AppData();
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading data: {ex.Message}");
            }

            return new AppData();
        }

        public void SaveData(AppData data)
        {
            try
            {
                var json = JsonConvert.SerializeObject(data, Formatting.Indented);
                File.WriteAllText(DataFile, json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error saving data: {ex.Message}");
                throw;
            }
        }

        public string GetDataFilePath() => DataFile;
    }
}
