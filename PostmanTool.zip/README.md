# 🚀 Postman-Like API Testing Tool - WPF GUI

Công cụ test API với giao diện đồ họa đầy đủ giống Postman, được viết bằng C# WPF.

## ✨ Tính năng

### Core Features
- ✅ **Giao diện GUI đẹp mắt**: Thiết kế trực quan, dễ sử dụng như Postman
- ✅ **Hỗ trợ đầy đủ HTTP Methods**: GET, POST, PUT, DELETE, PATCH
- ✅ **Headers Management**: Thêm, xóa, bật/tắt headers trong DataGrid
- ✅ **Request Body Editor**: Hỗ trợ JSON và text thuần
- ✅ **JSON Formatter**: Tự động format JSON đẹp với 1 click
- ✅ **Response Viewer**: Hiển thị response với auto-format
- ✅ **Status & Timing**: Theo dõi status code và response time
- ✅ **Authentication Helper**: Nhanh chóng thêm Bearer Token hoặc API Key
- ✅ **Split Panel**: Chia đôi màn hình Request/Response dễ theo dõi

## 🎨 Giao diện

### Các thành phần chính:
- **URL Bar**: Chọn method (GET/POST/PUT/DELETE/PATCH) và nhập endpoint
- **Left Panel**: 
  - Tab Headers: Quản lý headers với checkbox enable/disable
  - Tab Body: Editor cho request body với format JSON
- **Right Panel**: Response viewer với status bar và clear button
- **Status Bar**: Hiển thị tips và trạng thái

## 🛠️ Cài đặt

### Yêu cầu
- .NET 8.0 SDK hoặc cao hơn
- Windows OS (WPF chỉ chạy trên Windows)

### Build & Run

```powershell
# Restore packages
dotnet restore

# Build
dotnet build

# Run
dotnet run
```

## 📖 Hướng dẫn sử dụng

### 1. Gửi GET Request
1. Chọn **GET** từ dropdown
2. Nhập URL: `https://jsonplaceholder.typicode.com/posts/1`
3. Click **Send**
4. Xem response ở panel bên phải

### 2. Gửi POST Request với JSON
1. Chọn **POST** từ dropdown
2. Nhập URL: `https://jsonplaceholder.typicode.com/posts`
3. Vào tab **Body**
4. Nhập JSON:
```json
{
  "title": "My Post",
  "body": "This is content",
  "userId": 1
}
```
5. Click **✨ Format JSON** để beautify
6. Click **Send**

### 3. Quản lý Headers
1. Vào tab **📋 Headers**
2. Click **➕ Add Header**
3. Nhập Key (vd: `Content-Type`) và Value (vd: `application/json`)
4. Check/uncheck để enable/disable header
5. Click **➖ Remove** để xóa header đang chọn

### 4. Sử dụng Authentication
1. Click **🔐 Auth** button
2. Chọn loại:
   - **Bearer Token**: Cho OAuth/JWT
   - **API Key**: Cho API key custom
3. Nhập token
4. Click OK → Header tự động được thêm

## 🧪 API Test Examples

### JSONPlaceholder (Free Test API)

**GET:**
```
URL: https://jsonplaceholder.typicode.com/users
Method: GET
```

**POST:**
```
URL: https://jsonplaceholder.typicode.com/posts
Method: POST
Body:
{
  "title": "foo",
  "body": "bar", 
  "userId": 1
}
```

**PUT:**
```
URL: https://jsonplaceholder.typicode.com/posts/1
Method: PUT
```

**DELETE:**
```
URL: https://jsonplaceholder.typicode.com/posts/1
Method: DELETE
```

## 🏗️ Cấu trúc Project

```
PostmanTool/
├── PostmanTool.csproj    # WPF Project file
├── App.xaml              # Application styles
├── App.xaml.cs           # App startup
├── MainWindow.xaml       # Main UI
├── MainWindow.xaml.cs    # Main logic
├── AuthDialog.xaml       # Auth dialog UI
├── AuthDialog.xaml.cs    # Auth dialog logic
└── README.md
```

## 💡 Tips

- **Format JSON**: Luôn format JSON trước khi gửi để dễ debug
- **Toggle Headers**: Không cần xóa header, chỉ uncheck để tắt tạm thời
- **Auth Button**: Nhanh chóng thêm authentication mà không cần nhập tay
- **Copy Response**: Ctrl+A, Ctrl+C để copy toàn bộ response

## 🎯 Tính năng mở rộng

- [ ] Request Collections & Save
- [ ] Environment Variables {{var}}
- [ ] Request History
- [ ] Export/Import Postman format
- [ ] Multiple request tabs
- [ ] Code generation
- [ ] File upload support
- [ ] OAuth 2.0 flow
- [ ] WebSocket testing
- [ ] GraphQL support
- [ ] Dark theme

## 📝 License

MIT License - Free to use and modify

---

**Enjoy testing your APIs!** 🚀
