# Test cURL Commands

## Test 1: Simple GET
```bash
curl 'https://jsonplaceholder.typicode.com/posts/1'
```

## Test 2: GET with Headers
```bash
curl 'https://jsonplaceholder.typicode.com/posts/1' -H 'Accept: application/json' -H 'User-Agent: MyApp/1.0'
```

## Test 3: POST with JSON Body
```bash
curl -X POST 'https://jsonplaceholder.typicode.com/posts' -H 'Content-Type: application/json' -d '{"title": "foo", "body": "bar", "userId": 1}'
```

## Test 4: POST (Chrome DevTools format)
```bash
curl 'https://jsonplaceholder.typicode.com/posts' \
  -H 'Content-Type: application/json' \
  --data-raw '{"title":"My Post","body":"Content here","userId":1}'
```

## Test 5: PUT Request
```bash
curl -X PUT 'https://jsonplaceholder.typicode.com/posts/1' \
  -H 'Content-Type: application/json' \
  -d '{"id": 1, "title": "updated", "body": "updated body", "userId": 1}'
```

## Test 6: DELETE Request
```bash
curl -X DELETE 'https://jsonplaceholder.typicode.com/posts/1'
```

## Test 7: With Authorization Header
```bash
curl 'https://api.github.com/user' \
  -H 'Authorization: Bearer YOUR_TOKEN_HERE' \
  -H 'Accept: application/vnd.github+json'
```

## Test 8: Complex POST from browser
```bash
curl 'https://httpbin.org/post' \
  -H 'Content-Type: application/json' \
  -H 'Accept: */*' \
  -H 'User-Agent: Mozilla/5.0' \
  --data-raw '{"name":"John","email":"john@example.com"}'
```

---

## Hướng dẫn test:

1. Copy một trong các cURL command trên
2. Mở ứng dụng
3. Click button "Import cURL"
4. Paste vào text box
5. Click "Import"
6. Kiểm tra:
   - URL đã được điền
   - Method đã chọn đúng
   - Headers xuất hiện trong tab Headers
   - Body xuất hiện trong tab Body (nếu có)

## Tips:

- Copy cURL từ Chrome DevTools: F12 → Network → Right-click request → Copy → Copy as cURL
- Copy cURL từ Firefox: F12 → Network → Right-click → Copy → Copy as cURL
- Copy cURL từ Postman: Click Code → cURL

## Nếu vẫn không work:

1. Check Output window trong VS Code để xem debug log
2. MessageBox sẽ hiển thị chi tiết parse result
3. Kiểm tra xem có lỗi gì trong error message
