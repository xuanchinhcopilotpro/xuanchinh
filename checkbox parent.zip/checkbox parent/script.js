// Sample data structure
let records = [
    {
        id: 1,
        isParent: true,
        billingContent: '1. Khám bệnh',
        claimBenefit: 'Emergency due to accident',
        quantity: 1,
        healthInsurance: 6000000,
        patientPaid: 6000000,
        confidence: 0.5,
        decision: 'accept',
        declineReason: ''
    },
    {
        id: 2,
        isParent: false,
        billingContent: 'Khám bệnh cấp cứu',
        claimBenefit: 'Emergency due to accident',
        quantity: 1,
        healthInsurance: 6000000,
        patientPaid: 6000000,
        confidence: 0.5,
        decision: 'accept',
        declineReason: ''
    },
    {
        id: 3,
        isParent: true,
        billingContent: '2. Ngày giường',
        claimBenefit: 'Hospital Daily Room & Board',
        quantity: 1,
        healthInsurance: 6000000,
        patientPaid: 6000000,
        confidence: 0.5,
        decision: 'decline',
        declineReason: ''
    },
    {
        id: 4,
        isParent: false,
        billingContent: 'Phòng đôi - máy lạnh',
        claimBenefit: 'Hospital Daily Room & Board',
        quantity: 1,
        healthInsurance: 6000000,
        patientPaid: 6000000,
        confidence: 0.5,
        decision: 'accept',
        declineReason: ''
    },
    {
        id: 5,
        isParent: false,
        billingContent: 'Giường dành cho người thân',
        claimBenefit: 'Miscellaneous Expenses',
        quantity: 1,
        healthInsurance: 6000000,
        patientPaid: 6000000,
        confidence: 0.5,
        decision: 'decline',
        declineReason: '001 - Không nằm trong phạm vi cho phép'
    },
    {
        id: 6,
        isParent: true,
        billingContent: '3. Xét nghiệm',
        claimBenefit: 'Medication and medical supplied cost',
        quantity: 1,
        healthInsurance: 6000000,
        patientPaid: 6000000,
        confidence: 0.5,
        decision: 'accept',
        declineReason: ''
    },
    {
        id: 7,
        isParent: false,
        billingContent: 'Xét nghiệm máu',
        claimBenefit: 'Miscellaneous Expenses',
        quantity: 1,
        healthInsurance: 6000000,
        patientPaid: 6000000,
        confidence: 0.5,
        decision: 'accept',
        declineReason: ''
    },
    {
        id: 8,
        isParent: true,
        billingContent: '4. Chuẩn đoán hình ảnh',
        claimBenefit: 'Diagnosis imaging cost',
        quantity: 1,
        healthInsurance: 6000000,
        patientPaid: 6000000,
        confidence: 0.5,
        decision: 'accept',
        declineReason: ''
    },
    {
        id: 9,
        isParent: false,
        billingContent: 'Chụp X-Quang',
        claimBenefit: 'Miscellaneous Expenses',
        quantity: 1,
        healthInsurance: 6000000,
        patientPaid: 6000000,
        confidence: 0.0,
        decision: 'decline',
        declineReason: '000 - Lý do khác - cần nhập freetext'
    },
    {
        id: 10,
        isParent: false,
        billingContent: 'Chụp MRI',
        claimBenefit: 'Miscellaneous Expenses',
        quantity: 1,
        healthInsurance: 6000000,
        patientPaid: 6000000,
        confidence: 0.5,
        decision: 'accept',
        declineReason: ''
    },
    {
        id: 11,
        isParent: false,
        billingContent: 'Xạ cấp cứu',
        claimBenefit: 'Miscellaneous Expenses',
        quantity: 1,
        healthInsurance: 6000000,
        patientPaid: 6000000,
        confidence: 0.5,
        decision: 'accept',
        declineReason: ''
    }
];

// Render the table
function renderTable() {
    const tbody = document.getElementById('recordList');
    tbody.innerHTML = '';
    
    // Sort records: parents first, then their children
    const sortedRecords = sortRecords(records);
    
    sortedRecords.forEach((record, index) => {
        const row = createRow(record, index);
        tbody.appendChild(row);
    });
}

// Sort records to group parents and children together
function sortRecords(records) {
    const sorted = [];
    const processed = new Set();
    
    records.forEach((record, idx) => {
        if (processed.has(idx)) return;
        
        if (record.isParent) {
            sorted.push(record);
            processed.add(idx);
            
            // Find children that follow this parent
            for (let i = idx + 1; i < records.length; i++) {
                if (records[i].isParent) break;
                if (!processed.has(i)) {
                    sorted.push(records[i]);
                    processed.add(i);
                }
            }
        }
    });
    
    // Add any remaining records (orphaned children)
    records.forEach((record, idx) => {
        if (!processed.has(idx)) {
            sorted.push(record);
        }
    });
    
    return sorted;
}

// Create a table row
function createRow(record, index) {
    const tr = document.createElement('tr');
    tr.className = record.isParent ? 'parent-row' : 'child-row';
    tr.dataset.id = record.id;
    
    tr.innerHTML = `
        <td>
            <input type="checkbox" class="row-select">
        </td>
        <td>${record.billingContent}</td>
        <td>
            <select onchange="updateRecord(${record.id}, 'claimBenefit', this.value)">
                <option value="Emergency due to accident" ${record.claimBenefit === 'Emergency due to accident' ? 'selected' : ''}>Emergency due to accident</option>
                <option value="Hospital Daily Room & Board" ${record.claimBenefit === 'Hospital Daily Room & Board' ? 'selected' : ''}>Hospital Daily Room & Board</option>
                <option value="Miscellaneous Expenses" ${record.claimBenefit === 'Miscellaneous Expenses' ? 'selected' : ''}>Miscellaneous Expenses</option>
                <option value="Medication and medical supplied cost" ${record.claimBenefit === 'Medication and medical supplied cost' ? 'selected' : ''}>Medication and medical supplied cost</option>
                <option value="Diagnosis imaging cost" ${record.claimBenefit === 'Diagnosis imaging cost' ? 'selected' : ''}>Diagnosis imaging cost</option>
            </select>
        </td>
        <td>
            <input type="number" value="${record.quantity}" 
                   onchange="updateRecord(${record.id}, 'quantity', this.value)">
        </td>
        <td>
            <input type="text" value="${formatNumber(record.healthInsurance)}" 
                   onchange="updateRecord(${record.id}, 'healthInsurance', parseNumber(this.value))">
        </td>
        <td>
            <input type="text" value="${formatNumber(record.patientPaid)}" 
                   onchange="updateRecord(${record.id}, 'patientPaid', parseNumber(this.value))">
        </td>
        <td>
            <span class="confidence-badge ${record.confidence > 0.3 ? 'confidence-high' : 'confidence-low'}">
                ${record.confidence.toFixed(1)}
            </span>
        </td>
        <td>
            <div class="decision-toggle">
                <div class="toggle-switch ${record.decision === 'accept' ? 'active' : ''}" 
                     onclick="toggleDecision(${record.id})">
                </div>
                <span>${record.decision === 'accept' ? 'Accept' : 'Decline'}</span>
            </div>
        </td>
        <td>
            <input type="text" class="decline-input" value="${record.declineReason}" 
                   placeholder="${record.decision === 'decline' ? 'Nhập lý do...' : ''}"
                   ${record.decision === 'accept' ? 'disabled' : ''}
                   onchange="updateRecord(${record.id}, 'declineReason', this.value)">
        </td>
        <td style="text-align: center;">
            <input type="checkbox" class="parent-checkbox" 
                   ${record.isParent ? 'checked' : ''} 
                   onchange="toggleParentStatus(${record.id}, this.checked)">
        </td>
        <td style="text-align: center;">
            <button class="action-btn add-btn" onclick="addRow(${record.id})" title="Thêm">+</button>
            <button class="action-btn delete-btn" onclick="deleteRow(${record.id})" title="Xóa">🗑</button>
        </td>
    `;
    
    return tr;
}

// Toggle parent/child status
function toggleParentStatus(id, isParent) {
    const record = records.find(r => r.id === id);
    if (record) {
        record.isParent = isParent;
        renderTable();
        
        // Show notification
        showNotification(isParent ? 
            `"${record.billingContent}" đã được đổi thành Parent` : 
            `"${record.billingContent}" đã được đổi thành Child`
        );
    }
}

// Toggle decision (Accept/Decline)
function toggleDecision(id) {
    const record = records.find(r => r.id === id);
    if (record) {
        record.decision = record.decision === 'accept' ? 'decline' : 'accept';
        if (record.decision === 'accept') {
            record.declineReason = '';
        }
        renderTable();
    }
}

// Update record field
function updateRecord(id, field, value) {
    const record = records.find(r => r.id === id);
    if (record) {
        record[field] = value;
        if (field === 'healthInsurance' || field === 'patientPaid') {
            updateTotals();
        }
    }
}

// Add new row
function addRow(afterId) {
    const index = records.findIndex(r => r.id === afterId);
    const newId = Math.max(...records.map(r => r.id)) + 1;
    
    const newRecord = {
        id: newId,
        isParent: false,
        billingContent: 'New item',
        claimBenefit: 'Miscellaneous Expenses',
        quantity: 1,
        healthInsurance: 0,
        patientPaid: 0,
        confidence: 0.5,
        decision: 'accept',
        declineReason: ''
    };
    
    records.splice(index + 1, 0, newRecord);
    renderTable();
    updateTotals();
    showNotification('Đã thêm record mới');
}

// Delete row
function deleteRow(id) {
    if (confirm('Bạn có chắc muốn xóa record này?')) {
        records = records.filter(r => r.id !== id);
        renderTable();
        updateTotals();
        showNotification('Đã xóa record');
    }
}

// Format number with commas
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// Parse number from formatted string
function parseNumber(str) {
    return parseInt(str.replace(/,/g, '')) || 0;
}

// Update totals
function updateTotals() {
    const totalHealth = records.reduce((sum, r) => sum + r.healthInsurance, 0);
    const totalPatient = records.reduce((sum, r) => sum + r.patientPaid, 0);
    
    document.getElementById('totalHealth').textContent = formatNumber(totalHealth);
    document.getElementById('totalPatient').textContent = formatNumber(totalPatient);
}

// Show notification
function showNotification(message) {
    // Simple alert for now - you can implement a better notification system
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #4CAF50;
        color: white;
        padding: 15px 20px;
        border-radius: 4px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        z-index: 1000;
        animation: slideIn 0.3s ease-out;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 2000);
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    renderTable();
    updateTotals();
});
