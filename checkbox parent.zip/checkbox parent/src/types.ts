export interface Record {
  id: number;
  isParent: boolean;
  billingContent: string;
  claimBenefit: string;
  quantity: number;
  healthInsurance: number;
  patientPaid: number;
  confidence: number;
  decision: 'accept' | 'decline';
  declineReason: string;
}

export type ClaimBenefitType = 
  | 'Emergency due to accident'
  | 'Hospital Daily Room & Board'
  | 'Miscellaneous Expenses'
  | 'Medication and medical supplied cost'
  | 'Diagnosis imaging cost';
