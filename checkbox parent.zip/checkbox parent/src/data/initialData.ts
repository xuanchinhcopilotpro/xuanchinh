import { Record } from '../types';

export const initialRecords: Record[] = [
  {
    id: 1,
    isParent: true,
    billingContent: '1. Khám bệnh',
    claimBenefit: 'Emergency due to accident',
    quantity: 1,
    healthInsurance: 6000000,
    patientPaid: 6000000,
    confidence: 0.5,
    decision: 'accept',
    declineReason: ''
  },
  {
    id: 2,
    isParent: false,
    billingContent: 'Khám bệnh cấp cứu',
    claimBenefit: 'Emergency due to accident',
    quantity: 1,
    healthInsurance: 6000000,
    patientPaid: 6000000,
    confidence: 0.5,
    decision: 'accept',
    declineReason: ''
  },
  {
    id: 3,
    isParent: true,
    billingContent: '2. Ngày giường',
    claimBenefit: 'Hospital Daily Room & Board',
    quantity: 1,
    healthInsurance: 6000000,
    patientPaid: 6000000,
    confidence: 0.5,
    decision: 'decline',
    declineReason: ''
  },
  {
    id: 4,
    isParent: false,
    billingContent: 'Phòng đôi - máy lạnh',
    claimBenefit: 'Hospital Daily Room & Board',
    quantity: 1,
    healthInsurance: 6000000,
    patientPaid: 6000000,
    confidence: 0.5,
    decision: 'accept',
    declineReason: ''
  },
  {
    id: 5,
    isParent: false,
    billingContent: 'Giường dành cho người thân',
    claimBenefit: 'Miscellaneous Expenses',
    quantity: 1,
    healthInsurance: 6000000,
    patientPaid: 6000000,
    confidence: 0.5,
    decision: 'decline',
    declineReason: '001 - Không nằm trong phạm vi cho phép'
  },
  {
    id: 6,
    isParent: true,
    billingContent: '3. Xét nghiệm',
    claimBenefit: 'Medication and medical supplied cost',
    quantity: 1,
    healthInsurance: 6000000,
    patientPaid: 6000000,
    confidence: 0.5,
    decision: 'accept',
    declineReason: ''
  },
  {
    id: 7,
    isParent: false,
    billingContent: 'Xét nghiệm máu',
    claimBenefit: 'Miscellaneous Expenses',
    quantity: 1,
    healthInsurance: 6000000,
    patientPaid: 6000000,
    confidence: 0.5,
    decision: 'accept',
    declineReason: ''
  },
  {
    id: 8,
    isParent: true,
    billingContent: '4. Chuẩn đoán hình ảnh',
    claimBenefit: 'Diagnosis imaging cost',
    quantity: 1,
    healthInsurance: 6000000,
    patientPaid: 6000000,
    confidence: 0.5,
    decision: 'accept',
    declineReason: ''
  },
  {
    id: 9,
    isParent: false,
    billingContent: 'Chụp X-Quang',
    claimBenefit: 'Miscellaneous Expenses',
    quantity: 1,
    healthInsurance: 6000000,
    patientPaid: 6000000,
    confidence: 0.0,
    decision: 'decline',
    declineReason: '000 - Lý do khác - cần nhập freetext'
  },
  {
    id: 10,
    isParent: false,
    billingContent: 'Chụp MRI',
    claimBenefit: 'Miscellaneous Expenses',
    quantity: 1,
    healthInsurance: 6000000,
    patientPaid: 6000000,
    confidence: 0.5,
    decision: 'accept',
    declineReason: ''
  },
  {
    id: 11,
    isParent: false,
    billingContent: 'Xạ cấp cứu',
    claimBenefit: 'Miscellaneous Expenses',
    quantity: 1,
    healthInsurance: 6000000,
    patientPaid: 6000000,
    confidence: 0.5,
    decision: 'accept',
    declineReason: ''
  }
];
