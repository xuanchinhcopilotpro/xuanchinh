import { RecordTable } from './components/RecordTable';
import './App.css';

function App() {
  return <RecordTable />;
}

export default App;
