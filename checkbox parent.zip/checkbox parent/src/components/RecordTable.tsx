import React, { useState } from 'react';
import { Record } from '../types';
import { RecordRow } from './RecordRow';
import { sortRecords, calculateTotals, formatNumber } from '../utils/recordUtils';
import { initialRecords } from '../data/initialData';
import './RecordTable.css';

export const RecordTable: React.FC = () => {
  const [records, setRecords] = useState<Record[]>(initialRecords);
  const [notification, setNotification] = useState<string>('');

  const showNotification = (message: string) => {
    setNotification(message);
    setTimeout(() => setNotification(''), 2000);
  };

  const handleUpdate = (id: number, field: keyof Record, value: any) => {
    setRecords((prev) =>
      prev.map((record) => (record.id === id ? { ...record, [field]: value } : record))
    );
  };

  const handleToggleParent = (id: number, isParent: boolean) => {
    setRecords((prev) => {
      const updated = prev.map((record) =>
        record.id === id ? { ...record, isParent } : record
      );
      const record = prev.find((r) => r.id === id);
      if (record) {
        showNotification(
          isParent
            ? `"${record.billingContent}" đã được đổi thành Parent`
            : `"${record.billingContent}" đã được đổi thành Child`
        );
      }
      return updated;
    });
  };

  const handleToggleDecision = (id: number) => {
    setRecords((prev) =>
      prev.map((record) =>
        record.id === id
          ? {
              ...record,
              decision: record.decision === 'accept' ? 'decline' : 'accept',
              declineReason: record.decision === 'accept' ? record.declineReason : '',
            }
          : record
      )
    );
  };

  const handleAdd = (afterId: number) => {
    const index = records.findIndex((r) => r.id === afterId);
    const newId = Math.max(...records.map((r) => r.id)) + 1;

    const newRecord: Record = {
      id: newId,
      isParent: false,
      billingContent: 'New item',
      claimBenefit: 'Miscellaneous Expenses',
      quantity: 1,
      healthInsurance: 0,
      patientPaid: 0,
      confidence: 0.5,
      decision: 'accept',
      declineReason: '',
    };

    setRecords((prev) => [...prev.slice(0, index + 1), newRecord, ...prev.slice(index + 1)]);
    showNotification('Đã thêm record mới');
  };

  const handleDelete = (id: number) => {
    if (confirm('Bạn có chắc muốn xóa record này?')) {
      setRecords((prev) => prev.filter((r) => r.id !== id));
      showNotification('Đã xóa record');
    }
  };

  const sortedRecords = sortRecords(records);
  const totals = calculateTotals(records);

  return (
    <div className="container">
      <h1>Quản lý Parent-Child Records</h1>

      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th style={{ width: '40px' }}></th>
              <th style={{ width: '300px' }}>Billing Content</th>
              <th style={{ width: '200px' }}>Claim Benefit</th>
              <th style={{ width: '100px' }}>Quantity</th>
              <th style={{ width: '150px' }}>Health Insurance Paid Amount</th>
              <th style={{ width: '150px' }}>Patient Paid Amount</th>
              <th style={{ width: '120px' }}>Confidence Rate</th>
              <th style={{ width: '120px' }}>Decision</th>
              <th style={{ width: '200px' }}>Decline Reason</th>
              <th style={{ width: '80px' }}>Is Parent</th>
              <th style={{ width: '80px' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {sortedRecords.map((record) => (
              <RecordRow
                key={record.id}
                record={record}
                onUpdate={handleUpdate}
                onToggleParent={handleToggleParent}
                onToggleDecision={handleToggleDecision}
                onAdd={handleAdd}
                onDelete={handleDelete}
              />
            ))}
          </tbody>
        </table>
      </div>

      <div className="total-row">
        <span>Total Amount</span>
        <span>{formatNumber(totals.healthInsurance)}</span>
        <span>{formatNumber(totals.patientPaid)}</span>
      </div>

      {notification && <div className="notification">{notification}</div>}
    </div>
  );
};
