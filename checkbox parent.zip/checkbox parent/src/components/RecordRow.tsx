import React from 'react';
import { Record, ClaimBenefitType } from '../types';
import { formatNumber, parseNumber } from '../utils/recordUtils';
import './RecordRow.css';

interface RecordRowProps {
  record: Record;
  onUpdate: (id: number, field: keyof Record, value: any) => void;
  onToggleParent: (id: number, isParent: boolean) => void;
  onToggleDecision: (id: number) => void;
  onAdd: (id: number) => void;
  onDelete: (id: number) => void;
}

const claimBenefitOptions: ClaimBenefitType[] = [
  'Emergency due to accident',
  'Hospital Daily Room & Board',
  'Miscellaneous Expenses',
  'Medication and medical supplied cost',
  'Diagnosis imaging cost'
];

export const RecordRow: React.FC<RecordRowProps> = ({
  record,
  onUpdate,
  onToggleParent,
  onToggleDecision,
  onAdd,
  onDelete,
}) => {
  return (
    <tr className={record.isParent ? 'parent-row' : 'child-row'}>
      <td>
        <input type="checkbox" className="row-select" />
      </td>
      <td>{record.billingContent}</td>
      <td>
        <select
          value={record.claimBenefit}
          onChange={(e) => onUpdate(record.id, 'claimBenefit', e.target.value)}
        >
          {claimBenefitOptions.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      </td>
      <td>
        <input
          type="number"
          value={record.quantity}
          onChange={(e) => onUpdate(record.id, 'quantity', parseInt(e.target.value))}
        />
      </td>
      <td>
        <input
          type="text"
          value={formatNumber(record.healthInsurance)}
          onChange={(e) => onUpdate(record.id, 'healthInsurance', parseNumber(e.target.value))}
        />
      </td>
      <td>
        <input
          type="text"
          value={formatNumber(record.patientPaid)}
          onChange={(e) => onUpdate(record.id, 'patientPaid', parseNumber(e.target.value))}
        />
      </td>
      <td>
        <span className={`confidence-badge ${record.confidence > 0.3 ? 'confidence-high' : 'confidence-low'}`}>
          {record.confidence.toFixed(1)}
        </span>
      </td>
      <td>
        <div className="decision-toggle">
          <div
            className={`toggle-switch ${record.decision === 'accept' ? 'active' : ''}`}
            onClick={() => onToggleDecision(record.id)}
          />
          <span>{record.decision === 'accept' ? 'Accept' : 'Decline'}</span>
        </div>
      </td>
      <td>
        <input
          type="text"
          className="decline-input"
          value={record.declineReason}
          placeholder={record.decision === 'decline' ? 'Nhập lý do...' : ''}
          disabled={record.decision === 'accept'}
          onChange={(e) => onUpdate(record.id, 'declineReason', e.target.value)}
        />
      </td>
      <td style={{ textAlign: 'center' }}>
        <input
          type="checkbox"
          className="parent-checkbox"
          checked={record.isParent}
          onChange={(e) => onToggleParent(record.id, e.target.checked)}
        />
      </td>
      <td style={{ textAlign: 'center' }}>
        <button className="action-btn add-btn" onClick={() => onAdd(record.id)} title="Thêm">
          +
        </button>
        <button className="action-btn delete-btn" onClick={() => onDelete(record.id)} title="Xóa">
          🗑
        </button>
      </td>
    </tr>
  );
};
