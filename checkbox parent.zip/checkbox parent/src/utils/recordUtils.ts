import { Record } from '../types';

export const sortRecords = (records: Record[]): Record[] => {
  const sorted: Record[] = [];
  const processed = new Set<number>();
  
  records.forEach((record, idx) => {
    if (processed.has(idx)) return;
    
    if (record.isParent) {
      sorted.push(record);
      processed.add(idx);
      
      // Find children that follow this parent
      for (let i = idx + 1; i < records.length; i++) {
        if (records[i].isParent) break;
        if (!processed.has(i)) {
          sorted.push(records[i]);
          processed.add(i);
        }
      }
    }
  });
  
  // Add any remaining records (orphaned children)
  records.forEach((record, idx) => {
    if (!processed.has(idx)) {
      sorted.push(record);
    }
  });
  
  return sorted;
};

export const formatNumber = (num: number): string => {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
};

export const parseNumber = (str: string): number => {
  return parseInt(str.replace(/,/g, '')) || 0;
};

export const calculateTotals = (records: Record[]) => {
  return records.reduce(
    (acc, record) => ({
      healthInsurance: acc.healthInsurance + record.healthInsurance,
      patientPaid: acc.patientPaid + record.patientPaid,
    }),
    { healthInsurance: 0, patientPaid: 0 }
  );
};
