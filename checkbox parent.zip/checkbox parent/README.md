# Parent-Child Records Management

Ứng dụng quản lý Parent-Child Records được xây dựng bằng **React + TypeScript + Vite**.

## 🚀 Công nghệ sử dụng

- **React 18.3** - Thư viện UI hiện đại
- **TypeScript 5.5** - Type safety và IntelliSense
- **Vite 5.4** - Build tool cực nhanh
- **CSS Modules** - Styling components

## ✨ Tính năng

1. **Phân biệt Parent-Child:**
   - Record Parent: nền màu xám, font đậm
   - Record Child: nền màu trắng, thụt lề 40px

2. **Checkbox Parent/Child:**
   - Tick checkbox = Parent record
   - Bỏ tick = Child record
   - Tự động sắp xếp lại khi thay đổi

3. **Chức năng khác:**
   - Toggle Accept/Decline
   - Thêm/Xóa records
   - Tính tổng tự động
   - Notifications khi thay đổi

## 📦 Cài đặt

```bash
# Cài đặt dependencies
npm install

# Chạy development server
npm run dev

# Build cho production
npm run build

# Preview production build
npm run preview
```

## 🏗️ Cấu trúc thư mục

```
src/
├── components/
│   ├── RecordRow.tsx       # Component cho mỗi dòng
│   ├── RecordRow.css       # Styles cho RecordRow
│   ├── RecordTable.tsx     # Component chính quản lý bảng
│   └── RecordTable.css     # Styles cho RecordTable
├── data/
│   └── initialData.ts      # Dữ liệu mẫu ban đầu
├── utils/
│   └── recordUtils.ts      # Utility functions
├── types.ts                # TypeScript type definitions
├── App.tsx                 # Root component
├── App.css                 # Global styles
└── main.tsx               # Entry point
```

## 🎯 Sử dụng

1. Chạy `npm install` để cài đặt dependencies
2. Chạy `npm run dev` để khởi động development server
3. Mở trình duyệt tại `http://localhost:5173`

## 💡 Ưu điểm của stack này

- ⚡ **Cực nhanh:** Vite HMR siêu tốc
- 🔒 **Type-safe:** TypeScript giúp tránh bugs
- 🎨 **Component-based:** Code dễ maintain
- 📦 **Modern:** Sử dụng công nghệ mới nhất 2024-2025
- 🔧 **Developer Experience:** IntelliSense, auto-complete tuyệt vời
