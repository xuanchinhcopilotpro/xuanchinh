// src/api/d365CustomActions.ts
// Định nghĩa các custom action names và cấu trúc payload cho Dynamics 365

// ==================== CUSTOM ACTION NAMES ====================
export const D365_CUSTOM_ACTIONS = {
  // Group Management
  GET_GROUPS: 'getGroups',
  UPSERT_GROUPS: 'upsertGroups',
  DELETE_GROUPS: 'deleteGroups',
  
  // Benefit Management
  GET_BENEFITS: 'getBenefits',
  UPSERT_BENEFITS: 'upsertBenefits',
  DELETE_BENEFITS: 'deleteBenefits',
  
  // User Management
  GET_USERS: 'getUsers',
  UPSERT_USERS: 'upsertUsers',
  DELETE_USERS: 'deleteUsers',
} as const;

// ==================== PAYLOAD STRUCTURES ====================

// Generic inner payload structure as requested by user
export interface GenericInnerPayload {
  id?: string;
  GROUP_ID?: string;
  GroupName?: string;
  priority?: number;
  benefiT_CODE?: string;
  sub_BENEFIT?: number;
  useR_CODE?: string;
  match?: number;
  Cases?: number;
  masterDataLogicalName?: string;
  actionName: string; // This will contain action types like 'create', 'update', 'delete', 'getAll', 'getById', 'getByGroupId'
  idDelete?: string[];
}

// Base payload structure
export interface D365Payload {
  logicalName: string;
  payLoad: GenericInnerPayload;
}

// Group Management Payloads
export interface GroupGetAllPayload extends D365Payload {
  logicalName: 'group_management';
  payLoad: GenericInnerPayload & {
    actionName: 'getAll';
  };
}

export interface GroupGetByIdPayload extends D365Payload {
  logicalName: 'group_management';
  payLoad: GenericInnerPayload & {
    actionName: 'getById';
    id: string;
  };
}

export interface GroupCreatePayload extends D365Payload {
  logicalName: 'group_management';
  payLoad: GenericInnerPayload & {
    actionName: 'create';
    GroupName: string;
    priority: number;
    masterDataLogicalName: 'group_management';
  };
}

export interface GroupUpdatePayload extends D365Payload {
  logicalName: 'group_management';
  payLoad: GenericInnerPayload & {
    actionName: 'update';
    id: string;
    GroupName?: string;
    priority?: number;
    masterDataLogicalName: 'group_management';
  };
}

export interface GroupDeletePayload extends D365Payload {
  logicalName: 'group_management';
  payLoad: GenericInnerPayload & {
    actionName: 'delete';
    id: string;
    masterDataLogicalName: 'group_management';
  };
}

// Benefit Management Payloads
export interface BenefitGetByGroupIdPayload extends D365Payload {
  logicalName: 'benefit_management';
  payLoad: GenericInnerPayload & {
    actionName: 'getByGroupId';
    GROUP_ID: string;
    masterDataLogicalName: 'benefit_management';
  };
}

export interface BenefitCreatePayload extends D365Payload {
  logicalName: 'benefit_management';
  payLoad: GenericInnerPayload & {
    actionName: 'create';
    GROUP_ID: string;
    benefiT_CODE: string;
    sub_BENEFIT: number;
    masterDataLogicalName: 'benefit_management';
  };
}

export interface BenefitUpdatePayload extends D365Payload {
  logicalName: 'benefit_management';
  payLoad: GenericInnerPayload & {
    actionName: 'update';
    id: string;
    GROUP_ID?: string;
    benefiT_CODE?: string;
    sub_BENEFIT?: number;
    masterDataLogicalName: 'benefit_management';
  };
}

export interface BenefitDeletePayload extends D365Payload {
  logicalName: 'benefit_management';
  payLoad: GenericInnerPayload & {
    actionName: 'delete';
    id: string;
    masterDataLogicalName: 'benefit_management';
  };
}

// User Management Payloads
export interface UserGetByGroupIdPayload extends D365Payload {
  logicalName: 'user_management';
  payLoad: GenericInnerPayload & {
    actionName: 'getByGroupId';
    GROUP_ID: string;
    masterDataLogicalName: 'user_management';
  };
}

export interface UserCreatePayload extends D365Payload {
  logicalName: 'user_management';
  payLoad: GenericInnerPayload & {
    actionName: 'create';
    GROUP_ID: string;
    useR_CODE: string;
    Cases: number;
    match: number;
    masterDataLogicalName: 'user_management';
  };
}

export interface UserUpdatePayload extends D365Payload {
  logicalName: 'user_management';
  payLoad: GenericInnerPayload & {
    actionName: 'update';
    id: string;
    GROUP_ID?: string;
    useR_CODE?: string;
    Cases?: number;
    match?: number;
    masterDataLogicalName: 'user_management';
  };
}

export interface UserDeletePayload extends D365Payload {
  logicalName: 'user_management';
  payLoad: GenericInnerPayload & {
    actionName: 'delete';
    id: string;
    masterDataLogicalName: 'user_management';
  };
}

// Union type cho tất cả payload types
export type D365PayloadType = 
  | GroupGetAllPayload
  | GroupGetByIdPayload
  | GroupCreatePayload
  | GroupUpdatePayload
  | GroupDeletePayload
  | BenefitGetByGroupIdPayload
  | BenefitCreatePayload
  | BenefitUpdatePayload
  | BenefitDeletePayload
  | UserGetByGroupIdPayload
  | UserCreatePayload
  | UserUpdatePayload
  | UserDeletePayload;

// ==================== HELPER FUNCTIONS ====================

// Helper function để tạo payload cho Group operations
export const createGroupPayload = {
  getAll: (): GroupGetAllPayload => ({
    logicalName: 'group_management',
    payLoad: { 
      actionName: 'getAll',
      masterDataLogicalName: 'group_management'
    }
  }),
  
  getById: (groupId: string): GroupGetByIdPayload => ({
    logicalName: 'group_management',
    payLoad: { 
      actionName: 'getById', 
      id: groupId,
      masterDataLogicalName: 'group_management'
    }
  }),
  
  create: (groupData: { groupName: string; assignmentPriority: number }): GroupCreatePayload => ({
    logicalName: 'group_management',
    payLoad: { 
      actionName: 'create', 
      GroupName: groupData.groupName,
      priority: groupData.assignmentPriority,
      masterDataLogicalName: 'group_management'
    }
  }),
  
  update: (groupId: string, groupData: Partial<{ groupName: string; assignmentPriority: number }>): GroupUpdatePayload => ({
    logicalName: 'group_management',
    payLoad: { 
      actionName: 'update', 
      id: groupId, 
      ...(groupData.groupName && { GroupName: groupData.groupName }),
      ...(groupData.assignmentPriority !== undefined && { priority: groupData.assignmentPriority }),
      masterDataLogicalName: 'group_management'
    }
  }),
  
  delete: (groupId: string): GroupDeletePayload => ({
    logicalName: 'group_management',
    payLoad: { 
      actionName: 'delete', 
      id: groupId,
      masterDataLogicalName: 'group_management'
    }
  })
};

// Helper function để tạo payload cho Benefit operations
export const createBenefitPayload = {
  getByGroupId: (groupId: string): BenefitGetByGroupIdPayload => ({
    logicalName: 'benefit_management',
    payLoad: { 
      actionName: 'getByGroupId', 
      GROUP_ID: groupId,
      masterDataLogicalName: 'benefit_management'
    }
  }),
  
  create: (benefitData: { cr350_name: string; cr350_code: string; subBenefit: number; groupId: string }): BenefitCreatePayload => ({
    logicalName: 'benefit_management',
    payLoad: { 
      actionName: 'create', 
      GROUP_ID: benefitData.groupId,
      benefiT_CODE: benefitData.cr350_code,
      sub_BENEFIT: benefitData.subBenefit,
      masterDataLogicalName: 'benefit_management'
    }
  }),
  
  update: (benefitId: string, benefitData: Partial<{ cr350_code: string; subBenefit: number; groupId: string }>): BenefitUpdatePayload => ({
    logicalName: 'benefit_management',
    payLoad: { 
      actionName: 'update', 
      id: benefitId,
      ...(benefitData.groupId && { GROUP_ID: benefitData.groupId }),
      ...(benefitData.cr350_code && { benefiT_CODE: benefitData.cr350_code }),
      ...(benefitData.subBenefit !== undefined && { sub_BENEFIT: benefitData.subBenefit }),
      masterDataLogicalName: 'benefit_management'
    }
  }),
  
  delete: (benefitId: string): BenefitDeletePayload => ({
    logicalName: 'benefit_management',
    payLoad: { 
      actionName: 'delete', 
      id: benefitId,
      masterDataLogicalName: 'benefit_management'
    }
  })
};

// Helper function để tạo payload cho User operations
export const createUserPayload = {
  getByGroupId: (groupId: string): UserGetByGroupIdPayload => ({
    logicalName: 'user_management',
    payLoad: { 
      actionName: 'getByGroupId', 
      GROUP_ID: groupId,
      masterDataLogicalName: 'user_management'
    }
  }),
  
  create: (userData: { userCode: string; cases: number; ratio: number; groupId: string }): UserCreatePayload => ({
    logicalName: 'user_management',
    payLoad: { 
      actionName: 'create', 
      GROUP_ID: userData.groupId,
      useR_CODE: userData.userCode,
      Cases: userData.cases,
      match: userData.ratio,
      masterDataLogicalName: 'user_management'
    }
  }),
  
  update: (userId: string, userData: Partial<{ userCode: string; cases: number; ratio: number; groupId: string }>): UserUpdatePayload => ({
    logicalName: 'user_management',
    payLoad: { 
      actionName: 'update', 
      id: userId,
      ...(userData.groupId && { GROUP_ID: userData.groupId }),
      ...(userData.userCode && { useR_CODE: userData.userCode }),
      ...(userData.cases !== undefined && { Cases: userData.cases }),
      ...(userData.ratio !== undefined && { match: userData.ratio }),
      masterDataLogicalName: 'user_management'
    }
  }),
  
  delete: (userId: string): UserDeletePayload => ({
    logicalName: 'user_management',
    payLoad: { 
      actionName: 'delete', 
      id: userId,
      masterDataLogicalName: 'user_management'
    }
  })
};
