import { Group, Benefit, User, SystemUser, ApiError } from '../models/types.ts';
import { 
  D365_CUSTOM_ACTIONS, 
  createGroupPayload, 
  createBenefitPayload, 
  createUserPayload 
} from './d365CustomActions.ts';

// Cấu hình API
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:3001/api';
const D365_API_BASE_URL = process.env.REACT_APP_D365_API_BASE_URL || 'https://org176b616e.crm5.dynamics.com/api/data/v9.2';

// Token configuration - có thể thay đổi token ở đây hoặc qua environment variable
const getToken = (): string => {
  // Ưu tiên lấy từ environment variable
  const envToken = process.env.REACT_APP_D365_TOKEN;
  if (envToken) {
    return envToken;
  }
  return 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IkpZaEFjVFBNWl9MWDZEQmxPV1E3SG4wTmVYRSIsImtpZCI6IkpZaEFjVFBNWl9MWDZEQmxPV1E3SG4wTmVYRSJ9.eyJhdWQiOiJodHRwczovL29yZzE3NmI2MTZlLmNybTUuZHluYW1pY3MuY29tIiwiaXNzIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvYTQyOGRmN2ItZTg2Ny00Y2JiLTk1ZWYtNjEyY2M4NDg4NWM0LyIsImlhdCI6MTc1NDg0NzUxMSwibmJmIjoxNzU0ODQ3NTExLCJleHAiOjE3NTQ4NTE0MTEsImFpbyI6ImsyUmdZRmpSdzJIclBuZitRYlBvTDAwSzY1MllBQT09IiwiYXBwaWQiOiI2MDc1NDM3ZC1hYTk4LTRjZDctYjlmYS0yZWMwZGI2NDFhOWIiLCJhcHBpZGFjciI6IjEiLCJpZHAiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9hNDI4ZGY3Yi1lODY3LTRjYmItOTVlZi02MTJjYzg0ODg1YzQvIiwiaWR0eXAiOiJhcHAiLCJvaWQiOiJiODRmYWIxOS1hZDBkLTQ1MDktYjdkOC00MjgzNzYzMjczMzMiLCJyaCI6IjEuQVhFQWU5OG9wR2ZvdTB5VjcyRXN5RWlGeEFjQUFBQUFBQUFBd0FBQUFBQUFBQUF6QVFCeEFBLiIsInN1YiI6ImI4NGZhYjE5LWFkMGQtNDUwOS1iN2Q4LTQyODM3NjMyNzMzMyIsInRlbmFudF9yZWdpb25fc2NvcGUiOiJBUyIsInRpZCI6ImE0MjhkZjdiLWU4NjctNGNiYi05NWVmLTYxMmNjODQ4ODVjNCIsInV0aSI6InlLdFJ6MXBkLVVTczhULVE3QnBFQUEiLCJ2ZXIiOiIxLjAiLCJ4bXNfZnRkIjoiVVNVeFI1VER4RkNVR1Q1Z1BTSG9ZOFZIdlQwSGNZSGs0WXRpVHQ0UWxZVUJhMjl5WldGemIzVjBhQzFrYzIxeiIsInhtc19pZHJlbCI6IjcgMTAiLCJ4bXNfcmQiOiIwLjQyTGxZQkppTEJRUzRXQVhFcmhVNGFlWnJfekZzZDNZUU9wOWEtQkZvQ2lua01ERFFyNnExbjhQM0phZE9pRHJNX0g2RGFBb2g1QUFPd01FSElEU0FBIn0.oO-EJAZ6Dws6l5nuuls-yjsiS4KZYj9w7YSRW_VHCXuEchLDaEeXcL-WJxXpfSKBBvChGvjut6BXyWJYzP_rCLPBuaWqCl4noMQoCYQRU0X_3Gm93odQuiCYeLX_00jcCeIuc3R5k2AQWueydwJt9RlyPc7wBny5GzjILxL_QWQFn1cueZeQ9Cm38H-PQAWWoMy6VH4r7HRUzh2Bmvd1XsBvmFi5K5-xFTce1gczroAFXql-epyXr77UKvi43jG49vrNJq18GiwI4kC15v2DXKh8R-3Bf8WkZllGRs4byNaQK4QxtWedlzQYN5om0NFAyWMQFH3VOeGqqFNdSMClcg';
};

// Helper function để xử lý Dynamics 365 response
const handleD365Response = async <T>(response: Response): Promise<T> => {
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const apiError: ApiError = {
      message: errorData.error?.message || `HTTP error! status: ${response.status}`,
      status: response.status,
    };
    throw apiError;
  }
  
  // Dynamics 365 trả về data trực tiếp, không có wrapper
  const data = await response.json();
  return data.value || data; // D365 thường wrap data trong 'value' property
};

// Helper function để xử lý External API response
const handleExternalResponse = async <T>(response: Response): Promise<T> => {
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const apiError: ApiError = {
      message: errorData.message || `HTTP error! status: ${response.status}`,
      status: response.status,
    };
    throw apiError;
  }
  
  const data = await response.json();
  return data.data || data; // External API thường wrap data trong 'data' property
};

// Helper function để tạo request options cho D365
const createD365RequestOptions = (method: string, body?: any): RequestInit => {
  const token = getToken();
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'OData-MaxVersion': '4.0',
      'OData-Version': '4.0',
      'Accept': 'application/json',
    },
  };
  
  if (body) {
    options.body = JSON.stringify(body);
  }
  
  return options;
};

// Helper function để tạo request options cho External API
const createExternalRequestOptions = (method: string, body?: any): RequestInit => {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
  };
  
  if (body) {
    options.body = JSON.stringify(body);
  }
  
  return options;
};

// ==================== D365 CUSTOM ACTION APIs ====================

// Helper function để gọi custom action của D365
const callD365CustomAction = async <T>(actionName: string, payload: any): Promise<T> => {
  // Cấu trúc payload theo yêu cầu của D365 custom action
  const requestPayload = {
    requestName: actionName,
    data: payload
  };

  const options = createD365RequestOptions('POST', requestPayload);
  // Sử dụng endpoint trực tiếp cho custom action
  const response = await fetch(`${D365_API_BASE_URL}/${actionName}`, options);
  return handleD365Response<T>(response);
};

// ==================== D365 APIs (CHO LOOKUP FIELDS) ====================

// SystemUser API functions - D365
export const systemUserApi = {
  // Lấy danh sách tất cả system users từ D365
  getAll: async (): Promise<SystemUser[]> => {
    try {
      const options = createD365RequestOptions('GET');
      const response = await fetch(`${D365_API_BASE_URL}/systemusers?$select=systemuserid,fullname,employeeid`, options);
      const data = await handleD365Response<any[]>(response);
      
      // Map D365 fields to our interface
      return data.map(user => ({
        id: user.systemuserid, // Map systemuserid to id
        fullname: user.fullname,
        userCode: user.employeeid || user.systemuserid, // Use employeeid or fallback to systemuserid
      }));
    } catch (error) {
      console.error('Error fetching system users, falling back to mock data:', error);
      // Fallback to mock data if D365 API fails
      return (await import('./mockApiService.ts')).mockSystemUserApi.getAll();
    }
  },

  // Lấy chi tiết một system user theo ID từ D365
  getById: async (id: string | number): Promise<SystemUser> => {
    try {
      const options = createD365RequestOptions('GET');
      const response = await fetch(`${D365_API_BASE_URL}/systemusers(${id})?$select=systemuserid,fullname,employeeid`, options);
      const data = await handleD365Response<any>(response);
      
      // Map D365 fields to our interface
      return {
        id: data.systemuserid, // Map systemuserid to id
        fullname: data.fullname,
        userCode: data.employeeid || data.systemuserid, // Use employeeid or fallback to systemuserid
      };
    } catch (error) {
      console.error('Error fetching system user, falling back to mock data:', error);
      // Fallback to mock data if D365 API fails
      return (await import('./mockApiService.ts')).mockSystemUserApi.getById(id);
    }
  },
};

// Benefit lookup API functions - D365
export const benefitLookupApi = {
  // Lấy danh sách tất cả benefits từ D365 (cho lookup)
  getAll: async (): Promise<Benefit[]> => {
    const options = createD365RequestOptions('GET');
    const response = await fetch(`${D365_API_BASE_URL}/cr350_benefits?$top=1000`, options);
    return handleD365Response<Benefit[]>(response);
  },
};

// ==================== D365 CUSTOM ACTION APIs (CHO SUBGRID DATA) ====================

// Group API functions - D365 Custom Action
export const groupApi = {
  // Lấy danh sách tất cả groups
  getAll: async (): Promise<Group[]> => {
    const payload = createGroupPayload.getAll();
    return callD365CustomAction<Group[]>(D365_CUSTOM_ACTIONS.GET_GROUPS, payload);
  },

  // Lấy chi tiết một group theo ID
  getById: async (id: string | number): Promise<Group> => {
    const payload = createGroupPayload.getById(String(id));
    return callD365CustomAction<Group>(D365_CUSTOM_ACTIONS.GET_GROUPS, payload);
  },

  // Tạo mới group
  create: async (group: Omit<Group, 'id'>): Promise<Group> => {
    const payload = createGroupPayload.create(group);
    return callD365CustomAction<Group>(D365_CUSTOM_ACTIONS.UPSERT_GROUPS, payload);
  },

  // Cập nhật group
  update: async (id: string | number, group: Partial<Group>): Promise<Group> => {
    const payload = createGroupPayload.update(String(id), group);
    return callD365CustomAction<Group>(D365_CUSTOM_ACTIONS.UPSERT_GROUPS, payload);
  },

  // Xóa group
  delete: async (id: string | number): Promise<void> => {
    const payload = createGroupPayload.delete(String(id));
    return callD365CustomAction<void>(D365_CUSTOM_ACTIONS.DELETE_GROUPS, payload);
  },
};

// Benefit API functions - D365 Custom Action (cho subgrid)
export const benefitApi = {
  // Lấy danh sách benefits của một group
  getByGroupId: async (groupId: string | number): Promise<Benefit[]> => {
    const payload = createBenefitPayload.getByGroupId(String(groupId));
    return callD365CustomAction<Benefit[]>(D365_CUSTOM_ACTIONS.GET_BENEFITS, payload);
  },

  // Tạo mới benefit
  create: async (benefit: Omit<Benefit, 'id'>): Promise<Benefit> => {
    // Đảm bảo cr350_code có giá trị
    if (!benefit.cr350_code) {
      throw new Error('cr350_code is required for benefit creation');
    }
    const payload = createBenefitPayload.create({
      cr350_name: benefit.cr350_name,
      cr350_code: benefit.cr350_code,
      subBenefit: benefit.subBenefit || 0,
      groupId: String(benefit.groupId)
    });
    return callD365CustomAction<Benefit>(D365_CUSTOM_ACTIONS.UPSERT_BENEFITS, payload);
  },

  // Cập nhật benefit
  update: async (id: string | number, benefit: Partial<Benefit>): Promise<Benefit> => {
    const updateData: Partial<{ cr350_code: string; subBenefit: number; groupId: string }> = {};
    
    if (benefit.cr350_code) updateData.cr350_code = benefit.cr350_code;
    if (benefit.subBenefit !== undefined) updateData.subBenefit = benefit.subBenefit;
    if (benefit.groupId) updateData.groupId = String(benefit.groupId);
    
    const payload = createBenefitPayload.update(String(id), updateData);
    return callD365CustomAction<Benefit>(D365_CUSTOM_ACTIONS.UPSERT_BENEFITS, payload);
  },

  // Xóa benefit
  delete: async (id: string | number): Promise<void> => {
    const payload = createBenefitPayload.delete(String(id));
    return callD365CustomAction<void>(D365_CUSTOM_ACTIONS.DELETE_BENEFITS, payload);
  },
};

// User API functions - D365 Custom Action (cho subgrid)
export const userApi = {
  // Lấy danh sách users của một group
  getByGroupId: async (groupId: string | number): Promise<User[]> => {
    const payload = createUserPayload.getByGroupId(String(groupId));
    return callD365CustomAction<User[]>(D365_CUSTOM_ACTIONS.GET_USERS, payload);
  },

  // Tạo mới user
  create: async (user: Omit<User, 'id'>): Promise<User> => {
    const payload = createUserPayload.create({
      userCode: user.userCode,
      cases: user.cases,
      ratio: user.ratio,
      groupId: String(user.groupId)
    });
    return callD365CustomAction<User>(D365_CUSTOM_ACTIONS.UPSERT_USERS, payload);
  },

  // Cập nhật user
  update: async (id: string | number, user: Partial<User>): Promise<User> => {
    const updateData: Partial<{ userCode: string; cases: number; ratio: number; groupId: string }> = {};
    
    if (user.userCode) updateData.userCode = user.userCode;
    if (user.cases !== undefined) updateData.cases = user.cases;
    if (user.ratio !== undefined) updateData.ratio = user.ratio;
    if (user.groupId) updateData.groupId = String(user.groupId);
    
    const payload = createUserPayload.update(String(id), updateData);
    return callD365CustomAction<User>(D365_CUSTOM_ACTIONS.UPSERT_USERS, payload);
  },

  // Xóa user
  delete: async (id: string | number): Promise<void> => {
    const payload = createUserPayload.delete(String(id));
    return callD365CustomAction<void>(D365_CUSTOM_ACTIONS.DELETE_USERS, payload);
  },
};

// ==================== LEGACY EXTERNAL APIs (GIỮ LẠI ĐỂ TƯƠNG THÍCH) ====================

// Export default object để tương thích với code cũ
const apiClient = {
  get: async (url: string) => {
    const options = createExternalRequestOptions('GET');
    const response = await fetch(`${API_BASE_URL}${url}`, options);
    return handleExternalResponse(response);
  },
  post: async (url: string, data: any) => {
    const options = createExternalRequestOptions('POST', data);
    const response = await fetch(`${API_BASE_URL}${url}`, options);
    return handleExternalResponse(response);
  },
  put: async (url: string, data: any) => {
    const options = createExternalRequestOptions('PUT', data);
    const response = await fetch(`${API_BASE_URL}${url}`, options);
    return handleExternalResponse(response);
  },
  patch: async (url: string, data: any) => {
    const options = createExternalRequestOptions('PATCH', data);
    const response = await fetch(`${API_BASE_URL}${url}`, options);
    return handleExternalResponse(response);
  },
  delete: async (url: string) => {
    const options = createExternalRequestOptions('DELETE');
    const response = await fetch(`${API_BASE_URL}${url}`, options);
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const apiError: ApiError = {
        message: errorData.message || `HTTP error! status: ${response.status}`,
        status: response.status,
      };
      throw apiError;
    }
  },
};

export default apiClient; 