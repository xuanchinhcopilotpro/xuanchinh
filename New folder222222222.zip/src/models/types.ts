// src/models/types.ts
export interface Group {
  id: string | number;
  groupName: string;
  assignmentPriority: number;
  createdOn: string; // ISO date string
}

export interface Benefit {
  id: string | number;
  cr350_name: string; // Changed from benefitName to match D365 API
  cr350_description: string; // Changed from description to match D365 API
  cr350_legacycode?: string;
  cr350_type?: string;
  cr350_priority?: number;
  cr350_code?: string;
  subBenefit?: number; // Changed from string to number
  groupId: string | number; // Foreign key liên kết với Group
}

export interface SystemUser {
  id: string | number;
  fullname: string;
  userCode: string;
}

export interface User {
  id: string | number;
  systemUserId: string | number; // Reference to SystemUser
  fullname: string; // From SystemUser
  userCode: string; // From SystemUser
  ratio: number;
  cases: number;
  groupId: string | number; // Foreign key liên kết với Group
}

// API Response types
export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
}

export interface ApiError {
  message: string;
  status: number;
} 