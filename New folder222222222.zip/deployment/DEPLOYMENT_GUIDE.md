# 🚀 Hướng dẫn Deploy Dynamics 365 Group Management

## 📦 Files cần thiết

Trong thư mục `deployment/` bạn sẽ có:

- `main.c718c8b0.js` - JavaScript bundle (167.06 kB)
- `main.439ec562.css` - CSS bundle (342 B)
- `loader_dynamics365.html` - HTML loader cho Dynamics 365

## 🔧 Bước 1: Tạo Web Resources

### 1.1 JavaScript Web Resource

1. Vào **Settings** → **Advanced Settings** → **Customizations** → **Customize the System**
2. Tìm **Web Resources** → **New**
3. Cấu hình:
   - **Name**: `new_groupmanagement_main_js`
   - **Display Name**: `Group Management Main JS`
   - **Type**: `Script (JScript)`
   - **Upload**: File `main.c718c8b0.js`
4. **Save** và **Publish**

### 1.2 CSS Web Resource

1. **Web Resources** → **New**
2. Cấu hình:
   - **Name**: `new_groupmanagement_main_css`
   - **Display Name**: `Group Management Main CSS`
   - **Type**: `Style Sheet (CSS)`
   - **Upload**: File `main.439ec562.css`
3. **Save** và **Publish**

### 1.3 HTML Web Resource

1. **Web Resources** → **New**
2. Cấu hình:
   - **Name**: `new_groupmanagement_loader_html`
   - **Display Name**: `Group Management Loader`
   - **Type**: `Webpage (HTML)`
   - **Upload**: File `loader_dynamics365.html`
3. **Save** và **Publish**

## 🗺️ Bước 2: Thêm vào Site Map

### 2.1 Sử dụng App Designer

1. Mở **App Designer**
2. Chọn app muốn thêm
3. Vào **Site Map**
4. Thêm **Subarea** mới:
   - **Type**: `Web Resource`
   - **Web Resource**: `new_groupmanagement_loader_html`
   - **Title**: `Group Management`
   - **Icon**: Chọn icon phù hợp

### 2.2 Hoặc chỉnh sửa Site Map trực tiếp

```xml
<SubArea Id="GroupManagement" 
         Entity="" 
         Url="$webresource:new_groupmanagement_loader_html" 
         Title="Group Management" 
         Icon="$webresource:new_groupmanagement_icon" />
```

## 🔐 Bước 3: Cấu hình Security Roles

1. Vào **Settings** → **Security** → **Security Roles**
2. Chọn role cần cấp quyền
3. Tab **Customization**:
   - **Web Resources**: Read access cho 3 Web Resources vừa tạo
4. **Save** và **Close**

## 🌐 Bước 4: Cấu hình API (Production)

### 4.1 Tạo file .env cho production

```env
REACT_APP_API_BASE_URL=https://your-dynamics365-api.com/api
```

### 4.2 Update API Service

Thay đổi trong `src/api/apiService.ts`:

```typescript
// Sử dụng real API thay vì mock
import { groupApi, benefitApi, userApi } from '../api/apiService';
```

### 4.3 Build lại với production config

```bash
npm run build
```

## 🧪 Bước 5: Testing

### 5.1 Test Web Resources

1. Vào **Advanced Settings** → **Customizations** → **Web Resources**
2. Double-click vào `new_groupmanagement_loader_html`
3. Kiểm tra app load thành công

### 5.2 Test trong Site Map

1. Refresh browser
2. Vào menu mới tạo
3. Kiểm tra:
   - ✅ App load không lỗi
   - ✅ UI hiển thị đúng
   - ✅ Chức năng hoạt động
   - ✅ Responsive design

## 🐛 Troubleshooting

### Lỗi thường gặp:

#### 1. "Web Resource not found"
- **Nguyên nhân**: Tên Web Resource không đúng
- **Giải pháp**: Kiểm tra tên trong HTML loader

#### 2. "Script error" hoặc "CSS not loading"
- **Nguyên nhân**: Web Resources chưa được publish
- **Giải pháp**: Publish lại tất cả Web Resources

#### 3. "Permission denied"
- **Nguyên nhân**: User không có quyền truy cập Web Resources
- **Giải pháp**: Cấp quyền Read cho Security Role

#### 4. "API connection failed"
- **Nguyên nhân**: Sử dụng mock API hoặc URL không đúng
- **Giải pháp**: Cấu hình API endpoint production

#### 5. "Layout issues"
- **Nguyên nhân**: CSS conflicts với Dynamics 365
- **Giải pháp**: Kiểm tra CSS styles, thêm namespace

## 📱 Mobile Support

App đã được tối ưu cho:
- ✅ Desktop browsers
- ✅ Dynamics 365 Mobile app
- ✅ Tablet devices

## 🔄 Update Process

Khi cần update app:

1. Build version mới
2. Upload Web Resources mới (với tên file khác)
3. Update HTML loader để reference files mới
4. Publish và test

## 📞 Support

Nếu gặp vấn đề:
1. Kiểm tra Browser Console logs
2. Kiểm tra Network tab
3. Verify Web Resources đã publish
4. Test với user khác nhau

---

## ✅ Checklist Deploy

- [ ] JavaScript Web Resource đã upload và publish
- [ ] CSS Web Resource đã upload và publish  
- [ ] HTML Web Resource đã upload và publish
- [ ] Site Map đã cấu hình
- [ ] Security Roles đã cấp quyền
- [ ] API endpoint đã cấu hình (nếu dùng production)
- [ ] Test app hoạt động trong Dynamics 365
- [ ] Test với nhiều users/roles khác nhau
- [ ] Document lại process cho team

**🎉 Chúc mừng! App đã sẵn sàng sử dụng trong Dynamics 365!**

