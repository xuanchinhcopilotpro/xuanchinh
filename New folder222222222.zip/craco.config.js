const path = require('path');

module.exports = {
  webpack: {
    configure: (webpackConfig) => {
      // Tối ưu hóa output cho Dynamics 365
      webpackConfig.output = {
        ...webpackConfig.output,
        filename: 'static/js/[name].bundle.js',
        chunkFilename: 'static/js/[name].chunk.js',
      };

      // Tối ưu hóa CSS
      const miniCssExtractPlugin = webpackConfig.plugins.find(
        (plugin) => plugin.constructor.name === 'MiniCssExtractPlugin'
      );
      if (miniCssExtractPlugin) {
        miniCssExtractPlugin.options.filename = 'static/css/[name].bundle.css';
        miniCssExtractPlugin.options.chunkFilename = 'static/css/[name].chunk.css';
      }

      return webpackConfig;
    },
  },
  babel: {
    presets: [
      [
        '@babel/preset-env',
        {
          targets: {
            browsers: ['> 1%', 'last 2 versions', 'not ie <= 8'],
          },
        },
      ],
    ],
  },
}; 