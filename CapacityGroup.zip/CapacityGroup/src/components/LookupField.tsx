import React, { useState, useCallback } from 'react';
import {
  Combobox,
  Option,
  Field,
  Dialog,
  DialogTrigger,
  DialogSurface,
  DialogBody,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  DataGrid,
  DataGridHeader,
  DataGridRow,
  DataGridHeaderCell,
  DataGridBody,
  DataGridCell,
  TableColumnDefinition,
  createTableColumn,
  Spinner,
  MessageBar,
} from '@fluentui/react-components';
import { SearchRegular } from '@fluentui/react-icons';

interface LookupFieldProps<T> {
  label: string;
  value: T | null;
  onChange: (value: T | null) => void;
  fetchItems: () => Promise<T[]>;
  displayField: keyof T;
  columns: TableColumnDefinition<T>[];
  required?: boolean;
  disabled?: boolean;
}

const LookupField = <T extends { id: string | number }>({
  label,
  value,
  onChange,
  fetchItems,
  displayField,
  columns,
  required = false,
  disabled = false,
}: LookupFieldProps<T>) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedItem, setSelectedItem] = useState<T | null>(value);

  // Load items
  const loadItems = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchItems();
      setItems(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load items');
    } finally {
      setLoading(false);
    }
  }, [fetchItems]);

  // Handle dialog open
  const handleDialogOpen = async (open: boolean) => {
    setIsDialogOpen(open);
    if (open) {
      await loadItems();
    }
  };

  // Handle row click
  const handleRowClick = (item: T) => {
    setSelectedItem(item);
    onChange(item);
    setIsDialogOpen(false);
  };

  // Handle clear
  const handleClear = () => {
    setSelectedItem(null);
    onChange(null);
  };

  return (
    <Field
      label={label}
      required={required}
    >
      <div style={{ display: 'flex', gap: '8px' }}>
        <Dialog open={isDialogOpen} onOpenChange={(e, data) => handleDialogOpen(data.open)}>
          <DialogTrigger disableButtonEnhancement>
            <Combobox
              value={value ? String(value[displayField]) : ''}
              placeholder="Click to search..."
              style={{ flexGrow: 1 }}
              disabled={disabled}
            >
              <Option text="" value="">
                {loading ? 'Loading...' : 'Click to search...'}
              </Option>
            </Combobox>
          </DialogTrigger>
          <DialogSurface>
            <DialogBody>
              <DialogTitle>Select {label}</DialogTitle>
              <DialogContent>
                {error && (
                  <MessageBar intent="error" style={{ marginBottom: '16px' }}>
                    {error}
                  </MessageBar>
                )}

                {loading ? (
                  <div style={{ display: 'flex', justifyContent: 'center', padding: '20px' }}>
                    <Spinner size="medium" label="Loading..." />
                  </div>
                ) : (
                  <DataGrid
                    items={items}
                    columns={columns}
                    selectionMode="single"
                    onRowClick={(event, data) => handleRowClick(data.item)}
                    style={{ height: '400px' }}
                  >
                    <DataGridHeader>
                      <DataGridRow>
                        {({ renderHeaderCell }) => (
                          <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                        )}
                      </DataGridRow>
                    </DataGridHeader>
                    <DataGridBody>
                      {({ item, rowId }) => (
                        <DataGridRow key={rowId}>
                          {({ renderCell }) => (
                            <DataGridCell>{renderCell(item)}</DataGridCell>
                          )}
                        </DataGridRow>
                      )}
                    </DataGridBody>
                  </DataGrid>
                )}
              </DialogContent>
              <DialogActions>
                <Button appearance="secondary" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
              </DialogActions>
            </DialogBody>
          </DialogSurface>
        </Dialog>
        <Button
          icon={<SearchRegular />}
          onClick={() => setIsDialogOpen(true)}
          disabled={disabled}
        />
        {value && (
          <Button
            onClick={handleClear}
            disabled={disabled}
          >
            Clear
          </Button>
        )}
      </div>
    </Field>
  );
};

export default LookupField;