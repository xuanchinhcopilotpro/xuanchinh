import axios, { AxiosResponse } from 'axios';
import { Group, Benefit, User, ApiResponse, ApiError } from '../models/types.ts';

// Cấu hình axios
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:3001/api';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor để xử lý lỗi
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const apiError: ApiError = {
      message: error.response?.data?.message || 'An error occurred',
      status: error.response?.status || 500,
    };
    return Promise.reject(apiError);
  }
);

// Group API functions
export const groupApi = {
  // Lấy danh sách tất cả groups
  getAll: async (): Promise<Group[]> => {
    const response: AxiosResponse<ApiResponse<Group[]>> = await apiClient.get('/groups');
    return response.data.data;
  },

  // Lấy chi tiết một group theo ID
  getById: async (id: string | number): Promise<Group> => {
    const response: AxiosResponse<ApiResponse<Group>> = await apiClient.get(`/groups/${id}`);
    return response.data.data;
  },

  // Tạo mới group
  create: async (group: Omit<Group, 'id'>): Promise<Group> => {
    const response: AxiosResponse<ApiResponse<Group>> = await apiClient.post('/groups', group);
    return response.data.data;
  },

  // Cập nhật group
  update: async (id: string | number, group: Partial<Group>): Promise<Group> => {
    const response: AxiosResponse<ApiResponse<Group>> = await apiClient.put(`/groups/${id}`, group);
    return response.data.data;
  },

  // Xóa group
  delete: async (id: string | number): Promise<void> => {
    await apiClient.delete(`/groups/${id}`);
  },
};

// Benefit API functions
export const benefitApi = {
  // Lấy danh sách benefits của một group
  getByGroupId: async (groupId: string | number): Promise<Benefit[]> => {
    const response: AxiosResponse<ApiResponse<Benefit[]>> = await apiClient.get(`/groups/${groupId}/benefits`);
    return response.data.data;
  },

  // Tạo mới benefit
  create: async (benefit: Omit<Benefit, 'id'>): Promise<Benefit> => {
    const response: AxiosResponse<ApiResponse<Benefit>> = await apiClient.post('/benefits', benefit);
    return response.data.data;
  },

  // Cập nhật benefit
  update: async (id: string | number, benefit: Partial<Benefit>): Promise<Benefit> => {
    const response: AxiosResponse<ApiResponse<Benefit>> = await apiClient.put(`/benefits/${id}`, benefit);
    return response.data.data;
  },

  // Xóa benefit
  delete: async (id: string | number): Promise<void> => {
    await apiClient.delete(`/benefits/${id}`);
  },
};

// User API functions
export const userApi = {
  // Lấy danh sách users của một group
  getByGroupId: async (groupId: string | number): Promise<User[]> => {
    const response: AxiosResponse<ApiResponse<User[]>> = await apiClient.get(`/groups/${groupId}/users`);
    return response.data.data;
  },

  // Tạo mới user
  create: async (user: Omit<User, 'id'>): Promise<User> => {
    const response: AxiosResponse<ApiResponse<User>> = await apiClient.post('/users', user);
    return response.data.data;
  },

  // Cập nhật user
  update: async (id: string | number, user: Partial<User>): Promise<User> => {
    const response: AxiosResponse<ApiResponse<User>> = await apiClient.put(`/users/${id}`, user);
    return response.data.data;
  },

  // Xóa user
  delete: async (id: string | number): Promise<void> => {
    await apiClient.delete(`/users/${id}`);
  },
};

export default apiClient; 