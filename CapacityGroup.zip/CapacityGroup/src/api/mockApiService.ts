import { Group, Benefit, User, SystemUser, ApiResponse } from '../models/types';
import { mockGroups, mockBenefits, mockUsers, mockSystemUsers } from './mockData.ts';

// Helper function để tạo delay giả lập
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Group API functions
export const mockGroupApi = {
  // Lấy danh sách tất cả groups
  getAll: async (): Promise<Group[]> => {
    await delay(500); // Giả lập delay mạng
    return [...mockGroups];
  },

  // Lấy chi tiết một group theo ID
  getById: async (id: string | number): Promise<Group> => {
    await delay(300);
    const group = mockGroups.find(g => g.id === id);
    if (!group) {
      throw new Error('Group not found');
    }
    return { ...group };
  },

  // Tạo mới group
  create: async (group: Omit<Group, 'id'>): Promise<Group> => {
    await delay(700);
    const newGroup = {
      ...group,
      id: Math.max(...mockGroups.map(g => Number(g.id))) + 1,
    };
    mockGroups.push(newGroup);
    return { ...newGroup };
  },

  // Cập nhật group
  update: async (id: string | number, group: Partial<Group>): Promise<Group> => {
    await delay(500);
    const index = mockGroups.findIndex(g => g.id === id);
    if (index === -1) {
      throw new Error('Group not found');
    }
    mockGroups[index] = { ...mockGroups[index], ...group };
    return { ...mockGroups[index] };
  },

  // Xóa group
  delete: async (id: string | number): Promise<void> => {
    await delay(500);
    const index = mockGroups.findIndex(g => g.id === id);
    if (index === -1) {
      throw new Error('Group not found');
    }
    mockGroups.splice(index, 1);
  },
};

// Benefit API functions
export const mockBenefitApi = {
  // Lấy danh sách benefits của một group
  getByGroupId: async (groupId: string | number): Promise<Benefit[]> => {
    await delay(500);
    return mockBenefits.filter(b => b.groupId === groupId).map(b => ({ ...b }));
  },

  // Tạo mới benefit
  create: async (benefit: Omit<Benefit, 'id'>): Promise<Benefit> => {
    await delay(700);
    const newBenefit = {
      ...benefit,
      id: Math.max(...mockBenefits.map(b => Number(b.id))) + 1,
    };
    mockBenefits.push(newBenefit);
    return { ...newBenefit };
  },

  // Cập nhật benefit
  update: async (id: string | number, benefit: Partial<Benefit>): Promise<Benefit> => {
    await delay(500);
    const index = mockBenefits.findIndex(b => b.id === id);
    if (index === -1) {
      throw new Error('Benefit not found');
    }
    mockBenefits[index] = { ...mockBenefits[index], ...benefit };
    return { ...mockBenefits[index] };
  },

  // Xóa benefit
  delete: async (id: string | number): Promise<void> => {
    await delay(500);
    const index = mockBenefits.findIndex(b => b.id === id);
    if (index === -1) {
      throw new Error('Benefit not found');
    }
    mockBenefits.splice(index, 1);
  },
};

// SystemUser API functions
export const mockSystemUserApi = {
  // Lấy danh sách tất cả system users
  getAll: async (): Promise<SystemUser[]> => {
    await delay(500);
    return [...mockSystemUsers];
  },

  // Lấy chi tiết một system user theo ID
  getById: async (id: string | number): Promise<SystemUser> => {
    await delay(300);
    const user = mockSystemUsers.find(u => u.id === id);
    if (!user) {
      throw new Error('System User not found');
    }
    return { ...user };
  },
};

// User API functions
export const mockUserApi = {
  // Lấy danh sách users của một group
  getByGroupId: async (groupId: string | number): Promise<User[]> => {
    await delay(500);
    return mockUsers.filter(u => u.groupId === groupId).map(u => ({ ...u }));
  },

  // Tạo mới user
  create: async (user: Omit<User, 'id'>): Promise<User> => {
    await delay(700);
    const newUser = {
      ...user,
      id: Math.max(...mockUsers.map(u => Number(u.id))) + 1,
      cases: Math.round(user.ratio * 10), // Tính cases dựa trên ratio
    };
    mockUsers.push(newUser);
    return { ...newUser };
  },

  // Cập nhật user
  update: async (id: string | number, user: Partial<User>): Promise<User> => {
    await delay(500);
    const index = mockUsers.findIndex(u => u.id === id);
    if (index === -1) {
      throw new Error('User not found');
    }
    const updatedUser = { ...mockUsers[index], ...user };
    updatedUser.cases = Math.round(updatedUser.ratio * 10); // Tính lại cases khi ratio thay đổi
    mockUsers[index] = updatedUser;
    return { ...updatedUser };
  },

  // Xóa user
  delete: async (id: string | number): Promise<void> => {
    await delay(500);
    const index = mockUsers.findIndex(u => u.id === id);
    if (index === -1) {
      throw new Error('User not found');
    }
    mockUsers.splice(index, 1);
  },
};