import { Group, Benefit, User, SystemUser } from '../models/types';

// Mock data cho Groups
export const mockGroups: Group[] = [
  {
    id: 1,
    groupName: 'Nhóm Kinh Doanh',
    assignmentPriority: 1,
    createdOn: '2024-02-01T08:00:00Z',
  },
  {
    id: 2,
    groupName: 'Nhóm Kỹ Thuật',
    assignmentPriority: 2,
    createdOn: '2024-02-02T09:30:00Z',
  },
  {
    id: 3,
    groupName: 'Nhóm Hỗ Trợ',
    assignmentPriority: 3,
    createdOn: '2024-02-03T10:15:00Z',
  },
];

// Mock data cho Benefits
export const mockBenefits: Benefit[] = [
  {
    id: 1,
    benefitName: 'Bảo hiểm sức khỏe',
    description: 'Bảo hiểm y tế toàn diện cho nhân viên',
    groupId: 1,
  },
  {
    id: 2,
    benefitName: 'Phụ cấp đi lại',
    description: 'Hỗ trợ chi phí đi lại hàng tháng',
    groupId: 1,
  },
  {
    id: 3,
    benefitName: 'Đào tạo kỹ năng',
    description: 'Các khóa học nâng cao kỹ năng chuyên môn',
    groupId: 2,
  },
  {
    id: 4,
    benefitName: 'Phụ cấp điện thoại',
    description: 'Hỗ trợ chi phí điện thoại hàng tháng',
    groupId: 2,
  },
  {
    id: 5,
    benefitName: 'Bữa trưa miễn phí',
    description: 'Cung cấp bữa trưa tại công ty',
    groupId: 3,
  },
];

// Mock data cho SystemUsers
export const mockSystemUsers: SystemUser[] = [
  {
    id: 1,
    fullName: 'Nguyễn Văn A',
    userCode: 'NV001',
  },
  {
    id: 2,
    fullName: 'Trần Thị B',
    userCode: 'NV002',
  },
  {
    id: 3,
    fullName: 'Lê Văn C',
    userCode: 'NV003',
  },
  {
    id: 4,
    fullName: 'Phạm Thị D',
    userCode: 'NV004',
  },
  {
    id: 5,
    fullName: 'Hoàng Văn E',
    userCode: 'NV005',
  },
];

// Mock data cho Users
export const mockUsers: User[] = [
  {
    id: 1,
    systemUserId: 1,
    fullName: 'Nguyễn Văn A',
    userCode: 'NV001',
    ratio: 0.8,
    cases: 10,
    groupId: 1,
  },
  {
    id: 2,
    systemUserId: 2,
    fullName: 'Trần Thị B',
    userCode: 'NV002',
    ratio: 1.2,
    cases: 15,
    groupId: 1,
  },
  {
    id: 3,
    systemUserId: 3,
    fullName: 'Lê Văn C',
    userCode: 'NV003',
    ratio: 0.6,
    cases: 8,
    groupId: 2,
  },
  {
    id: 4,
    systemUserId: 4,
    fullName: 'Phạm Thị D',
    userCode: 'NV004',
    ratio: 1.0,
    cases: 12,
    groupId: 2,
  },
  {
    id: 5,
    systemUserId: 5,
    fullName: 'Hoàng Văn E',
    userCode: 'NV005',
    ratio: 0.4,
    cases: 5,
    groupId: 3,
  },
];