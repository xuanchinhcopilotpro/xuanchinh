import React, { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Field,
  Input,
  Button,
  Spinner,
  MessageBar,
  TableColumnDefinition,
  createTableColumn,
  DataGridCell,
} from '@fluentui/react-components';
import { SaveRegular, DeleteRegular, ArrowLeftRegular } from '@fluentui/react-icons';
import { Group, Benefit, User, SystemUser } from '../models/types.ts';
import { 
  mockGroupApi as groupApi, 
  mockBenefitApi as benefitApi, 
  mockUserApi as userApi,
  mockSystemUserApi as systemUserApi 
} from '../api/mockApiService.ts';
import { mockSystemUsers, mockBenefits } from '../api/mockData.ts';
import Subgrid from '../components/Subgrid.tsx';
import LookupField from '../components/LookupField.tsx';

const GroupFormPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [group, setGroup] = useState<Partial<Group>>({
    groupName: '',
    assignmentPriority: 0,
  });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [formData, setFormData] = useState<any>({});

  const isNewGroup = id === 'new';

  const loadGroup = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await groupApi.getById(id!);
      setGroup(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load group');
    } finally {
      setLoading(false);
    }
  }, [id]);

  // Load group data if editing
  useEffect(() => {
    if (!isNewGroup && id) {
      loadGroup();
    }
  }, [id, isNewGroup, loadGroup]);

  // Handle form field changes
  const handleFieldChange = (field: keyof Group, value: any) => {
    setGroup(prev => ({ ...prev, [field]: value }));
  };

  // Save group
  const handleSave = async () => {
    try {
      setSaving(true);
      setError(null);
      setSuccess(null);

      if (isNewGroup) {
        const newGroup = await groupApi.create(group as Omit<Group, 'id'>);
        setSuccess('Group created successfully!');
        setGroup(newGroup);
        // Update URL to show the new ID
        navigate(`/form/${newGroup.id}`, { replace: true });
      } else {
        await groupApi.update(id!, group);
        setSuccess('Group updated successfully!');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to save group');
    } finally {
      setSaving(false);
    }
  };

  // Save and close
  const handleSaveAndClose = async () => {
    await handleSave();
    if (!error) {
      navigate('/');
    }
  };

  // Delete group
  const handleDelete = async () => {
    if (isNewGroup) return;

    if (window.confirm('Are you sure you want to delete this group?')) {
      try {
        setSaving(true);
        setError(null);
        await groupApi.delete(id!);
        navigate('/');
      } catch (err: any) {
        setError(err.message || 'Failed to delete group');
        setSaving(false);
      }
    }
  };

  // Benefit columns
  const benefitColumns: TableColumnDefinition<Benefit>[] = [
    {
      columnId: 'benefitName',
      compare: (a, b) => a.benefitName.localeCompare(b.benefitName),
      renderHeaderCell: () => 'Benefit Name',
      renderCell: (item) => item.benefitName,
    },
    {
      columnId: 'description',
      compare: (a, b) => a.description.localeCompare(b.description),
      renderHeaderCell: () => 'Description',
      renderCell: (item) => item.description,
    },
  ];

  // User columns
  const userColumns: TableColumnDefinition<User>[] = [
    {
      columnId: 'fullName',
      compare: (a, b) => {
        const aSystemUser = mockSystemUsers.find(su => su.id === a.systemUserId);
        const bSystemUser = mockSystemUsers.find(su => su.id === b.systemUserId);
        return (aSystemUser?.fullName || a.fullName).localeCompare(bSystemUser?.fullName || b.fullName);
      },
      renderHeaderCell: () => 'Full Name',
      renderCell: (item) => {
        const systemUser = mockSystemUsers.find(su => su.id === item.systemUserId);
        return systemUser?.fullName || item.fullName;
      },
    },
    {
      columnId: 'userCode',
      compare: (a, b) => {
        const aSystemUser = mockSystemUsers.find(su => su.id === a.systemUserId);
        const bSystemUser = mockSystemUsers.find(su => su.id === b.systemUserId);
        return (aSystemUser?.userCode || a.userCode).localeCompare(bSystemUser?.userCode || b.userCode);
      },
      renderHeaderCell: () => 'User Code',
      renderCell: (item) => {
        const systemUser = mockSystemUsers.find(su => su.id === item.systemUserId);
        return systemUser?.userCode || item.userCode;
      },
    },
    {
      columnId: 'cases',
      compare: (a, b) => (a.cases || 0) - (b.cases || 0),
      renderHeaderCell: () => 'Cases',
      renderCell: (item) => item.cases || 0,
    },
    {
      columnId: 'ratio',
      compare: (a, b) => (a.ratio || 0) - (b.ratio || 0),
      renderHeaderCell: () => 'Ratio',
      renderCell: (item) => (item.ratio || 0).toFixed(2),
    },
  ];

  // Helper: columns cho LookupField Benefit
  const getBenefitLookupColumns = () => [
    createTableColumn<Benefit>({
      columnId: 'benefitName',
      renderCell: (item) => <DataGridCell>{item.benefitName}</DataGridCell>,
    }),
    createTableColumn<Benefit>({
      columnId: 'description',
      renderCell: (item) => <DataGridCell>{item.description}</DataGridCell>,
    }),
  ];
  // Helper: columns cho LookupField User
  const getSystemUserLookupColumns = () => [
    createTableColumn<SystemUser>({
      columnId: 'fullName',
      renderCell: (item) => <DataGridCell>{item.fullName}</DataGridCell>,
    }),
    createTableColumn<SystemUser>({
      columnId: 'userCode',
      renderCell: (item) => <DataGridCell>{item.userCode}</DataGridCell>,
    }),
  ];
  // Helper: fetchItems cho LookupField Benefit (always get all)
  const fetchAllBenefits = async () => {
    return mockBenefits;
  };
  // Helper: fetchItems cho LookupField User
  const fetchAllSystemUsers = async () => await systemUserApi.getAll();

  // Benefit create form fields
  const benefitCreateFormFields = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <LookupField<Benefit>
        label="Benefit"
        value={null}
        onChange={(benefit) => {
          if (benefit) {
            setFormData({
              benefitName: benefit.benefitName,
              description: benefit.description,
            });
          }
        }}
        fetchItems={fetchAllBenefits}
        displayField="benefitName"
        columns={getBenefitLookupColumns()}
        required
      />
    </div>
  );

  // Benefit edit form fields
  const benefitEditFormFields = (benefit: Benefit) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <LookupField<Benefit>
        label="Benefit"
        value={benefit}
        onChange={(selectedBenefit) => {
          if (selectedBenefit) {
            setFormData(prev => ({
              ...prev,
              benefitName: selectedBenefit.benefitName,
              description: selectedBenefit.description
            }));
          }
        }}
        fetchItems={fetchAllBenefits}
        displayField="benefitName"
        columns={getBenefitLookupColumns()}
        required
      />
    </div>
  );

  // User create form fields
  const userCreateFormFields = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <LookupField<SystemUser>
        label="System User"
        value={null}
        onChange={(systemUser) => {
          if (systemUser) {
            setFormData(prev => ({
              ...prev,
              systemUserId: systemUser.id,
              fullName: systemUser.fullName,
              userCode: systemUser.userCode,
              ratio: 1.0, // Default ratio
            }));
          }
        }}
        fetchItems={fetchAllSystemUsers}
        displayField="fullName"
        columns={getSystemUserLookupColumns()}
        required
      />
      <Field label="Ratio" required>
        <Input
          type="number"
          step="0.1"
          value={formData.ratio?.toString() || '1.0'}
          onChange={(e, data) => setFormData(prev => ({ ...prev, ratio: parseFloat(data.value) || 0 }))}
        />
      </Field>
    </div>
  );

  // User edit form fields
  const userEditFormFields = (user: User) => {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <LookupField<SystemUser>
          label="System User"
          value={mockSystemUsers.find(su => su.id === user.systemUserId) ?? null}
          onChange={(systemUser) => {
            if (systemUser) {
              setFormData(prev => ({
                ...prev,
                systemUserId: systemUser.id,
                fullName: systemUser.fullName,
                userCode: systemUser.userCode,
              }));
            }
          }}
          fetchItems={fetchAllSystemUsers}
          displayField="fullName"
          columns={getSystemUserLookupColumns()}
          required
        />
        <Field label="Ratio" required>
          <Input
            type="number"
            step="0.1"
            value={formData.ratio?.toString() || user.ratio?.toString() || '0'}
            onChange={(e, data) => setFormData(prev => ({ ...prev, ratio: parseFloat(data.value) || 0 }))}
          />
        </Field>
      </div>
    );
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '400px' }}>
        <Spinner size="large" label="Loading group..." />
      </div>
    );
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: '#f8f8f8' }}>
      {/* Header */}
      <div style={{ 
        padding: '8px 20px',
        backgroundColor: '#fff',
        borderBottom: '1px solid #e1e1e1',
        display: 'flex',
        alignItems: 'center',
        gap: '12px'
      }}>
        <Button
          appearance="subtle"
          icon={<ArrowLeftRegular />}
          onClick={() => navigate('/')}
        >
          Back to List
        </Button>
        <Button
          appearance="primary"
          icon={<SaveRegular />}
          onClick={handleSave}
          disabled={saving}
        >
          {saving ? 'Saving...' : 'Save'}
        </Button>
        <Button
          appearance="secondary"
          icon={<SaveRegular />}
          onClick={handleSaveAndClose}
          disabled={saving}
        >
          Save & Close
        </Button>
        {!isNewGroup && (
          <Button
            appearance="subtle"
            icon={<DeleteRegular />}
            onClick={handleDelete}
            disabled={saving}
          >
            Delete
          </Button>
        )}
      </div>

      {/* Title */}
      <div style={{ 
        padding: '16px 20px',
        backgroundColor: '#fff',
        borderBottom: '1px solid #e1e1e1',
        marginBottom: '1px'
      }}>
        <h1 style={{ 
          margin: 0,
          fontSize: '24px',
          fontWeight: '600'
        }}>{isNewGroup ? 'Create New Group' : 'Edit Group'}</h1>
      </div>

      {/* Messages */}
      <div style={{ padding: '0 20px' }}>
        {error && (
          <MessageBar intent="error" style={{ marginBottom: '16px' }}>
            {error}
          </MessageBar>
        )}

        {success && (
          <MessageBar intent="success" style={{ marginBottom: '16px' }}>
            {success}
          </MessageBar>
        )}
      </div>

      {/* Content */}
      <div style={{ 
        flex: 1,
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        gap: '24px',
        overflow: 'auto'
      }}>
        {/* Form Fields */}
        <div style={{ 
          backgroundColor: '#fff',
          padding: '20px',
          borderRadius: '2px',
          boxShadow: '0 1.6px 3.6px 0 rgba(0,0,0,0.132), 0 0.3px 0.9px 0 rgba(0,0,0,0.108)'
        }}>
          <div style={{ maxWidth: '400px' }}>
            <Field label="Group Name" required>
              <Input
                value={group.groupName || ''}
                onChange={(e, data) => handleFieldChange('groupName', data.value)}
                placeholder="Enter group name"
              />
            </Field>
            <Field label="Assignment Priority" required style={{ marginTop: '16px' }}>
              <Input
                type="number"
                value={group.assignmentPriority?.toString() || '0'}
                onChange={(e, data) => handleFieldChange('assignmentPriority', parseInt(data.value) || 0)}
                placeholder="Enter priority"
              />
            </Field>
          </div>
        </div>

        {/* Subgrids */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
          {/* Benefits Subgrid */}
          <div style={{ 
            backgroundColor: '#fff',
            borderRadius: '2px',
            boxShadow: '0 1.6px 3.6px 0 rgba(0,0,0,0.132), 0 0.3px 0.9px 0 rgba(0,0,0,0.108)'
          }}>
            <Subgrid
              title="Benefits"
              groupId={isNewGroup ? 'new' : id!}
              columns={benefitColumns}
              apiServiceFunctions={{
                fetch: benefitApi.getByGroupId,
                create: benefitApi.create,
                update: benefitApi.update,
                delete: benefitApi.delete,
              }}
              createFormFields={benefitCreateFormFields}
              editFormFields={benefitEditFormFields}
            />
          </div>

          {/* Users Subgrid */}
          <div style={{ 
            backgroundColor: '#fff',
            borderRadius: '2px',
            boxShadow: '0 1.6px 3.6px 0 rgba(0,0,0,0.132), 0 0.3px 0.9px 0 rgba(0,0,0,0.108)'
          }}>
            <Subgrid
              title="Users"
              groupId={isNewGroup ? 'new' : id!}
              columns={userColumns}
              apiServiceFunctions={{
                fetch: userApi.getByGroupId,
                create: userApi.create,
                update: userApi.update,
                delete: userApi.delete,
              }}
              createFormFields={userCreateFormFields}
              editFormFields={userEditFormFields}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default GroupFormPage; 