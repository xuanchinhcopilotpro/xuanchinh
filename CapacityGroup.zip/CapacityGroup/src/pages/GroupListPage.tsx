import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  DataGrid,
  DataGridHeader,
  DataGridRow,
  DataGridHeaderCell,
  DataGridBody,
  DataGridCell,
  TableColumnDefinition,
  TableColumnId,
  Spinner,
  MessageBar,
  makeStyles,
  tokens,
  Button,
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbDivider,
  Table, TableHeader, TableRow, TableCell, TableBody, Checkbox,
} from '@fluentui/react-components';
import {
  bundleIcon,
  AddRegular,
  AddFilled,
  DeleteRegular,
  DeleteFilled,
  ArrowClockwiseRegular,
  ArrowClockwiseFilled,
  HomeFilled,
  HomeRegular,
} from '@fluentui/react-icons';

import { Group } from '../models/types.ts';
import { mockGroupApi as groupApi } from '../api/mockApiService.ts';

// Bundle icons for hover states
const Add = bundleIcon(AddFilled, AddRegular);
const Delete = bundleIcon(DeleteFilled, DeleteRegular);
const Refresh = bundleIcon(ArrowClockwiseFilled, ArrowClockwiseRegular);
const Home = bundleIcon(HomeFilled, HomeRegular);

// Styles
const useStyles = makeStyles({
  root: {
    display: 'flex',
    flexDirection: 'column',
    height: '100%',
    backgroundColor: tokens.colorNeutralBackground1,
  },
  header: {
    padding: '20px',
    borderBottom: `1px solid ${tokens.colorNeutralStroke1}`,
    backgroundColor: tokens.colorNeutralBackground1,
  },
  title: {
    fontSize: tokens.fontSizeBase600,
    fontWeight: tokens.fontWeightSemibold,
    color: tokens.colorNeutralForeground1,
    marginBottom: '8px',
  },
  commandBar: {
    display: 'flex',
    gap: '8px',
    padding: '8px 20px',
    backgroundColor: tokens.colorNeutralBackground1,
    borderBottom: `1px solid ${tokens.colorNeutralStroke1}`,
  },
  content: {
    flex: 1,
    padding: '0 20px 20px 20px',
    overflow: 'auto',
  },
  gridContainer: {
    height: '100%',
    border: `1px solid ${tokens.colorNeutralStroke1}`,
    borderRadius: tokens.borderRadiusMedium,
    overflow: 'hidden',
  },
});

const GroupListPage: React.FC = () => {
  const styles = useStyles();
  const navigate = useNavigate();
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedItems, setSelectedItems] = useState<Set<string | number>>(new Set());

  // Định nghĩa cột cho DataGrid
  const columns = [
    {
      columnId: 'groupName',
      compare: (a, b) => a.groupName.localeCompare(b.groupName),
      renderHeaderCell: () => 'Group Name',
      renderCell: (item) => item.groupName,
    },
    {
      columnId: 'assignmentPriority',
      compare: (a, b) => a.assignmentPriority - b.assignmentPriority,
      renderHeaderCell: () => 'Assignment Priority',
      renderCell: (item) => item.assignmentPriority,
    },
    {
      columnId: 'createdOn',
      compare: (a, b) => new Date(a.createdOn).getTime() - new Date(b.createdOn).getTime(),
      renderHeaderCell: () => 'Created On',
      renderCell: (item) => new Date(item.createdOn).toLocaleString('vi-VN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      }),
    },
    {
      columnId: 'actions',
      renderHeaderCell: () => 'Actions',
      renderCell: (item) => (
        <Button appearance="subtle" onClick={() => navigate(`/form/${item.id}`)}>
          Edit
        </Button>
      ),
      compare: () => 0,
    },
  ];

  // Load danh sách groups
  const loadGroups = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await groupApi.getAll();
      setGroups(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load groups');
    } finally {
      setLoading(false);
    }
  };

  // Xóa groups đã chọn
  const handleDelete = async () => {
    if (selectedItems.size === 0) return;

    try {
      const deletePromises = Array.from(selectedItems).map(id => groupApi.delete(id));
      await Promise.all(deletePromises);
      setSelectedItems(new Set());
      await loadGroups();
    } catch (err: any) {
      setError(err.message || 'Failed to delete groups');
    }
  };



  // Xử lý selection change
  const handleSelectionChange = (e: any, data: { selectedItems: TableColumnId[] }) => {
    setSelectedItems(new Set(data.selectedItems));
  };

  useEffect(() => {
    loadGroups();
  }, []);

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '400px' }}>
        <Spinner size="large" label="Loading groups..." />
      </div>
    );
  }

  return (
    <div className={styles.root}>
      <div className={styles.header}>
        <Breadcrumb size="small">
          <BreadcrumbItem>Home</BreadcrumbItem>
          <BreadcrumbDivider />
          <BreadcrumbItem>Group Management</BreadcrumbItem>
        </Breadcrumb>
        <h1 className={styles.title}>Group Management</h1>
      </div>

      {error && (
        <MessageBar intent="error" style={{ margin: '0 20px 16px 20px' }}>
          {error}
        </MessageBar>
      )}

      <div className={styles.commandBar}>
        <Button
          appearance="primary"
          icon={<Add />}
          onClick={() => navigate('/form/new')}
        >
          New
        </Button>
        <Button
          appearance="subtle"
          icon={<Delete />}
          onClick={handleDelete}
          disabled={selectedItems.size === 0}
        >
          Delete ({selectedItems.size})
        </Button>
        <Button
          appearance="subtle"
          icon={<Refresh />}
          onClick={loadGroups}
        >
          Refresh
        </Button>
      </div>

      <div className={styles.content}>
        <div className={styles.gridContainer}>
          <div style={{ height: '100%', backgroundColor: '#fff' }}>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableCell style={{ width: '8%' }}>
                    <Checkbox
                      checked={selectedItems.size === groups.length && groups.length > 0}
                      onChange={(_, data) => {
                        if (data.checked) {
                          setSelectedItems(new Set(groups.map(i => i.id)));
                        } else {
                          setSelectedItems(new Set());
                        }
                      }}
                    />
                  </TableCell>
                  <TableCell>Group Name</TableCell>
                  <TableCell>Assignment Priority</TableCell>
                  <TableCell>Created On</TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableHeader>
              <TableBody>
                {groups.map((item) => (
                  <TableRow key={item.id} onDoubleClick={() => navigate(`/form/${item.id}`)} style={{ cursor: 'pointer' }}>
                    <TableCell style={{ width: '8%' }}>
                      <Checkbox
                        checked={selectedItems.has(item.id)}
                        onChange={(_, data) => {
                          const newSet = new Set(selectedItems);
                          if (data.checked) {
                            newSet.add(item.id);
                          } else {
                            newSet.delete(item.id);
                          }
                          setSelectedItems(newSet);
                        }}
                      />
                    </TableCell>
                    <TableCell>{item.groupName}</TableCell>
                    <TableCell>{item.assignmentPriority}</TableCell>
                    <TableCell>{new Date(item.createdOn).toLocaleString('vi-VN', {
                      year: 'numeric',
                      month: '2-digit',
                      day: '2-digit',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}</TableCell>
                    <TableCell></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GroupListPage; 