# Dynamics 365 Group Management Web Resource

Ứng dụng React để quản lý Groups, Benefits và Users trong Dynamics 365 Sales.

## Tính năng

- **Trang danh sách Groups**: Hiển thị danh sách tất cả groups với khả năng tìm kiếm và lọc
- **Form quản lý Group**: Tạo mới và chỉnh sửa thông tin group
- **Subgrid Benefits**: Quản lý benefits của từng group
- **Subgrid Users**: Quản lý users của từng group
- **Giao diện Fluent UI**: Đồng bộ với thiết kế của Microsoft Dynamics 365

## Cấu trúc dự án

```
src/
├── api/              # API service functions
├── components/       # Reusable components
├── hooks/           # Custom React hooks
├── models/          # TypeScript interfaces
├── pages/           # Main page components
└── contexts/        # React contexts
```

## Cài đặt và chạy

### Yêu cầu hệ thống
- Node.js 16+ 
- npm hoặc yarn

### Cài đặt dependencies
```bash
npm install
```

### Chạy ứng dụng development
```bash
npm start
```

### Build cho production
```bash
npm run build
```

## Cấu hình API

Tạo file `.env` trong thư mục gốc và cấu hình:

```env
REACT_APP_API_BASE_URL=http://your-api-server.com/api
```

## Triển khai lên Dynamics 365

### Bước 1: Build ứng dụng
```bash
npm run build
```

### Bước 2: Tạo Web Resources trong Dynamics 365

1. Vào **Settings** > **Advanced Settings** > **Customizations** > **Customize the System**
2. Tìm đến mục **Web Resources**
3. Tạo các Web Resources sau:

#### JavaScript Web Resource
- **Name**: `new_react_group_management.js`
- **Type**: Script (JScript)
- **Upload**: File `build/static/js/main.bundle.js`

#### CSS Web Resource (nếu có)
- **Name**: `new_react_group_management.css`
- **Type**: Style Sheet (CSS)
- **Upload**: File `build/static/css/main.bundle.css`

#### HTML Web Resource
- **Name**: `new_main_loader.html`
- **Type**: HTML
- **Content**: Sử dụng file `public/loader.html` và cập nhật đường dẫn

### Bước 3: Cập nhật HTML Loader

Trong Web Resource HTML, cập nhật đường dẫn:

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Group Management</title>
    <link rel="stylesheet" type="text/css" href="new_react_group_management.css">
</head>
<body style="overflow: hidden; word-wrap: break-word;">
    <div id="root"></div>
    <script src="new_react_group_management.js"></script>
</body>
</html>
```

### Bước 4: Thêm vào Site Map

1. Vào **App Designer** > **Site Map**
2. Thêm một Subarea mới
3. Cấu hình:
   - **Type**: Web Resource
   - **Web Resource**: Chọn `new_main_loader.html`
   - **Title**: Group Management

## API Endpoints

Ứng dụng yêu cầu các API endpoints sau:

### Groups
- `GET /api/groups` - Lấy danh sách groups
- `GET /api/groups/{id}` - Lấy chi tiết group
- `POST /api/groups` - Tạo group mới
- `PUT /api/groups/{id}` - Cập nhật group
- `DELETE /api/groups/{id}` - Xóa group

### Benefits
- `GET /api/groups/{groupId}/benefits` - Lấy benefits của group
- `POST /api/benefits` - Tạo benefit mới
- `DELETE /api/benefits/{id}` - Xóa benefit

### Users
- `GET /api/groups/{groupId}/users` - Lấy users của group
- `POST /api/users` - Tạo user mới
- `DELETE /api/users/{id}` - Xóa user

## Troubleshooting

### Lỗi thường gặp

1. **API không kết nối được**
   - Kiểm tra cấu hình `REACT_APP_API_BASE_URL`
   - Đảm bảo CORS được cấu hình đúng

2. **Web Resource không load**
   - Kiểm tra tên file trong HTML loader
   - Đảm bảo Web Resources đã được publish

3. **Giao diện không hiển thị đúng**
   - Kiểm tra CSS Web Resource đã được load
   - Đảm bảo Fluent UI theme được áp dụng

## Phát triển

### Thêm tính năng mới

1. Tạo component trong `src/components/`
2. Thêm API functions trong `src/api/`
3. Cập nhật types trong `src/models/`
4. Tích hợp vào pages

### Testing

```bash
npm test
```

## License

MIT License 