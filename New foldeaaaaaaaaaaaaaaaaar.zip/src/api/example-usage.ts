// src/api/example-usage.ts
// Ví dụ sử dụng các API mới cho Dynamics 365 custom actions

import { groupApi, benefitApi, userApi } from './apiService';

// ==================== GROUP MANAGEMENT EXAMPLES ====================

// Ví dụ 1: Lấy danh sách tất cả groups
export const exampleGetAllGroups = async () => {
  try {
    console.log('Đang lấy danh sách groups...');
    const groups = await groupApi.getAll();
    console.log('Danh sách groups:', groups);
    return groups;
  } catch (error: any) {
    console.error('Lỗi khi lấy groups:', error.message);
    throw error;
  }
};

// Ví dụ 2: Tạo mới group
export const exampleCreateGroup = async () => {
  try {
    console.log('Đang tạo group mới...');
    const newGroup = await groupApi.create({
      groupName: 'Nhóm Marketing',
      assignmentPriority: 4
    });
    console.log('Group mới được tạo:', newGroup);
    return newGroup;
  } catch (error: any) {
    console.error('Lỗi khi tạo group:', error.message);
    throw error;
  }
};

// Ví dụ 3: Cập nhật group
export const exampleUpdateGroup = async (groupId: string) => {
  try {
    console.log(`Đang cập nhật group ${groupId}...`);
    const updatedGroup = await groupApi.update(groupId, {
      groupName: 'Nhóm Marketing Mới',
      assignmentPriority: 5
    });
    console.log('Group đã được cập nhật:', updatedGroup);
    return updatedGroup;
  } catch (error: any) {
    console.error('Lỗi khi cập nhật group:', error.message);
    throw error;
  }
};

// Ví dụ 4: Xóa group
export const exampleDeleteGroup = async (groupId: string) => {
  try {
    console.log(`Đang xóa group ${groupId}...`);
    await groupApi.delete(groupId);
    console.log(`Group ${groupId} đã được xóa thành công`);
  } catch (error: any) {
    console.error('Lỗi khi xóa group:', error.message);
    throw error;
  }
};

// ==================== BENEFIT MANAGEMENT EXAMPLES ====================

// Ví dụ 5: Lấy danh sách benefits của một group
export const exampleGetBenefitsByGroup = async (groupId: string) => {
  try {
    console.log(`Đang lấy benefits của group ${groupId}...`);
    const benefits = await benefitApi.getByGroupId(groupId);
    console.log(`Benefits của group ${groupId}:`, benefits);
    return benefits;
  } catch (error: any) {
    console.error('Lỗi khi lấy benefits:', error.message);
    throw error;
  }
};

// Ví dụ 6: Tạo mới benefit
export const exampleCreateBenefit = async (groupId: string) => {
  try {
    console.log('Đang tạo benefit mới...');
    const newBenefit = await benefitApi.create({
      cr350_name: 'Thưởng dự án',
      cr350_code: 'THUONG001',
      subBenefit: 1,
      groupId: groupId
    });
    console.log('Benefit mới được tạo:', newBenefit);
    return newBenefit;
  } catch (error: any) {
    console.error('Lỗi khi tạo benefit:', error.message);
    throw error;
  }
};

// Ví dụ 7: Cập nhật benefit
export const exampleUpdateBenefit = async (benefitId: string) => {
  try {
    console.log(`Đang cập nhật benefit ${benefitId}...`);
    const updatedBenefit = await benefitApi.update(benefitId, {
      cr350_code: 'THUONG002',
      subBenefit: 2
    });
    console.log('Benefit đã được cập nhật:', updatedBenefit);
    return updatedBenefit;
  } catch (error: any) {
    console.error('Lỗi khi cập nhật benefit:', error.message);
    throw error;
  }
};

// Ví dụ 8: Xóa benefit
export const exampleDeleteBenefit = async (benefitId: string) => {
  try {
    console.log(`Đang xóa benefit ${benefitId}...`);
    await benefitApi.delete(benefitId);
    console.log(`Benefit ${benefitId} đã được xóa thành công`);
  } catch (error: any) {
    console.error('Lỗi khi xóa benefit:', error.message);
    throw error;
  }
};

// ==================== USER MANAGEMENT EXAMPLES ====================

// Ví dụ 9: Lấy danh sách users của một group
export const exampleGetUsersByGroup = async (groupId: string) => {
  try {
    console.log(`Đang lấy users của group ${groupId}...`);
    const users = await userApi.getByGroupId(groupId);
    console.log(`Users của group ${groupId}:`, users);
    return users;
  } catch (error: any) {
    console.error('Lỗi khi lấy users:', error.message);
    throw error;
  }
};

// Ví dụ 10: Tạo mới user
export const exampleCreateUser = async (groupId: string) => {
  try {
    console.log('Đang tạo user mới...');
    const newUser = await userApi.create({
      userCode: 'NV006',
      cases: 12,
      ratio: 1.1,
      groupId: groupId
    });
    console.log('User mới được tạo:', newUser);
    return newUser;
  } catch (error: any) {
    console.error('Lỗi khi tạo user:', error.message);
    throw error;
  }
};

// Ví dụ 11: Cập nhật user
export const exampleUpdateUser = async (userId: string) => {
  try {
    console.log(`Đang cập nhật user ${userId}...`);
    const updatedUser = await userApi.update(userId, {
      ratio: 1.3,
      cases: 18
    });
    console.log('User đã được cập nhật:', updatedUser);
    return updatedUser;
  } catch (error: any) {
    console.error('Lỗi khi cập nhật user:', error.message);
    throw error;
  }
};

// Ví dụ 12: Xóa user
export const exampleDeleteUser = async (userId: string) => {
  try {
    console.log(`Đang xóa user ${userId}...`);
    await userApi.delete(userId);
    console.log(`User ${userId} đã được xóa thành công`);
  } catch (error: any) {
    console.error('Lỗi khi xóa user:', error.message);
    throw error;
  }
};

// ==================== COMPLEX WORKFLOW EXAMPLES ====================

// Ví dụ 13: Tạo group mới và thêm benefits, users
export const exampleCreateCompleteGroup = async () => {
  try {
    console.log('=== BẮT ĐẦU TẠO GROUP HOÀN CHỈNH ===');
    
    // 1. Tạo group mới
    const newGroup = await exampleCreateGroup();
    console.log('✅ Group đã được tạo:', newGroup);
    
    // 2. Thêm benefits cho group
    const benefit1 = await exampleCreateBenefit(newGroup.id);
    console.log('✅ Benefit 1 đã được tạo:', benefit1);
    
    const benefit2 = await benefitApi.create({
      cr350_name: 'Bảo hiểm y tế',
      cr350_code: 'BHYT001',
      subBenefit: 1,
      groupId: newGroup.id
    });
    console.log('✅ Benefit 2 đã được tạo:', benefit2);
    
    // 3. Thêm users cho group
    const user1 = await exampleCreateUser(newGroup.id);
    console.log('✅ User 1 đã được tạo:', user1);
    
    const user2 = await userApi.create({
      userCode: 'NV007',
      cases: 15,
      ratio: 0.9,
      groupId: newGroup.id
    });
    console.log('✅ User 2 đã được tạo:', user2);
    
    console.log('=== HOÀN THÀNH TẠO GROUP HOÀN CHỈNH ===');
    console.log('Group:', newGroup);
    console.log('Benefits:', [benefit1, benefit2]);
    console.log('Users:', [user1, user2]);
    
    return {
      group: newGroup,
      benefits: [benefit1, benefit2],
      users: [user1, user2]
    };
  } catch (error: any) {
    console.error('Lỗi trong quá trình tạo group hoàn chỉnh:', error.message);
    throw error;
  }
};

// Ví dụ 14: Xóa group và tất cả dữ liệu liên quan
export const exampleDeleteCompleteGroup = async (groupId: string) => {
  try {
    console.log(`=== BẮT ĐẦU XÓA GROUP ${groupId} VÀ DỮ LIỆU LIÊN QUAN ===`);
    
    // 1. Lấy danh sách benefits và users của group
    const benefits = await benefitApi.getByGroupId(groupId);
    const users = await userApi.getByGroupId(groupId);
    
    console.log(`Tìm thấy ${benefits.length} benefits và ${users.length} users`);
    
    // 2. Xóa tất cả benefits
    for (const benefit of benefits) {
      await benefitApi.delete(benefit.id);
      console.log(`✅ Đã xóa benefit: ${benefit.id}`);
    }
    
    // 3. Xóa tất cả users
    for (const user of users) {
      await userApi.delete(user.id);
      console.log(`✅ Đã xóa user: ${user.id}`);
    }
    
    // 4. Xóa group
    await groupApi.delete(groupId);
    console.log(`✅ Đã xóa group: ${groupId}`);
    
    console.log(`=== HOÀN THÀNH XÓA GROUP ${groupId} ===`);
    console.log(`Đã xóa ${benefits.length} benefits, ${users.length} users và 1 group`);
  } catch (error: any) {
    console.error('Lỗi trong quá trình xóa group:', error.message);
    throw error;
  }
};

// ==================== ERROR HANDLING EXAMPLES ====================

// Ví dụ 15: Xử lý lỗi
export const exampleErrorHandling = async () => {
  try {
    // Thử tạo group với dữ liệu không hợp lệ
    const invalidGroup = await groupApi.create({
      groupName: '', // Tên rỗng - có thể gây lỗi
      assignmentPriority: -1 // Priority âm - có thể gây lỗi
    });
    return invalidGroup;
  } catch (error: any) {
    console.error('Lỗi được bắt:', {
      message: error.message,
      status: error.status
    });
    
    // Có thể xử lý lỗi theo status code
    if (error.status === 400) {
      console.log('Lỗi validation - kiểm tra lại dữ liệu đầu vào');
    } else if (error.status === 401) {
      console.log('Lỗi authentication - kiểm tra lại token');
    } else if (error.status === 403) {
      console.log('Lỗi authorization - không có quyền thực hiện thao tác');
    } else if (error.status === 500) {
      console.log('Lỗi server - liên hệ admin');
    }
    
    throw error;
  }
};

// ==================== BATCH OPERATIONS EXAMPLES ====================

// Ví dụ 16: Thao tác batch
export const exampleBatchOperations = async (groupId: string) => {
  try {
    console.log(`=== BẮT ĐẦU THAO TÁC BATCH CHO GROUP ${groupId} ===`);
    
    // Tạo nhiều benefits cùng lúc
    const benefitPromises = [
      benefitApi.create({
        cr350_name: 'Thưởng tháng',
        cr350_code: 'THUONG_THANG',
        subBenefit: 1,
        groupId: groupId
      }),
      benefitApi.create({
        cr350_name: 'Thưởng quý',
        cr350_code: 'THUONG_QUY',
        subBenefit: 1,
        groupId: groupId
      }),
      benefitApi.create({
        cr350_name: 'Thưởng năm',
        cr350_code: 'THUONG_NAM',
        subBenefit: 1,
        groupId: groupId
      })
    ];
    
    const benefits = await Promise.all(benefitPromises);
    console.log('✅ Đã tạo 3 benefits:', benefits);
    
    // Tạo nhiều users cùng lúc
    const userPromises = [
      userApi.create({
        userCode: 'NV008',
        cases: 8,
        ratio: 1.0,
        groupId: groupId
      }),
      userApi.create({
        userCode: 'NV009',
        cases: 10,
        ratio: 1.2,
        groupId: groupId
      }),
      userApi.create({
        userCode: 'NV010',
        cases: 12,
        ratio: 0.8,
        groupId: groupId
      })
    ];
    
    const users = await Promise.all(userPromises);
    console.log('✅ Đã tạo 3 users:', users);
    
    console.log(`=== HOÀN THÀNH THAO TÁC BATCH CHO GROUP ${groupId} ===`);
    return { benefits, users };
  } catch (error: any) {
    console.error('Lỗi trong thao tác batch:', error.message);
    throw error;
  }
};

// ==================== MAIN FUNCTION ====================

// Hàm chính để chạy tất cả ví dụ
export const runAllExamples = async () => {
  try {
    console.log('🚀 BẮT ĐẦU CHẠY TẤT CẢ VÍ DỤ');
    
    // Tạo group hoàn chỉnh
    const completeGroup = await exampleCreateCompleteGroup();
    
    // Thực hiện các thao tác khác
    await exampleBatchOperations(completeGroup.group.id);
    
    // Xóa group và dữ liệu liên quan
    await exampleDeleteCompleteGroup(completeGroup.group.id);
    
    console.log('🎉 HOÀN THÀNH TẤT CẢ VÍ DỤ');
  } catch (error: any) {
    console.error('❌ Lỗi khi chạy ví dụ:', error.message);
  }
};

// Export tất cả các ví dụ
export default {
  exampleGetAllGroups,
  exampleCreateGroup,
  exampleUpdateGroup,
  exampleDeleteGroup,
  exampleGetBenefitsByGroup,
  exampleCreateBenefit,
  exampleUpdateBenefit,
  exampleDeleteBenefit,
  exampleGetUsersByGroup,
  exampleCreateUser,
  exampleUpdateUser,
  exampleDeleteUser,
  exampleCreateCompleteGroup,
  exampleDeleteCompleteGroup,
  exampleErrorHandling,
  exampleBatchOperations,
  runAllExamples
};
