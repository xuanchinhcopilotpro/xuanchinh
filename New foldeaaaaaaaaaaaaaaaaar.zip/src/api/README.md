# Dynamics 365 Custom Action APIs

## Tổng quan

Hệ thống này sử dụng Dynamics 365 Custom Actions để thực hiện các thao tác CRUD (Create, Read, Update, Delete) cho Groups, Benefits và Users. Tất cả các API calls đều được gửi đến các custom action của D365 thay vì gọi trực tiếp đến các endpoint thông thường.

## Cấu trúc Payload

Mỗi request đến custom action có cấu trúc như sau:

```typescript
const requestPayload = {
  requestName: "actionName", // Tên của custom action
  data: {
    logicalName: "entity_name", // Tên logical của entity
    payLoad: {
      // Cấu trúc payload mới theo yêu cầu
      id?: "string",
      GROUP_ID?: "string",
      GroupName?: "string",
      priority?: 0,
      benefiT_CODE?: "string",
      sub_BENEFIT?: 0,
      useR_CODE?: "string",
      match?: 0,
      Cases?: 0,
      masterDataLogicalName: "string",
      actionName: "string", // Loại thao tác (create, update, delete, getAll, getById, getByGroupId)
      idDelete?: ["string"]
    }
  }
};
```

### Generic Inner Payload Structure

Cấu trúc `payLoad` mới sử dụng một format chung cho tất cả các entities:

```typescript
interface GenericInnerPayload {
  id?: string;                    // ID của record (dùng cho update, delete, getById)
  GROUP_ID?: string;              // ID của group (dùng cho benefits và users)
  GroupName?: string;             // Tên của group
  priority?: number;              // Độ ưu tiên của group
  benefiT_CODE?: string;          // Mã benefit
  sub_BENEFIT?: number;           // Số lượng sub-benefit
  useR_CODE?: string;             // Mã user
  match?: number;                 // Tỷ lệ match (ratio)
  Cases?: number;                 // Số lượng cases
  masterDataLogicalName: string;  // Tên logical của master data entity
  actionName: string;             // Loại thao tác
  idDelete?: string[];            // Danh sách ID để xóa (cho batch delete)
}
```

## Các Custom Actions

### 1. Group Management

#### Lấy danh sách tất cả groups
```typescript
import { groupApi } from './apiService';

const groups = await groupApi.getAll();
```

**Payload gửi đến D365:**
```json
{
  "requestName": "getGroups",
  "data": {
    "logicalName": "group_management",
    "payLoad": {
      "actionName": "getAll",
      "masterDataLogicalName": "group_management"
    }
  }
}
```

#### Tạo mới group
```typescript
const newGroup = await groupApi.create({
  groupName: "Nhóm Kinh Doanh",
  assignmentPriority: 1
});
```

**Payload gửi đến D365:**
```json
{
  "requestName": "upsertGroups",
  "data": {
    "logicalName": "group_management",
    "payLoad": {
      "actionName": "create",
      "GroupName": "Nhóm Kinh Doanh",
      "priority": 1,
      "masterDataLogicalName": "group_management"
    }
  }
}
```

#### Cập nhật group
```typescript
const updatedGroup = await groupApi.update(1, {
  groupName: "Nhóm Kinh Doanh Mới",
  assignmentPriority: 2
});
```

**Payload gửi đến D365:**
```json
{
  "requestName": "upsertGroups",
  "data": {
    "logicalName": "group_management",
    "payLoad": {
      "actionName": "update",
      "id": "1",
      "GroupName": "Nhóm Kinh Doanh Mới",
      "priority": 2,
      "masterDataLogicalName": "group_management"
    }
  }
}
```

#### Xóa group
```typescript
await groupApi.delete(1);
```

**Payload gửi đến D365:**
```json
{
  "requestName": "deleteGroups",
  "data": {
    "logicalName": "group_management",
    "payLoad": {
      "actionName": "delete",
      "id": "1",
      "masterDataLogicalName": "group_management"
    }
  }
}
```

### 2. Benefit Management

#### Lấy danh sách benefits của một group
```typescript
import { benefitApi } from './apiService';

const benefits = await benefitApi.getByGroupId(1);
```

**Payload gửi đến D365:**
```json
{
  "requestName": "getBenefits",
  "data": {
    "logicalName": "benefit_management",
    "payLoad": {
      "actionName": "getByGroupId",
      "GROUP_ID": "1",
      "masterDataLogicalName": "benefit_management"
    }
  }
}
```

#### Tạo mới benefit
```typescript
const newBenefit = await benefitApi.create({
  cr350_name: "Bảo hiểm y tế",
  cr350_code: "BHYT001",
  subBenefit: 1,
  groupId: 1
});
```

**Payload gửi đến D365:**
```json
{
  "requestName": "upsertBenefits",
  "data": {
    "logicalName": "benefit_management",
    "payLoad": {
      "actionName": "create",
      "GROUP_ID": "1",
      "benefiT_CODE": "BHYT001",
      "sub_BENEFIT": 1,
      "masterDataLogicalName": "benefit_management"
    }
  }
}
```

### 3. User Management

#### Lấy danh sách users của một group
```typescript
import { userApi } from './apiService';

const users = await userApi.getByGroupId(1);
```

**Payload gửi đến D365:**
```json
{
  "requestName": "getUsers",
  "data": {
    "logicalName": "user_management",
    "payLoad": {
      "actionName": "getByGroupId",
      "GROUP_ID": "1",
      "masterDataLogicalName": "user_management"
    }
  }
}
```

#### Tạo mới user
```typescript
const newUser = await userApi.create({
  userCode: "NV001",
  cases: 10,
  ratio: 1.0,
  groupId: 1
});
```

**Payload gửi đến D365:**
```json
{
  "requestName": "upsertUsers",
  "data": {
    "logicalName": "user_management",
    "payLoad": {
      "actionName": "create",
      "GROUP_ID": "1",
      "useR_CODE": "NV001",
      "Cases": 10,
      "match": 1.0,
      "masterDataLogicalName": "user_management"
    }
  }
}
```

## Cấu hình

### Environment Variables

```bash
# Base URL cho Dynamics 365 API
REACT_APP_D365_API_BASE_URL=https://org176b616e.crm5.dynamics.com/api/data/v9.2

# Token cho D365 (có thể lưu trong localStorage cho development)
REACT_APP_D365_TOKEN=your_d365_token_here
```

### Token Configuration

Token có thể được cấu hình theo thứ tự ưu tiên:

1. **Environment Variable**: `REACT_APP_D365_TOKEN`
2. **LocalStorage**: `d365_token` (cho development)
3. **Hardcoded**: Token mặc định trong code (chỉ dùng cho testing)

## Error Handling

Tất cả các API calls đều có error handling tích hợp sẵn:

```typescript
try {
  const groups = await groupApi.getAll();
  // Xử lý data thành công
} catch (error) {
  // Error object có cấu trúc:
  // {
  //   message: string,
  //   status: number
  // }
  console.error('Error:', error.message);
}
```

## Tương thích

Các API mới này hoàn toàn tương thích với code cũ. Tất cả các components và pages hiện tại sẽ hoạt động bình thường mà không cần thay đổi gì.

## Lưu ý

- Tất cả các custom actions phải được tạo trước trong Dynamics 365
- Custom actions phải có tên chính xác như đã định nghĩa trong `D365_CUSTOM_ACTIONS`
- Payload structure mới sử dụng format chung cho tất cả entities
- Trường `actionName` thay thế cho trường `action` cũ
- Trường `masterDataLogicalName` xác định loại entity chính
- Token phải có quyền truy cập vào các custom actions
