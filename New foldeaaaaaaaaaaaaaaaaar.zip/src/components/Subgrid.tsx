import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  TableColumnDefinition,
  Button,
  Dialog,
  DialogSurface,
  DialogTitle,
  DialogBody,
  DialogContent,
  DialogActions,
  Spinner,
  MessageBar,
  makeStyles,
  tokens,
  Table, TableHeader, TableRow, TableCell, TableBody, Checkbox,
} from '@fluentui/react-components';
import { AddRegular, DeleteRegular } from '@fluentui/react-icons';

interface SubgridProps<T> {
  title: string;
  groupId: string | number;
  columns: TableColumnDefinition<T>[];
  apiServiceFunctions: {
    fetch: (groupId: string | number) => Promise<T[]>;
    create: (item: Omit<T, 'id'>) => Promise<T>;
    update?: (id: string | number, item: Partial<T>) => Promise<T>;
    delete: (id: string | number) => Promise<void>;
  };
  createFormFields: React.ReactNode;
  editFormFields?: (item: T) => React.ReactNode;
  onDataChange?: () => void;
  getCreateData?: () => any; // Callback to get form data from parent
  onOpenCreateDialog?: () => void; // Callback when create dialog opens
  onCloseCreateDialog?: () => void; // Callback when create dialog closes
}

const useStyles = makeStyles({
  root: {
    padding: '16px',
    border: `1px solid ${tokens.colorNeutralStroke1}`,
    borderRadius: tokens.borderRadiusMedium,
    position: 'relative',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '16px',
  },
  title: {
    margin: 0,
    fontSize: tokens.fontSizeBase500,
    fontWeight: tokens.fontWeightSemibold,
    color: tokens.colorNeutralForeground1,
  },
  actions: {
    display: 'flex',
    gap: '8px',
  },
  grid: {
    marginTop: '16px',
    border: `1px solid ${tokens.colorNeutralStroke1}`,
    borderRadius: tokens.borderRadiusSmall,
    '& [role="grid"]': {
      backgroundColor: '#fff',
    },
    '& [role="columnheader"]': {
      backgroundColor: '#f8f8f8',
      borderBottom: `1px solid ${tokens.colorNeutralStroke1}`,
      padding: '8px 12px',
      fontWeight: tokens.fontWeightSemibold,
    },
    '& [role="gridcell"]': {
      padding: '8px 12px',
      borderBottom: `1px solid ${tokens.colorNeutralStroke1}`,
    },
    '& [role="row"]:hover': {
      backgroundColor: tokens.colorNeutralBackground1Hover,
    },
    '& [role="row"][aria-selected="true"]': {
      backgroundColor: tokens.colorNeutralBackground1Selected,
    },
    '& [role="checkbox"]': {
      margin: '0 8px',
    },
  },
});

const Subgrid = <T extends { id: string | number }>({
  title,
  groupId,
  columns,
  apiServiceFunctions,
  createFormFields,
  editFormFields,
  onDataChange,
  getCreateData,
  onOpenCreateDialog,
  onCloseCreateDialog,
}: SubgridProps<T>) => {
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [createLoading, setCreateLoading] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedItems, setSelectedItems] = useState<Set<string | number>>(new Set());
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState<any>({});
  const [selectedItem, setSelectedItem] = useState<T | null>(null);

  const styles = useStyles();

  // Load data
  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const data = await apiServiceFunctions.fetch(groupId);
      setItems(data);
    } catch (err: any) {
      setError(err.message || `Failed to load ${title}`);
    } finally {
      setLoading(false);
    }
  }, [groupId, apiServiceFunctions.fetch, title]);

  // Use ref to prevent unnecessary API calls
  const hasLoadedData = useRef(false);

  useEffect(() => {
    // Only load data when groupId changes and is not 'new'
    // and when we haven't loaded data for this groupId yet
    if (groupId !== 'new' && !hasLoadedData.current) {
      hasLoadedData.current = true;
      loadData();
    } else if (groupId === 'new') {
      // For new groups, set empty items immediately
      setItems([]);
      setLoading(false);
      hasLoadedData.current = false; // Reset for next group
    }
  }, [groupId]); // Remove loadData from dependencies to prevent unnecessary re-runs

  // Delete selected items
  const handleDelete = async () => {
    if (selectedItems.size === 0) return;

    try {
      setDeleteLoading(true);
      const deletePromises = Array.from(selectedItems).map(id => apiServiceFunctions.delete(id));
      await Promise.all(deletePromises);
      setSelectedItems(new Set());
      // Remove items from local state instead of reloading
      setItems(prevItems => prevItems.filter(item => !selectedItems.has(item.id)));
      onDataChange?.();
    } catch (err: any) {
      setError(err.message || `Failed to delete ${title}`);
    } finally {
      setDeleteLoading(false);
    }
  };

  // Create new item
  const handleCreate = async () => {
    setCreateLoading(true);
    setError(null);
    
    try {
      // Get form data from parent component if callback is provided
      const dataToCreate = getCreateData ? getCreateData() : formData;
      
      // If getCreateData returns null, skip creation (parent component handled it)
      if (dataToCreate === null) {
        setIsDialogOpen(false);
        setFormData({});
        // Only call onDataChange if it's provided and we're not in a new group
        if (onDataChange && groupId !== 'new') {
          onDataChange();
        }
        return;
      }

      // Nếu dataToCreate là mảng (multiple users), xử lý từng user một
      if (Array.isArray(dataToCreate)) {
        let hasError = false;
        const createdItems: T[] = [];
        
        for (const userData of dataToCreate) {
          try {
            const newItem = await apiServiceFunctions.create({
              ...userData,
              groupId,
            });
            createdItems.push(newItem);
          } catch (err: any) {
            // Nếu có lỗi (ví dụ: user trùng), hiển thị lỗi và dừng
            setError(err.message || `Failed to create user: ${userData.fullname || 'Unknown'}`);
            hasError = true;
            break;
          }
        }
        
        if (!hasError) {
          // Nếu tất cả users được tạo thành công
          setItems([...items, ...createdItems]);
          setIsDialogOpen(false);
          setFormData({});
          // Only call onDataChange if it's provided and we're not in a new group
          if (onDataChange && groupId !== 'new') {
            onDataChange();
          }
        }
        // Nếu có lỗi, giữ dialog mở để user thấy lỗi
        return;
      }
      
      // Xử lý single user như cũ
      const newItem = await apiServiceFunctions.create({
        ...dataToCreate,
        groupId,
      });
      setItems([...items, newItem]);
      setIsDialogOpen(false);
      setFormData({});
      // Only call onDataChange if it's provided and we're not in a new group
      if (onDataChange && groupId !== 'new') {
        onDataChange();
      }
    } catch (err: any) {
      setError(err.message || `Failed to create ${title}`);
    } finally {
      setCreateLoading(false);
    }
  };

  // Update item
  const handleUpdate = async () => {
    if (!selectedItem || !apiServiceFunctions.update) return;

    setCreateLoading(true);
    setError(null);

    try {
      const updatedItem = await apiServiceFunctions.update(selectedItem.id, formData);
      setItems(items.map(item => item.id === updatedItem.id ? updatedItem : item));
      setIsDialogOpen(false);
      setSelectedItem(null);
      setFormData({});
      // Only call onDataChange if it's provided and we're not in a new group
      if (onDataChange && groupId !== 'new') {
        onDataChange();
      }
    } catch (err: any) {
      setError(err.message || `Failed to update ${title}`);
    } finally {
      setCreateLoading(false);
    }
  };


  // For new groups, show a message if no items are loaded
  if (groupId === 'new' && items.length === 0) {
    return (
      <div style={{ padding: '16px', border: '1px solid #e0e0e0', borderRadius: '4px' }}>
        <h3>{title}</h3>
        <p>No {title.toLowerCase()} added yet. Add some using the form above.</p>
      </div>
    );
  }

  return (
    <div className={styles.root}>
      <div className={styles.header}>
        <h3 className={styles.title}>{title}</h3>
        <div className={styles.actions}>
          <Button 
            icon={<AddRegular />}
            appearance="subtle"
            size="small"
            onClick={() => {
              setSelectedItem(null);
              setFormData({});
              setIsDialogOpen(true);
              // Call the callback to notify parent component that create dialog is opening
              onOpenCreateDialog?.();
            }}
          >
            New
          </Button>

          {/* Common Dialog for Create and Edit */}
          <Dialog open={isDialogOpen} onOpenChange={(event, data) => {
            setIsDialogOpen(data.open);
            // If dialog is closing, call the callback
            if (!data.open) {
              onCloseCreateDialog?.();
            }
          }}>
            <DialogSurface>
              <DialogBody>
                <DialogTitle>{selectedItem ? `Edit ${title.slice(0, -1)}` : `Add New ${title.slice(0, -1)}`}</DialogTitle>
                <DialogContent>
                  {selectedItem ? editFormFields?.(selectedItem) : createFormFields}
                </DialogContent>
                <DialogActions>
                  <Button appearance="secondary" onClick={() => {
                    setIsDialogOpen(false);
                    setSelectedItem(null);
                    setFormData({});
                  }}>
                    Cancel
                  </Button>
                  <Button 
                    appearance="primary" 
                    onClick={selectedItem ? handleUpdate : handleCreate}
                    disabled={createLoading}
                  >
                    {createLoading ? (
                      <>
                        <Spinner size="tiny" />
                        {selectedItem ? 'Updating...' : 'Creating...'}
                      </>
                    ) : (
                      selectedItem ? 'Update' : 'Create'
                    )}
                  </Button>
                </DialogActions>
              </DialogBody>
            </DialogSurface>
          </Dialog>

          <Button
            icon={<DeleteRegular />}
            appearance="subtle"
            size="small"
            onClick={handleDelete}
            disabled={selectedItems.size === 0 || deleteLoading}
          >
            {deleteLoading ? (
              <>
                <Spinner size="tiny" />
                Deleting...
              </>
            ) : (
              `Delete (${selectedItems.size})`
            )}
          </Button>
        </div>
      </div>
      
      {error && (
        <MessageBar intent="error" style={{ marginBottom: '16px' }}>
          {error}
        </MessageBar>
      )}

      {loading ? (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '20px' }}>
          <Spinner size="medium" label={`Loading ${title}...`} />
        </div>
      ) : (
        <div className={styles.grid}>
          <div style={{ height: '100%', backgroundColor: '#fff' }}>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableCell style={{ width: '8%' }}>
                    <Checkbox
                      checked={items.length > 0 && selectedItems.size === items.length}
                      onChange={(_, data) => {
                        if (data.checked) {
                          setSelectedItems(new Set(items.map(i => i.id)));
                        } else {
                          setSelectedItems(new Set());
                        }
                      }}
                    />
                  </TableCell>
                  {columns.map((col) => (
                    <TableCell key={col.columnId}>{col.renderHeaderCell ? col.renderHeaderCell() : col.columnId}</TableCell>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item) => (
                  <TableRow key={item.id} onDoubleClick={() => { if (editFormFields) { setSelectedItem(item); setFormData(item); setIsDialogOpen(true); } }} style={{ cursor: editFormFields ? 'pointer' : undefined }}>
                    <TableCell style={{ width: '8%' }}>
                      <Checkbox
                        checked={selectedItems.has(item.id)}
                        onChange={(_, data) => {
                          const newSet = new Set(selectedItems);
                          if (data.checked) {
                            newSet.add(item.id);
                          } else {
                            newSet.delete(item.id);
                          }
                          setSelectedItems(newSet);
                        }}
                      />
                    </TableCell>
                    {columns.map((col) => (
                      <TableCell key={col.columnId}>
                        {col.renderCell ? col.renderCell(item) : item[col.columnId]}
                      </TableCell>
                    ))}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}
    </div>
  );
};

export default Subgrid; 