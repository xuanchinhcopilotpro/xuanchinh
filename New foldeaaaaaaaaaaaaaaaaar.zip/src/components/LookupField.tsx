import React, { useState, useCallback, useMemo, useRef } from 'react';
import {
  Combobox,
  Option,
  Field,
  Dialog,
  DialogTrigger,
  DialogSurface,
  DialogBody,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  DataGrid,
  DataGridHeader,
  DataGridRow,
  DataGridHeaderCell,
  DataGridBody,
  DataGridCell,
  TableColumnDefinition,
  Spinner,
  MessageBar,
  Input,
} from '@fluentui/react-components';
import { SearchRegular } from '@fluentui/react-icons';

interface LookupFieldProps<T> {
  label: string;
  value: T | null | T[];
  onChange: (value: T | null | T[]) => void;
  fetchItems: () => Promise<T[]>;
  displayField: keyof T;
  columns: TableColumnDefinition<T>[];
  required?: boolean;
  disabled?: boolean;
  multiple?: boolean;
  error?: string | null; // Thêm prop error để hiển thị lỗi từ bên ngoài
}

const LookupField = <T extends { id: string | number }>({
  label,
  value,
  onChange,
  fetchItems,
  displayField,
  columns,
  required = false,
  disabled = false,
  multiple = false,
  error: externalError = null, // Nhận error từ bên ngoài
}: LookupFieldProps<T>) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [items, setItems] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Filter items based on search term
  const filteredItems = useMemo(() => {
    if (!searchTerm.trim()) return items;
    
    return items.filter(item => {
      // Search across all string fields in the item
      return Object.entries(item).some(([key, value]) => {
        if (typeof value === 'string') {
          return value.toLowerCase().includes(searchTerm.toLowerCase());
        }
        if (typeof value === 'number') {
          return value.toString().includes(searchTerm);
        }
        return false;
      });
    });
  }, [items, searchTerm]);

  // Load items
  // Load items from API - use useRef to avoid dependency on fetchItems
  const fetchItemsRef = useRef(fetchItems);
  fetchItemsRef.current = fetchItems;

  const loadItems = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      console.log('Loading items for:', label);
      
      if (typeof fetchItemsRef.current !== 'function') {
        throw new Error('fetchItems is not a function');
      }
      
      const data = await fetchItemsRef.current();
      console.log('Loaded items:', data);
      setItems(data || []);
    } catch (err: any) {
      console.error('Error loading items:', err);
      setError(err.message || 'Failed to load items');
    } finally {
      setLoading(false);
    }
  }, [label]);

  // Handle dialog open
  const handleDialogOpen = useCallback(async (open: boolean) => {
    console.log('Dialog open state changed:', open);
    setIsDialogOpen(open);
    if (open && items.length === 0) {
      try {
        console.log('Loading items for dialog...');
        await loadItems();
      } catch (error) {
        console.error('Error loading items in dialog:', error);
      }
    }
    // Reset search term when dialog opens
    if (open) {
      setSearchTerm('');
    }
  }, [items.length, loadItems]);

  // Handle search button click
  const handleSearchClick = useCallback(async () => {
    console.log('Search button clicked');
    if (!isDialogOpen) {
      setIsDialogOpen(true);
      try {
        console.log('Loading items for search button...');
        await loadItems();
      } catch (error) {
        console.error('Error loading items on search click:', error);
      }
    }
  }, [isDialogOpen, loadItems]);

  // Handle combobox click
  const handleComboboxClick = useCallback(async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    console.log('Combobox clicked');
    if (!isDialogOpen) {
      setIsDialogOpen(true);
      try {
        console.log('Loading items for combobox...');
        await loadItems();
      } catch (error) {
        console.error('Error loading items on combobox click:', error);
      }
    }
  }, [isDialogOpen, loadItems]);

  // Get display value for combobox - restore original logic
  const getDisplayValue = useMemo(() => {
    if (!value) return '';
    if (multiple) {
      const values = value as T[];
      if (values.length === 0) return '';
      if (values.length === 1) return String(values[0][displayField]);
      return `${values.length} items selected`;
    }
    return String((value as T)[displayField]);
  }, [value, multiple, displayField]);



  // Handle row click - restore original working logic
  const handleRowClick = useCallback((item: T) => {
    console.log('Row clicked:', item);
    if (multiple) {
      const currentValue = value as T[] || [];
      const isAlreadySelected = currentValue.some(i => i.id === item.id);
      
      if (isAlreadySelected) {
        // Remove item if already selected
        const newValue = currentValue.filter(i => i.id !== item.id);
        // Only call onChange if the value actually changed
        if (newValue.length !== currentValue.length) {
          onChange(newValue);
        }
      } else {
        // Add item if not selected
        const newValue = [...currentValue, item];
        // Only call onChange if the value actually changed
        if (newValue.length !== currentValue.length) {
          onChange(newValue);
        }
      }
      
      // Don't close dialog for multiple selection - let user click Done button
    } else {
      // For single selection, immediately update and close dialog
      onChange(item);
      setIsDialogOpen(false);
    }
  }, [multiple, value, onChange]);

  // Handle clear
  const handleClear = useCallback(() => {
    console.log('handleClear called');
    if (multiple) {
      onChange([]);
    } else {
      onChange(null);
    }
  }, [multiple, onChange]);

  // Handle search input change
  const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>, data: { value: string }) => {
    setSearchTerm(data.value);
  }, []);



  return (
    <Field
      label={label}
      required={required}
    >
      <div style={{ display: 'flex', gap: '8px' }}>
        <Dialog open={isDialogOpen} onOpenChange={(e, data) => handleDialogOpen(data.open)}>
          <DialogTrigger disableButtonEnhancement>
            <Combobox
              value={getDisplayValue}
              placeholder="Click to search..."
              style={{ flexGrow: 1 }}
              disabled={disabled}
              onClick={handleComboboxClick}
            >
              <Option text="" value="">
                {loading ? 'Loading...' : 'Click to search...'}
              </Option>
            </Combobox>
          </DialogTrigger>
          <DialogSurface style={{ minWidth: '600px' }}>
            <DialogBody>
              <DialogTitle>Select {label}</DialogTitle>
              <DialogContent>
                {/* Hiển thị external error (như lỗi duplicate user) */}
                {externalError && (
                  <MessageBar intent="error" style={{ marginBottom: '16px' }}>
                    {externalError}
                  </MessageBar>
                )}
                
                {/* Hiển thị internal error (như lỗi load data) */}
                {error && (
                  <MessageBar intent="error" style={{ marginBottom: '16px' }}>
                    {error}
                  </MessageBar>
                )}

                {/* Quick Search Input */}
                <div style={{ marginBottom: '16px' }}>
                  <Input
                    placeholder="Quick search..."
                    value={searchTerm}
                    onChange={handleSearchChange}
                    style={{ width: '100%' }}
                  />
                  {searchTerm && (
                    <div style={{ marginTop: '8px', fontSize: '12px', color: '#666' }}>
                      Found {filteredItems.length} of {items.length} items
                    </div>
                  )}

                </div>

                {loading ? (
                  <div style={{ display: 'flex', justifyContent: 'center', padding: '20px' }}>
                    <Spinner size="medium" label="Loading..." />
                  </div>
                ) : (
                  <DataGrid
                    items={filteredItems}
                    columns={columns}
                    style={{ height: '400px' }}
                  >
                    <DataGridHeader>
                      <DataGridRow>
                        {({ renderHeaderCell }) => (
                          <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                        )}
                      </DataGridRow>
                    </DataGridHeader>
                    <DataGridBody>
                      {({ item, rowId }) => {
                        const typedItem = item as T;
                        
                        // Fix isSelected logic - use same logic as original working version
                        const isSelected = multiple && value && (value as T[]).some(i => i.id === typedItem.id);
                        

                        

                        
                        return (
                          <DataGridRow 
                            key={rowId}
                            onClick={() => handleRowClick(typedItem)}
                            style={{ 
                              cursor: 'pointer',
                              backgroundColor: isSelected ? '#e6f3ff' : 'transparent'
                            }}
                          >
                            {({ renderCell }) => (
                              <DataGridCell>{renderCell(typedItem)}</DataGridCell>
                            )}
                          </DataGridRow>
                        );
                      }}
                    </DataGridBody>
                  </DataGrid>
                )}
              </DialogContent>
              <DialogActions>
                {multiple && (
                  <Button 
                    appearance="primary" 
                    onClick={() => setIsDialogOpen(false)}
                  >
                    Done
                  </Button>
                )}
                <Button appearance="secondary" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
              </DialogActions>
            </DialogBody>
          </DialogSurface>
        </Dialog>
        <Button
          icon={<SearchRegular />}
          onClick={handleSearchClick}
          disabled={disabled}
        />
        {value && (
          <Button
            onClick={handleClear}
            disabled={disabled}
          >
            Clear
          </Button>
        )}
      </div>
    </Field>
  );
};

export default React.memo(LookupField) as <T extends { id: string | number }>(props: LookupFieldProps<T>) => JSX.Element;