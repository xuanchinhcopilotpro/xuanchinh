import React, { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Field,
  Input,
  Button,
  Spinner,
  MessageBar,
  createTableColumn,
  DataGridCell,
  Combobox,
  Option,
} from '@fluentui/react-components';
import { SaveRegular, DeleteRegular, ArrowLeftRegular } from '@fluentui/react-icons';
import { Group, Benefit, User, SystemUser } from '../models/types.ts';
import { 
  groupApi, 
  benefitApi, 
  userApi,
  systemUserApi,
  benefitLookupApi
} from '../api/apiService.ts';
import Subgrid from '../components/Subgrid.tsx';
import LookupField from '../components/LookupField.tsx';

const GroupFormPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [group, setGroup] = useState<Partial<Group>>({
    groupName: '',
    assignmentPriority: 0,
  });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [formData, setFormData] = useState<any>({});
  const [refreshUsersSubgrid, setRefreshUsersSubgrid] = useState(0);
  const [unsavedUsers, setUnsavedUsers] = useState<User[]>([]); // State for unsaved users
  const [userSelectionError, setUserSelectionError] = useState<string | null>(null); // Thêm state để lưu lỗi khi chọn user
  const [selectedUsers, setSelectedUsers] = useState<SystemUser[]>([]); // State for selected users
  const [selectedBenefit, setSelectedBenefit] = useState<Benefit | null>(null); // State for selected benefit
  const [selectedSubBenefit, setSelectedSubBenefit] = useState<number | null>(null);
  const [selectedSubBenefitText, setSelectedSubBenefitText] = useState<string>('');

  // Sub benefit options
  const [subBenefitOptions, setSubBenefitOptions] = useState<{ key: string; text: string }[]>([]);

  const isNewGroup = id === 'new';



  // Check if a user is already added (either in unsaved or saved)
  const isUserAlreadyAdded = useCallback(async (systemUserId: string | number) => {
    // Check in unsaved users
    const isInUnsaved = unsavedUsers.some(user => user.systemUserId === systemUserId);
    if (isInUnsaved) return true;
    
    // For existing groups, also check saved users
    if (!isNewGroup) {
      try {
        const existingUsers = await userApi.getByGroupId(id!);
        return existingUsers.some(user => user.systemUserId === systemUserId);
      } catch (error) {
        console.error('Error checking existing users:', error);
        return false;
      }
    }
    
    return false;
  }, [unsavedUsers, isNewGroup, id]);

  // Create user function that handles both new and existing groups
  const createUserForGroup = useCallback(async (userData: Omit<User, 'id'>, skipDuplicateCheck = false) => {
    try {
      setUserSelectionError(null); // Clear error trước khi tạo
      
      // Check if user is already added
      if (!skipDuplicateCheck && await isUserAlreadyAdded(userData.systemUserId)) {
        setUserSelectionError(`User ${userData.fullname} is already added to this group`);
        return null; // Return null để không tạo user
      }

      if (isNewGroup) {
        // For new groups, add to local state
        const newUser: User = {
          ...userData,
          id: `temp-${Date.now()}-${Math.random()}`,
          groupId: 'new'
        };
        setUnsavedUsers(prev => [...prev, newUser]);
        return newUser;
      } else {
        // For existing groups, create via API
        return await userApi.create(userData);
      }
    } catch (error) {
      setUserSelectionError(`Failed to create user: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return null;
    }
  }, [isNewGroup, isUserAlreadyAdded]);

  // Wrapper function for Subgrid to ensure it always gets a User or throws an error
  const createUserForGroupWrapper = useCallback(async (userData: Omit<User, 'id'>) => {
    // Kiểm tra duplicate trước khi tạo
    if (await isUserAlreadyAdded(userData.systemUserId)) {
      throw new Error(`User ${userData.fullname} is already added to this group`);
    }
    
    const result = await createUserForGroup(userData);
    if (!result) {
      throw new Error('Failed to create user');
    }
    return result;
  }, [createUserForGroup, isUserAlreadyAdded]);

  // Callback to refresh users subgrid
  const handleUsersDataChange = useCallback(() => {
    // Only increment if we're not in the middle of creating users
    // and if we're not in the middle of a dialog operation
    if (selectedUsers.length === 0) {
      // Use a more efficient approach - only refresh when necessary
      // and avoid immediate refresh during creation
      const timeoutId = setTimeout(() => {
        setRefreshUsersSubgrid(prev => prev + 1);
      }, 200); // Increased delay to ensure creation is complete
      
      // Cleanup timeout if component unmounts
      return () => clearTimeout(timeoutId);
    }
  }, [selectedUsers.length]);

  // Custom fetch function for users that combines saved and unsaved users
  const fetchUsersForGroup = useCallback(async (groupId: string | number) => {
    if (groupId === 'new') {
      // Get the current unsavedUsers value directly from the state
      return unsavedUsers;
    } else {
      // Return saved users from API for existing groups
      return await userApi.getByGroupId(groupId);
    }
  }, [unsavedUsers]);

  // Custom update function for users
  const updateUserForGroup = useCallback(async (id: string | number, user: Partial<User>) => {
    if (isNewGroup) {
      // For new groups, update in local state
      setUnsavedUsers(prev => prev.map(u => u.id === id ? { ...u, ...user } : u));
      const updatedUser = unsavedUsers.find(u => u.id === id);
      return updatedUser!;
    } else {
      // For existing groups, update via API
      return await userApi.update(id, user);
    }
  }, [isNewGroup, unsavedUsers]);

  // Custom delete function for users
  const deleteUserForGroup = useCallback(async (id: string | number) => {
    if (isNewGroup) {
      // For new groups, remove from local state
      setUnsavedUsers(prev => prev.filter(u => u.id !== id));
    } else {
      // For existing groups, delete via API
      await userApi.delete(id);
    }
  }, [isNewGroup]);

  // Memoize API service functions to prevent unnecessary re-renders
  const userApiServiceFunctions = useMemo(() => ({
    fetch: fetchUsersForGroup,
    create: createUserForGroupWrapper,
    update: updateUserForGroup,
    delete: deleteUserForGroup,
  }), [fetchUsersForGroup, createUserForGroupWrapper, updateUserForGroup, deleteUserForGroup]);

  // Use ref to store stable API service functions
  const userApiServiceFunctionsRef = useRef({
    fetch: fetchUsersForGroup,
    create: createUserForGroupWrapper,
    update: updateUserForGroup,
    delete: deleteUserForGroup,
  });

  // Update ref when functions change
  useEffect(() => {
    userApiServiceFunctionsRef.current = {
      fetch: fetchUsersForGroup,
      create: createUserForGroupWrapper,
      update: updateUserForGroup,
      delete: deleteUserForGroup,
    };
  }, [fetchUsersForGroup, createUserForGroupWrapper, updateUserForGroup, deleteUserForGroup]);

  const benefitApiServiceFunctions = useMemo(() => ({
    fetch: benefitApi.getByGroupId,
    create: benefitApi.create,
    update: benefitApi.update,
    delete: benefitApi.delete,
  }), []);

  // Use ref to store stable benefit API service functions
  const benefitApiServiceFunctionsRef = useRef({
    fetch: benefitApi.getByGroupId,
    create: benefitApi.create,
    update: benefitApi.update,
    delete: benefitApi.delete,
  });

  const loadGroup = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await groupApi.getById(id!);
      // Only update if data actually changed
      setGroup(prev => JSON.stringify(prev) === JSON.stringify(data) ? prev : data);
    } catch (err: any) {
      setError(err.message || 'Failed to load group');
    } finally {
      setLoading(false);
    }
  }, [id]);

  // Load group data if editing
  useEffect(() => {
    if (!isNewGroup && id) {
      loadGroup();
    }
  }, [id, isNewGroup, loadGroup]);

  // Load sub benefit options when benefit changes
  useEffect(() => {
    if (selectedBenefit?.cr350_name === "Healthcare") {
      setSubBenefitOptions([
        { key: "100001", text: "item 1" },
        { key: "100002", text: "item 2" },
        { key: "100003", text: "item 3" },
      ]);
    } else {
      setSubBenefitOptions([]);
    }
  }, [selectedBenefit?.cr350_name]);

  // Helper: fetchItems cho LookupField Benefit (từ D365)
  const fetchAllBenefits = useCallback(async () => {
    try {
      const data = await benefitLookupApi.getAll();
      return data || [];
    } catch (error) {
      console.error('Error fetching benefits:', error);
      return [];
    }
  }, []);

  // Helper: fetchItems cho LookupField User (từ D365)
  const fetchAllSystemUsers = useCallback(async () => {
    try {
      const data = await systemUserApi.getAll();
      return data || [];
    } catch (error) {
      console.error('Error fetching system users:', error);
      return [];
    }
  }, []);

  // Load all benefits for lookup
  useEffect(() => {
    fetchAllBenefits();
  }, [fetchAllBenefits]);

  // Handle field change with useCallback to prevent unnecessary re-renders
  const handleFieldChange = useCallback((field: keyof Group, value: any) => {
    // Only update if value actually changed
    setGroup(prev => prev[field] === value ? prev : { ...prev, [field]: value });
  }, []);

  // Optimize form data updates
  const handleFormDataChange = useCallback((field: string, value: any) => {
    // Only update if value actually changed
    setFormData(prev => prev[field] === value ? prev : { ...prev, [field]: value });
  }, []);

  // Handle user selection change
  const handleUserSelectionChange = useCallback((users: SystemUser | SystemUser[] | null) => {
    // Batch state updates to prevent multiple re-renders
    if (Array.isArray(users)) {
      setSelectedUsers(users);
      setUserSelectionError(null); // Clear error khi user thay đổi selection
    } else {
      const userArray = users ? [users] : [];
      setSelectedUsers(userArray);
      setUserSelectionError(null); // Clear error khi user thay đổi selection
    }
  }, []);

  // Optimize benefit selection change
  const handleBenefitSelectionChange = useCallback((benefit: Benefit | Benefit[] | null) => {
    if (benefit && !Array.isArray(benefit)) {
      setSelectedBenefit(benefit); // Set selected benefit để hiển thị trong LookupField
      
      // Batch state updates to prevent multiple re-renders
      if (benefit.cr350_name !== "Healthcare") {
        setSelectedSubBenefit(null);
        setSelectedSubBenefitText('');
        setFormData(prev => ({
          ...prev,
          benefitId: benefit.id,
          cr350_name: benefit.cr350_name,
          cr350_description: benefit.cr350_description,
          cr350_code: benefit.cr350_code, // Lấy cr350_code từ selected benefit
          subBenefit: null, // Reset sub benefit for non-Healthcare benefits
        }));
      } else {
        // Keep existing sub benefit for Healthcare benefits
        setFormData(prev => ({
          ...prev,
          benefitId: benefit.id,
          cr350_name: benefit.cr350_name,
          cr350_description: benefit.cr350_description,
          cr350_code: benefit.cr350_code, // Lấy cr350_code từ selected benefit
          // Keep existing subBenefit value
        }));
      }
    }
  }, []);

  // Optimize system user selection change
  const handleSystemUserSelectionChange = useCallback((systemUser: SystemUser | SystemUser[] | null) => {
    if (systemUser && !Array.isArray(systemUser)) {
      // Batch state updates to prevent multiple re-renders
      setFormData(prev => ({
        ...prev,
        systemUserId: systemUser.id,
        fullname: systemUser.fullname,
        userCode: systemUser.userCode,
      }));
    }
  }, []);

  // Optimize input change handlers
  const handleRatioChange = useCallback((e: React.ChangeEvent<HTMLInputElement>, data: { value: string }) => {
    const value = data?.value ?? e.target?.value ?? '1.0';
    const parsedValue = parseFloat(value) || 1.0;
    // Only update if value actually changed
    setFormData(prev => prev.ratio === parsedValue ? prev : { ...prev, ratio: parsedValue });
  }, []);

  const handleCasesChange = useCallback((e: React.ChangeEvent<HTMLInputElement>, data: { value: string }) => {
    const value = data?.value ?? e.target?.value ?? '0';
    const parsedValue = parseInt(value) || 0;
    // Only update if value actually changed
    setFormData(prev => prev.cases === parsedValue ? prev : { ...prev, cases: parsedValue });
  }, []);

  // Handle sub benefit selection change
  const handleSubBenefitChange = useCallback((event: any, data: any) => {
    // In FluentUI v9 Combobox, data.optionValue contains the key (e.g., "100001")
    // and data.optionText contains the displayed text (e.g., "item 2")
    const selectedOption = subBenefitOptions.find(opt => opt.key === data?.optionValue);
    
    if (selectedOption) {
      const numericValue = parseFloat(selectedOption.key);
      setSelectedSubBenefit(numericValue);
      setSelectedSubBenefitText(selectedOption.text);
      
      setFormData(prev => ({
        ...prev,
        subBenefit: numericValue,
      }));
    } else {
      // If no option found, clear the values
      setSelectedSubBenefit(null);
      setSelectedSubBenefitText('');
      setFormData(prev => ({
        ...prev,
        subBenefit: null,
      }));
    }
  }, [subBenefitOptions]);

  // Reset selected users when opening create dialog
  const resetSelectedUsers = useCallback(() => {
    console.log('resetSelectedUsers called - clearing all selections');
    // Batch state updates to prevent multiple re-renders
    setSelectedUsers([]);
    setUserSelectionError(null);
    setSelectedBenefit(null); // Clear selected benefit
    setSelectedSubBenefit(null); // Clear selected sub benefit
    setSelectedSubBenefitText(''); // Clear selected sub benefit text
    setFormData(prev => ({
      ...prev,
      ratio: 1.0,
      cases: 0,
      subBenefit: null,
    }));
  }, []);

  // Save group
  const handleSave = useCallback(async () => {
    try {
      setSaving(true);
      setError(null);
      setSuccess(null);

      if (isNewGroup) {
        const newGroup = await groupApi.create(group as Omit<Group, 'id'>);
        setSuccess('Group created successfully!');
        setGroup(newGroup);
        
        // Save all unsaved users with the new group ID
        if (unsavedUsers.length > 0) {
          try {
            for (const unsavedUser of unsavedUsers) {
              const userToCreate: Omit<User, 'id'> = {
                groupId: newGroup.id,
                systemUserId: unsavedUser.systemUserId,
                fullname: unsavedUser.fullname,
                userCode: unsavedUser.userCode,
                ratio: unsavedUser.ratio,
                cases: unsavedUser.cases,
              };
              await userApi.create(userToCreate);
            }
            // Clear unsaved users after successful creation
            setUnsavedUsers([]);
            setSuccess(`Group and ${unsavedUsers.length} users created successfully!`);
          } catch (userError: any) {
            setError(`Group created but failed to save users: ${userError.message}`);
          }
        }
        
        // Update URL to show the new ID
        navigate(`/form/${newGroup.id}`, { replace: true });
      } else {
        await groupApi.update(id!, group);
        setSuccess('Group updated successfully!');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to save group');
    } finally {
      setSaving(false);
    }
  }, [isNewGroup, group, id, unsavedUsers, navigate]);

  // Save and close
  const handleSaveAndClose = useCallback(async () => {
    await handleSave();
    if (!error) {
      navigate('/');
    }
  }, [handleSave, error, navigate]);

  // Delete group
  const handleDelete = useCallback(async () => {
    if (isNewGroup) return;

    if (window.confirm('Are you sure you want to delete this group?')) {
      try {
        setSaving(true);
        setError(null);
        await groupApi.delete(id!);
        navigate('/');
      } catch (err: any) {
        setError(err.message || 'Failed to delete group');
        setSaving(false);
      }
    }
  }, [isNewGroup, id, navigate]);



  // Helper: columns cho LookupField Benefit
  const getBenefitLookupColumns = () => [
    createTableColumn<Benefit>({
      columnId: 'cr350_name',
      renderCell: (item) => <DataGridCell>{item.cr350_name}</DataGridCell>,
    }),
    createTableColumn<Benefit>({
      columnId: 'cr350_code',
      renderCell: (item) => <DataGridCell>{item.cr350_code || 'N/A'}</DataGridCell>,
    }),
    createTableColumn<Benefit>({
      columnId: 'cr350_description',
      renderCell: (item) => <DataGridCell>{item.cr350_description}</DataGridCell>,
    }),
  ];

  // Helper: columns cho LookupField User
  const getSystemUserLookupColumns = () => [
    createTableColumn<SystemUser>({
      columnId: 'fullname',
      renderCell: (item) => <DataGridCell>{item.fullname}</DataGridCell>,
    }),
    createTableColumn<SystemUser>({
      columnId: 'userCode',
      renderCell: (item) => <DataGridCell>{item.userCode}</DataGridCell>,
    }),
  ];

  // Memoize columns to prevent unnecessary re-renders
  const benefitLookupColumns = useMemo(() => getBenefitLookupColumns(), []);
  const systemUserLookupColumns = useMemo(() => getSystemUserLookupColumns(), []);

  // Memoize grid columns to prevent unnecessary re-renders
  const benefitGridColumns = useMemo(() => [
    createTableColumn<Benefit>({
      columnId: 'cr350_name',
      compare: (a, b) => a.cr350_name.localeCompare(b.cr350_name),
      renderHeaderCell: () => 'Benefit Name',
      renderCell: (item) => item.cr350_name,
    }),
    createTableColumn<Benefit>({
      columnId: 'cr350_code',
      compare: (a, b) => (a.cr350_code || '').localeCompare(b.cr350_code || ''),
      renderHeaderCell: () => 'Benefit Code',
      renderCell: (item) => item.cr350_code || 'N/A',
    }),
    // createTableColumn<Benefit>({
    //   columnId: 'cr350_description',
    //   compare: (a, b) => a.cr350_description.localeCompare(b.cr350_description),
    //   renderHeaderCell: () => 'Description',
    //   renderCell: (item) => item.cr350_description,
    // }),
    createTableColumn<Benefit>({
      columnId: 'subBenefit',
      compare: (a, b) => (a.subBenefit || 0) - (b.subBenefit || 0),
      renderHeaderCell: () => 'Sub Benefit',
      renderCell: (item) => {
        const option = subBenefitOptions.find(opt => parseFloat(opt.key) === item.subBenefit);
        return option ? option.text : item.subBenefit || '';
      },
    }),
  ], [subBenefitOptions]);

  const userGridColumns = useMemo(() => [
    createTableColumn<User>({
      columnId: 'fullname',
      compare: (a, b) => a.fullname.localeCompare(b.fullname),
      renderHeaderCell: () => 'Full Name',
      renderCell: (item) => item.fullname,
    }),
    createTableColumn<User>({
      columnId: 'userCode',
      compare: (a, b) => a.userCode.localeCompare(b.userCode),
      renderHeaderCell: () => 'User Code',
      renderCell: (item) => item.userCode,
    }),
    createTableColumn<User>({
      columnId: 'cases',
      compare: (a, b) => (a.cases || 0) - (b.cases || 0),
      renderHeaderCell: () => 'Cases',
      renderCell: (item) => item.cases || 0,
    }),
    createTableColumn<User>({
      columnId: 'ratio',
      compare: (a, b) => (a.ratio || 0) - (b.ratio || 0),
      renderHeaderCell: () => 'Ratio',
      renderCell: (item) => (item.ratio || 0).toFixed(2),
    }),
  ], []);

  // Benefit create form fields
  const benefitCreateFormFields = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <LookupField<Benefit>
        label="Benefit"
        value={selectedBenefit}
        onChange={handleBenefitSelectionChange}
        fetchItems={fetchAllBenefits}
        displayField="cr350_name"
        columns={benefitLookupColumns}
        required
        multiple={false}
      />
      {selectedBenefit?.cr350_name === "Healthcare" && (
        <Field label="Sub benefit">
          <Combobox
            value={selectedSubBenefitText}
            onOptionSelect={handleSubBenefitChange}
            placeholder="Select sub benefit..."
          >
            {subBenefitOptions.map(option => (
              <Option key={option.key} value={option.key}>
                {option.text}
              </Option>
            ))}
          </Combobox>
        </Field>
      )}
      {/* Hiển thị thông tin benefit đã chọn */}
      {selectedBenefit && (
        <div style={{ padding: '12px', backgroundColor: '#f5f5f5', borderRadius: '4px' }}>
          <div><strong>Benefit Code:</strong> {selectedBenefit.cr350_code || 'N/A'}</div>
          <div><strong>Description:</strong> {selectedBenefit.cr350_description}</div>
        </div>
      )}
    </div>
  );

  // Benefit edit form fields
  const benefitEditFormFields = useMemo(() => (benefit: Benefit) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <LookupField<Benefit>
        label="Benefit"
        value={selectedBenefit || benefit}
        onChange={handleBenefitSelectionChange}
        fetchItems={fetchAllBenefits}
        displayField="cr350_name"
        columns={benefitLookupColumns}
        required
        multiple={false}
      />
      {(selectedBenefit?.cr350_name === "Healthcare" || benefit?.cr350_name === "Healthcare") && (
        <Field label="Sub benefit">
          <Combobox
            value={selectedSubBenefitText}
            onOptionSelect={handleSubBenefitChange}
            placeholder="Select sub benefit..."
          >
            {subBenefitOptions.map(option => (
              <Option key={option.key} value={option.key}>
                {option.text}
              </Option>
            ))}
          </Combobox>
        </Field>
      )}
      {/* Hiển thị thông tin benefit đã chọn */}
      {(selectedBenefit || benefit) && (
        <div style={{ padding: '12px', backgroundColor: '#f5f5f5', borderRadius: '4px' }}>
          <div><strong>Benefit Code:</strong> {(selectedBenefit || benefit)?.cr350_code || 'N/A'}</div>
          <div><strong>Description:</strong> {(selectedBenefit || benefit)?.cr350_description}</div>
        </div>
      )}
    </div>
  ), [handleBenefitSelectionChange, fetchAllBenefits, benefitLookupColumns, selectedBenefit, selectedSubBenefitText, handleSubBenefitChange, subBenefitOptions]);

  // User create form fields
  const userCreateFormFields = useMemo(() => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <LookupField<SystemUser>
        label="System User"
        value={selectedUsers}
        onChange={handleUserSelectionChange}
        fetchItems={fetchAllSystemUsers}
        displayField="fullname"
        columns={systemUserLookupColumns}
        required
        multiple={true}
        error={userSelectionError} // Truyền lỗi duplicate user vào LookupField
      />
      <Field label="Ratio" required>
        <Input
          type="number"
          step="0.1"
          value={formData.ratio?.toString() || '1.0'}
          onChange={handleRatioChange}
        />
      </Field>
      <Field label="Cases" required>
        <Input
          type="number"
          step="1"
          value={formData.cases?.toString() || '0'}
          onChange={handleCasesChange}
        />
      </Field>
    </div>
  ), [selectedUsers, handleUserSelectionChange, systemUserLookupColumns, formData.ratio, formData.cases, handleRatioChange, handleCasesChange, userSelectionError]);

  // User edit form fields
  const userEditFormFields = useMemo(() => (user: User) => {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <LookupField<SystemUser>
          label="System User"
          value={null} // Sẽ được load từ API
          onChange={handleSystemUserSelectionChange}
          fetchItems={fetchAllSystemUsers}
          displayField="fullname"
          columns={systemUserLookupColumns}
          required
          multiple={false}
        />
        <Field label="Ratio" required>
          <Input
            type="number"
            step="0.1"
            value={formData.ratio?.toString() || user.ratio?.toString() || '0'}
            onChange={handleRatioChange}
          />
        </Field>
      </div>
    );
  }, [handleSystemUserSelectionChange, systemUserLookupColumns, formData.ratio, handleRatioChange]);

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '400px' }}>
        <Spinner size="large" label="Loading group..." />
      </div>
    );
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: '#f8f8f8' }}>
      {/* Header */}
      <div style={{ 
        padding: '8px 20px',
        backgroundColor: '#fff',
        borderBottom: '1px solid #e1e1e1',
        display: 'flex',
        alignItems: 'center',
        gap: '12px'
      }}>
        <Button
          appearance="subtle"
          icon={<ArrowLeftRegular />}
          onClick={() => navigate('/')}
        >
          Back to List
        </Button>
        <Button
          appearance="primary"
          icon={<SaveRegular />}
          onClick={handleSave}
          disabled={saving}
        >
          {saving ? 'Saving...' : 'Save'}
        </Button>
        <Button
          appearance="secondary"
          icon={<SaveRegular />}
          onClick={handleSaveAndClose}
          disabled={saving}
        >
          Save & Close
        </Button>
        {!isNewGroup && (
          <Button
            appearance="subtle"
            icon={<DeleteRegular />}
            onClick={handleDelete}
            disabled={saving}
          >
            Delete
          </Button>
        )}
      </div>

      {/* Title */}
      <div style={{ 
        padding: '16px 20px',
        backgroundColor: '#fff',
        borderBottom: '1px solid #e1e1e1',
        marginBottom: '1px'
      }}>
        <h1 style={{ 
          margin: 0,
          fontSize: '24px',
          fontWeight: '600'
        }}>{isNewGroup ? 'Create New Group' : 'Edit Group'}</h1>
      </div>

      {/* Messages */}
      <div style={{ padding: '0 20px' }}>
        {error && (
          <MessageBar intent="error" style={{ marginBottom: '16px' }}>
            {error}
          </MessageBar>
        )}

        {success && (
          <MessageBar intent="success" style={{ marginBottom: '16px' }}>
            {success}
          </MessageBar>
        )}
      </div>

      {/* Content */}
      <div style={{ 
        flex: 1,
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        gap: '24px',
        overflow: 'auto'
      }}>
        {/* Form Fields */}
        <div style={{ 
          backgroundColor: '#fff',
          padding: '20px',
          borderRadius: '2px',
          boxShadow: '0 1.6px 3.6px 0 rgba(0,0,0,0.132), 0 0.3px 0.9px 0 rgba(0,0,0,0.108)'
        }}>
          <div style={{ maxWidth: '400px' }}>
            <Field label="Group Name" required>
              <Input
                value={group.groupName || ''}
                onChange={(e, data) => {
                  const value = data?.value ?? e.target?.value ?? '';
                  handleFieldChange('groupName', value);
                }}
                placeholder="Enter group name"
              />
            </Field>
            <Field label="Assignment Priority" required style={{ marginTop: '16px' }}>
              <Input
                type="number"
                value={group.assignmentPriority?.toString() || '0'}
                onChange={(e, data) => {
                  const value = data?.value ?? e.target?.value ?? '0';
                  handleFieldChange('assignmentPriority', parseInt(value) || 0);
                }}
                placeholder="Enter priority"
              />
            </Field>
          </div>
        </div>

        {/* Subgrids */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
          {/* Benefits Subgrid */}
          <div style={{ 
            backgroundColor: '#fff',
            borderRadius: '2px',
            boxShadow: '0 1.6px 3.6px 0 rgba(0,0,0,0.132), 0 0.3px 0.9px 0 rgba(0,0,0,0.108)'
          }}>
            <Subgrid
              title="Benefits"
              groupId={isNewGroup ? 'new' : id!}
              columns={benefitGridColumns}
              apiServiceFunctions={benefitApiServiceFunctionsRef.current}
              createFormFields={benefitCreateFormFields}
              editFormFields={benefitEditFormFields}
              getCreateData={() => {
                if (!selectedBenefit) return null;
                
                const createData: any = {
                  groupId: isNewGroup ? 'new' : id!,
                  cr350_name: selectedBenefit.cr350_name,
                  cr350_description: selectedBenefit.cr350_description,
                  cr350_code: selectedBenefit.cr350_code, // Thêm cr350_code vào create data
                };
                
                // Only include subBenefit if the selected benefit is "Healthcare"
                if (selectedBenefit.cr350_name === "Healthcare" && selectedSubBenefit) {
                  createData.subBenefit = selectedSubBenefit;
                }
                
                return createData;
              }}
              onOpenCreateDialog={() => {
                // Reset benefit-related states when opening create dialog
                setSelectedBenefit(null);
                setSelectedSubBenefit(null);
                setSelectedSubBenefitText('');
                setFormData(prev => ({
                  ...prev,
                  subBenefit: null,
                }));
              }}
              onCloseCreateDialog={() => {
                // Don't clear selected users immediately when dialog closes
                // This allows the user to see their selection and make changes if needed
                console.log('Dialog closed, keeping selectedUsers:', selectedUsers);
                // Only clear if there was an error or if explicitly requested
                if (userSelectionError) {
                  setSelectedUsers([]);
                  setUserSelectionError(null);
                }
              }}
            />
          </div>

          {/* Users Subgrid */}
          <div style={{ 
            backgroundColor: '#fff',
            borderRadius: '2px',
            boxShadow: '0 1.6px 3.6px 0 rgba(0,0,0,0.132), 0 0.3px 0.9px 0 rgba(0,0,0,0.108)'
          }}>
            <Subgrid
              key={`users-${refreshUsersSubgrid}`}
              title="Users"
              groupId={isNewGroup ? 'new' : id!}
              columns={userGridColumns}
              apiServiceFunctions={userApiServiceFunctionsRef.current}
              createFormFields={userCreateFormFields}
              editFormFields={userEditFormFields}
              onDataChange={handleUsersDataChange}
              getCreateData={() => {
                // Return the selected users with default ratio and cases
                const usersToCreate = selectedUsers.map(systemUser => ({
                  groupId: isNewGroup ? 'new' : id!,
                  systemUserId: systemUser.id,
                  fullname: systemUser.fullname,
                  userCode: systemUser.userCode,
                  ratio: formData.ratio || 1.0,
                  cases: formData.cases || 0,
                }));
                
                // Nếu có nhiều users, return mảng để Subgrid xử lý từng user một
                // Điều này sẽ cho phép hiển thị lỗi đúng cách
                if (usersToCreate.length > 1) {
                  return usersToCreate; // Return mảng thay vì null
                }
                
                return usersToCreate[0] || {};
              }}
              onOpenCreateDialog={resetSelectedUsers} // Pass the reset function
              onCloseCreateDialog={() => {
                // Don't clear selected users immediately when dialog closes
                // This allows the user to see their selection and make changes if needed
                console.log('Users dialog closed, keeping selectedUsers:', selectedUsers);
                // Only clear if there was an error or if explicitly requested
                if (userSelectionError) {
                  setSelectedUsers([]);
                  setUserSelectionError(null);
                }
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default React.memo(GroupFormPage); 