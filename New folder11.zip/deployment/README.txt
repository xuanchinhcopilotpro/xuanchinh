🚀 DYNAMICS 365 GROUP MANAGEMENT - DEPLOYMENT PACKAGE
================================================================

📦 PACKAGE CONTENTS:
- main.c718c8b0.js          (JavaScript Bundle)
- main.439ec562.css         (CSS Bundle)  
- loader_dynamics365.html   (HTML Loader)
- DEPLOYMENT_GUIDE.md       (Chi tiết hướng dẫn)
- WEB_RESOURCES_MANIFEST.txt (Thông tin Web Resources)

🔧 QUICK START:
1. Upload 3 files as Web Resources trong Dynamics 365
2. Thêm vào Site Map  
3. Cấp quyền Security Role
4. Test application

📖 CHI TIẾT:
Xem file DEPLOYMENT_GUIDE.md để có hướng dẫn đầy đủ.

⚠️ LƯU Ý:
- App hiện đang dùng Mock API
- Cho production cần cấu hình API thực
- Test trước khi deploy production

📞 SUPPORT:
Liên hệ team development nếu cần hỗ trợ.

================================================================
Group Management v1.0.0 - Ready for Dynamics 365 Deployment

