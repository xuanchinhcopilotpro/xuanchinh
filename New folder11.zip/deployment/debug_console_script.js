// 🔍 DYNAMICS 365 REACT APP DEBUG SCRIPT
// Copy và paste script này vào Browser Console trong D365

console.log('%c🔍 D365 REACT APP DEBUG STARTED', 'color: blue; font-size: 16px; font-weight: bold;');
console.log('=' .repeat(50));

// 1. ENVIRONMENT CHECK
console.log('%c📍 ENVIRONMENT INFO:', 'color: green; font-weight: bold;');
console.log('URL:', window.location.href);
console.log('Protocol:', window.location.protocol);
console.log('Host:', window.location.host);
console.log('Is D365:', window.location.href.includes('crm.dynamics.com') || window.location.href.includes('crm.'));
console.log('User Agent:', navigator.userAgent.substring(0, 100));

// 2. DOM CHECK
console.log('%c🏗️ DOM INFO:', 'color: orange; font-weight: bold;');
console.log('Root element exists:', !!document.getElementById('root'));
console.log('Document ready state:', document.readyState);
console.log('Total DOM elements:', document.querySelectorAll('*').length);

// 3. REACT CHECK
console.log('%c⚛️ REACT INFO:', 'color: cyan; font-weight: bold;');
console.log('React available:', typeof React !== 'undefined' ? '✅ YES' : '❌ NO');
console.log('ReactDOM available:', typeof ReactDOM !== 'undefined' ? '✅ YES' : '❌ NO');
console.log('Init function available:', typeof window.initializeGroupManagementApp !== 'undefined' ? '✅ YES' : '❌ NO');

// 4. WEB RESOURCES CHECK
console.log('%c🌐 WEB RESOURCES TEST:', 'color: purple; font-weight: bold;');

const webResources = [
    'new_groupmanagement_main_js',
    'new_groupmanagement_main_css',
    'new_groupmanagement_loader_html'
];

async function testWebResources() {
    for (const resource of webResources) {
        try {
            const url = `/WebResources/${resource}`;
            const response = await fetch(url, { method: 'HEAD' });
            console.log(`${resource}:`, response.status === 200 ? '✅ ACCESSIBLE' : `❌ ERROR ${response.status}`);
        } catch (error) {
            console.log(`${resource}:`, '❌ NETWORK ERROR', error.message);
        }
    }
}

testWebResources();

// 5. DYNAMICS 365 CONTEXT CHECK
console.log('%c🏢 DYNAMICS 365 CONTEXT:', 'color: red; font-weight: bold;');
console.log('Xrm available:', typeof Xrm !== 'undefined' ? '✅ YES' : '❌ NO');
if (typeof Xrm !== 'undefined') {
    console.log('Xrm.Utility available:', typeof Xrm.Utility !== 'undefined' ? '✅ YES' : '❌ NO');
    console.log('Xrm.Page available:', typeof Xrm.Page !== 'undefined' ? '✅ YES' : '❌ NO');
}

// 6. SECURITY CHECK
console.log('%c🔐 SECURITY INFO:', 'color: brown; font-weight: bold;');
console.log('Local Storage available:', typeof Storage !== 'undefined' ? '✅ YES' : '❌ NO');
console.log('Session Storage available:', typeof sessionStorage !== 'undefined' ? '✅ YES' : '❌ NO');
console.log('Console available:', typeof console !== 'undefined' ? '✅ YES' : '❌ NO');

// 7. NETWORK PERFORMANCE
console.log('%c⚡ PERFORMANCE:', 'color: darkgreen; font-weight: bold;');
if (window.performance && window.performance.timing) {
    const timing = window.performance.timing;
    const loadTime = timing.loadEventEnd - timing.navigationStart;
    console.log('Page load time:', loadTime + 'ms');
    console.log('DOM ready time:', (timing.domContentLoadedEventEnd - timing.navigationStart) + 'ms');
}

// 8. ERROR DETECTION
console.log('%c🐛 ERROR DETECTION:', 'color: red; font-weight: bold;');

// Check for existing errors
const errors = [];
const originalError = window.onerror;
window.onerror = function(message, source, lineno, colno, error) {
    errors.push({
        message: message,
        source: source,
        line: lineno,
        column: colno,
        error: error
    });
    console.error('CAPTURED ERROR:', message, 'at', source + ':' + lineno);
    if (originalError) originalError.apply(this, arguments);
};

console.log('Error monitoring enabled. Check for new errors above.');

// 9. FINAL SUMMARY
setTimeout(() => {
    console.log('%c📊 DEBUG SUMMARY:', 'color: blue; font-size: 14px; font-weight: bold;');
    console.log('=' .repeat(50));
    
    const summary = {
        'Environment': window.location.href.includes('crm.') ? '✅ Dynamics 365' : '❌ Not D365',
        'DOM Ready': document.readyState === 'complete' ? '✅ Complete' : '⚠️ ' + document.readyState,
        'React Available': typeof React !== 'undefined' ? '✅ Loaded' : '❌ Missing',
        'Root Element': document.getElementById('root') ? '✅ Found' : '❌ Missing',
        'Errors Detected': errors.length === 0 ? '✅ None' : `❌ ${errors.length} errors`
    };
    
    for (const [key, value] of Object.entries(summary)) {
        console.log(`${key}: ${value}`);
    }
    
    console.log('=' .repeat(50));
    console.log('%c🎯 NEXT STEPS:', 'color: green; font-weight: bold;');
    
    if (typeof React === 'undefined') {
        console.log('1. ❌ React not loaded - Check JS Web Resource');
    } else if (!document.getElementById('root')) {
        console.log('1. ❌ Root element missing - Check HTML Web Resource');
    } else if (errors.length > 0) {
        console.log('1. ❌ JavaScript errors detected - Check error details above');
    } else {
        console.log('1. ✅ All basic checks passed - App should be working');
    }
    
    console.log('2. 📸 Screenshot this console output');
    console.log('3. 🌐 Check Network tab for failed requests');
    console.log('4. 🔐 Verify user permissions');
    
}, 3000);

console.log('🔍 Debug script completed. Wait 3 seconds for summary...');

