# Dynamics 365 Group Management Web Resource

Ứng dụng React để quản lý Groups, Benefits và Users trong Dynamics 365 Sales.

## Tính năng

- **Trang danh sách Groups**: Hiển thị danh sách tất cả groups với khả năng tìm kiếm và lọc
- **Form quản lý Group**: Tạo mới và chỉnh sửa thông tin group
- **Subgrid Benefits**: Quản lý benefits của từng group
- **Subgrid Users**: Quản lý users của từng group
- **Giao diện Fluent UI**: Đồng bộ với thiết kế của Microsoft Dynamics 365

## Kiến trúc API

Ứng dụng sử dụng 2 loại API khác nhau:

### 1. Dynamics 365 APIs (Cho Lookup Fields)
- **SystemUser**: Lấy danh sách system users từ D365
- **Benefit**: Lấy danh sách benefits từ D365 (cho lookup)

### 2. External APIs (Cho Subgrid Data)
- **Groups**: CRUD operations cho groups (ListPage)
- **Benefits**: CRUD operations cho benefits của group (FormPage)
- **Users**: CRUD operations cho users của group (FormPage)

## Cấu trúc dự án

```
src/
├── api/              # API service functions
│   ├── apiService.ts     # D365 APIs + External APIs
│   ├── mockApiService.ts # Mock API cho development
│   └── mockData.ts       # Mock data cho development
├── components/       # Reusable components
│   ├── LookupField.tsx   # Component lookup field
│   └── Subgrid.tsx       # Component subgrid
├── hooks/           # Custom React hooks
├── models/          # TypeScript interfaces
├── pages/           # Main page components
└── contexts/        # React contexts
```

## Cài đặt và chạy

### Yêu cầu hệ thống
- Node.js 16+ 
- npm hoặc yarn

### Cài đặt dependencies
```bash
npm install
```

### Cấu hình Token cho Dynamics 365

Để kết nối với Dynamics 365, bạn cần cấu hình token authentication. Có 3 cách:

#### Cách 1: Thay đổi token trực tiếp trong code
Chỉnh sửa file `src/api/apiService.ts`, dòng 15:
```typescript
return 'YOUR_D365_TOKEN_HERE'; // Thay thế bằng token thực của bạn
```

#### Cách 2: Sử dụng Environment Variable
Tạo file `.env` trong thư mục gốc:
```env
REACT_APP_D365_TOKEN=your_actual_token_here
REACT_APP_D365_API_BASE_URL=https://your-org.crm.dynamics.com/api/data/v9.2
REACT_APP_API_BASE_URL=http://localhost:3001/api
```

#### Cách 3: Lưu token trong localStorage (cho development)
Mở Developer Tools (F12) và chạy:
```javascript
localStorage.setItem('d365_token', 'your_actual_token_here');
```

### Chạy ứng dụng development
```bash
npm start
```

### Build cho production
```bash
npm run build
```

## Cấu hình API

### Dynamics 365 API Endpoints (Cho Lookup Fields)

#### SystemUsers
- `GET /systemusers?$select=systemuserid,fullname,employeeid` - Lấy danh sách system users
- `GET /systemusers({id})?$select=systemuserid,fullname,employeeid` - Lấy chi tiết system user

#### Benefits (Lookup)
- `GET /benefits?$top=1000` - Lấy danh sách tất cả benefits (cho lookup)

### External API Endpoints (Cho Subgrid Data)

#### Groups
- `GET /groups` - Lấy danh sách tất cả groups
- `GET /groups/{id}` - Lấy chi tiết group theo ID
- `POST /groups` - Tạo mới group
- `PUT /groups/{id}` - Cập nhật group
- `DELETE /groups/{id}` - Xóa group

#### Benefits
- `GET /groups/{groupId}/benefits` - Lấy benefits theo group
- `POST /benefits` - Tạo mới benefit
- `PUT /benefits/{id}` - Cập nhật benefit
- `DELETE /benefits/{id}` - Xóa benefit

#### Users
- `GET /groups/{groupId}/users` - Lấy users theo group
- `POST /users` - Tạo mới user
- `PUT /users/{id}` - Cập nhật user
- `DELETE /users/{id}` - Xóa user

### Cấu hình Environment Variables

Tạo file `.env` trong thư mục gốc và cấu hình:

```env
# Dynamics 365 Configuration (Cho Lookup Fields)
REACT_APP_D365_API_BASE_URL=https://your-org.crm.dynamics.com/api/data/v9.2
REACT_APP_D365_TOKEN=your_actual_token_here

# External API Configuration (Cho Subgrid Data)
REACT_APP_API_BASE_URL=http://localhost:3001/api

# Development Configuration
REACT_APP_USE_MOCK_API=false
```

## Triển khai lên Dynamics 365

### Bước 1: Build ứng dụng
```bash
npm run build
```

### Bước 2: Tạo Web Resources trong Dynamics 365

1. Vào **Settings** > **Advanced Settings** > **Customizations** > **Customize the System**
2. Tìm đến mục **Web Resources**
3. Tạo các Web Resources sau:

#### JavaScript Web Resource
- **Name**: `new_react_group_management.js`
- **Type**: Script (JScript)
- **Upload**: File `build/static/js/main.bundle.js`

#### CSS Web Resource (nếu có)
- **Name**: `new_react_group_management.css`
- **Type**: Style Sheet (CSS)
- **Upload**: File `build/static/css/main.bundle.css`

#### HTML Web Resource
- **Name**: `new_main_loader.html`
- **Type**: Webpage (HTML)
- **Upload**: File `build/loader.html`

### Bước 3: Tạo Form trong Dynamics 365

1. Vào **Settings** > **Customizations** > **Customize the System**
2. Tìm entity cần thêm form (ví dụ: Account, Contact)
3. Tạo form mới hoặc chỉnh sửa form hiện có
4. Thêm Web Resource vào form
5. Cấu hình để load React app

## Lưu ý quan trọng

### Security
- **Token Security**: Không commit token vào source code. Sử dụng environment variables hoặc secure storage.
- **CORS**: Đảm bảo Dynamics 365 cho phép CORS từ domain của ứng dụng.
- **API Permissions**: Token cần có quyền truy cập vào các entity và API endpoints cần thiết.

### Performance
- **Pagination**: API sử dụng `$top=1000` để lấy dữ liệu, có thể cần điều chỉnh theo nhu cầu.
- **Caching**: Implement caching cho data thường xuyên sử dụng.
- **Error Handling**: Xử lý lỗi network và API errors.

### Development
- **Mock Data**: Sử dụng mock data cho development khi không có access đến Dynamics 365.
- **Environment**: Tách biệt configuration cho development và production.

## Troubleshooting

### Lỗi Authentication
- Kiểm tra token có hợp lệ không
- Kiểm tra token có quyền truy cập API không
- Kiểm tra URL API có đúng không

### Lỗi CORS
- Đảm bảo Dynamics 365 cho phép CORS
- Kiểm tra domain trong cấu hình CORS

### Lỗi API
- Kiểm tra API endpoint có tồn tại không
- Kiểm tra request headers có đúng không
- Kiểm tra response format có đúng không

### Lỗi Build
- Kiểm tra TypeScript errors
- Kiểm tra dependencies có đầy đủ không
- Kiểm tra environment variables có đúng không

## Development Workflow

1. **Setup Development Environment**
   ```bash
   npm install
   cp .env.example .env
   # Cấu hình .env file
   ```

2. **Run Development Server**
   ```bash
   npm start
   ```

3. **Test with Mock Data**
   - Ứng dụng sẽ sử dụng mock data khi không có token
   - Có thể test tất cả tính năng với mock data

4. **Test with Real API**
   - Cấu hình token trong .env hoặc localStorage
   - Test với Dynamics 365 API thực

5. **Build for Production**
   ```bash
   npm run build
   ```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License.
