# 🔍 Debug Dynamics 365 Deployment - Checklist

## ❗ Vấn đề: Không thấy gì hiển thị sau khi deploy

### 🚀 **BƯỚC 1: Kiểm tra Browser Console (ĐỒU TIÊN)**

1. **Mở Dynamics 365 tại page có Web Resource**
2. **Nhấn F12** để mở Developer Tools
3. **Vào tab Console** 
4. **Kiểm tra errors:**

```
❌ Lỗi thường gặp:
- "Failed to load resource: net::ERR_NAME_NOT_RESOLVED"
- "Uncaught ReferenceError: React is not defined" 
- "404 Not Found" cho Web Resources
- "Access denied" hoặc permission errors
- CORS errors
```

**📱 Actions:**
- [ ] Screenshot tất cả errors trong Console
- [ ] Note lại tên Web Resources bị lỗi
- [ ] Kiểm tra tab Network để xem requests nào fail

---

### 🔧 **BƯỚC 2: Verify Web Resources**

#### 2.1 Kiểm tra Web Resources đã upload

1. **Settings** → **Advanced Settings** → **Customizations** → **Web Resources**
2. **Tìm 3 Web Resources:**
   - `new_groupmanagement_main_js`
   - `new_groupmanagement_main_css`  
   - `new_groupmanagement_loader_html`

**✅ Checklist:**
- [ ] Tất cả 3 Web Resources tồn tại
- [ ] File size > 0 (không empty)
- [ ] Published (có icon published)
- [ ] Tên chính xác không có typo

#### 2.2 Test Web Resources trực tiếp

**Test HTML Web Resource:**
```
https://[org].crm.dynamics.com/WebResources/new_groupmanagement_loader_html
```

**Expected:** Thấy loading spinner hoặc HTML content

**Test JS Web Resource:**
```
https://[org].crm.dynamics.com/WebResources/new_groupmanagement_main_js
```

**Expected:** Download file JavaScript

**📱 Actions:**
- [ ] Test access trực tiếp qua URL
- [ ] Verify file content không bị corrupt
- [ ] Check file size matches build files

---

### 🔐 **BƯỚC 3: Security & Permissions**

#### 3.1 User Security Role

1. **Settings** → **Security** → **Security Roles**
2. **Chọn role của user hiện tại**
3. **Tab Customization:**
   - **Web Resources**: Cần **Read** permission
   - **System Forms**: **Read** permission

**📱 Actions:**
- [ ] Verify user có đúng Security Role
- [ ] Check Read permission cho Web Resources
- [ ] Test với System Administrator role

#### 3.2 Business Unit & Teams

- [ ] User thuộc đúng Business Unit
- [ ] Web Resources được share với đúng team/users

---

### 🗺️ **BƯỚC 4: Site Map Configuration**

#### 4.1 Kiểm tra Site Map

1. **App Designer** → **Site Map**  
2. **Tìm Subarea Group Management**
3. **Properties:**
   - **Type**: Web Resource
   - **Web Resource**: `new_groupmanagement_loader_html`
   - **URL**: `$webresource:new_groupmanagement_loader_html`

**📱 Actions:**
- [ ] Verify Web Resource name chính xác
- [ ] Check typo trong URL
- [ ] Test với Web Resource URL trực tiếp

#### 4.2 App Publishing

- [ ] App đã được **Published**
- [ ] User có access vào App
- [ ] Site Map changes được save

---

### 🛠️ **BƯỚC 5: HTML Loader Issues**

#### 5.1 Check HTML References

**Open HTML Web Resource và kiểm tra:**

```html
<!-- Phải có đúng tên Web Resources -->
<link rel="stylesheet" type="text/css" href="new_groupmanagement_main_css">
<script src="new_groupmanagement_main_js"></script>
```

**❌ Lỗi thường gặp:**
- Tên Web Resource sai
- Missing CSS hoặc JS reference
- Path không đúng

#### 5.2 Test HTML Content

**📱 Actions:**
- [ ] View source của HTML Web Resource
- [ ] Verify references đúng tên
- [ ] Check JavaScript initialization

---

### 🌐 **BƯỚC 6: Network & Loading Issues**

#### 6.1 Network Tab Analysis

1. **F12** → **Network tab**
2. **Reload page**
3. **Kiểm tra:**
   - Tất cả requests thành công (status 200)
   - No 404 errors
   - File sizes correct

**📱 Actions:**
- [ ] Screenshot Network tab
- [ ] Check failed requests
- [ ] Verify file loading order

#### 6.2 Performance Issues

- [ ] Large bundle size causing timeout
- [ ] Slow network in D365 environment  
- [ ] Memory issues with React app

---

### 🐛 **BƯỚC 7: JavaScript Errors**

#### 7.1 React App Initialization

**Console errors related to:**
```javascript
// Check these in Console:
window.React
window.ReactDOM
window.initializeGroupManagementApp
```

**📱 Actions:**
- [ ] Verify React loads correctly
- [ ] Check ReactDOM.render executes
- [ ] Test initialization function

#### 7.2 Dependencies Issues

**Common errors:**
- Missing Fluent UI dependencies
- React Router errors
- Axios/API errors

---

### 🔧 **QUICK FIXES - Try These First**

#### Fix 1: Re-upload Web Resources
```
1. Delete existing Web Resources
2. Re-upload with exact names
3. Publish All Customizations
4. Clear browser cache
```

#### Fix 2: Test with Simple HTML
```html
<!-- Upload this as test Web Resource -->
<!DOCTYPE html>
<html>
<head><title>Test</title></head>
<body>
    <h1>Hello Dynamics 365!</h1>
    <script>console.log('Web Resource loaded!');</script>
</body>
</html>
```

#### Fix 3: Permissions Reset
```
1. Remove user from Security Role
2. Add back with full permissions
3. Test with System Administrator
```

#### Fix 4: Clear Cache
```
1. Browser cache (Ctrl+Shift+Delete)
2. D365 cache (Settings → Administration → System Settings → Clear cache)
3. Hard refresh (Ctrl+F5)
```

---

### 📞 **DEBUGGING COMMANDS**

**In Browser Console, run:**

```javascript
// Check if React loaded
console.log('React:', typeof React);
console.log('ReactDOM:', typeof ReactDOM);

// Check DOM element
console.log('Root element:', document.getElementById('root'));

// Check Web Resource URLs
console.log('Current URL:', window.location.href);

// Check for errors
console.log('Errors:', window.onerror);
```

---

### 🎯 **COMMON SOLUTIONS**

| Problem | Solution |
|---------|----------|
| **Console: 404 Web Resource** | Re-upload with exact names |
| **Console: Permission denied** | Check Security Role permissions |
| **Blank page, no errors** | Check HTML references |
| **React not defined** | Verify JS Web Resource loaded |
| **Site Map not working** | Check App published & user access |
| **Loading forever** | Check Network tab for failed requests |

---

### ✅ **SUCCESS INDICATORS**

**You know it's working when:**
- [ ] No console errors
- [ ] Network tab shows all 200 responses  
- [ ] React app renders in DOM
- [ ] Fluent UI components visible
- [ ] Navigation works

---

## 🚨 **EMERGENCY DEBUG - Run This Now**

**1. Open D365 page with Web Resource**
**2. Press F12**
**3. Console tab**
**4. Run this:**

```javascript
// Debug script - paste in Console
console.log('=== D365 REACT APP DEBUG ===');
console.log('URL:', window.location.href);
console.log('React:', typeof React);
console.log('ReactDOM:', typeof ReactDOM);
console.log('Root element:', document.getElementById('root'));
console.log('Init function:', typeof window.initializeGroupManagementApp);
console.log('Errors:', window.performance.getEntriesByType('navigation'));

// Test Web Resource access
fetch('/WebResources/new_groupmanagement_main_js')
  .then(r => console.log('JS accessible:', r.status))
  .catch(e => console.log('JS error:', e));

fetch('/WebResources/new_groupmanagement_main_css')
  .then(r => console.log('CSS accessible:', r.status))
  .catch(e => console.log('CSS error:', e));
```

**5. Screenshot results**
**6. Share với team development**

---

## 🔥 **NEXT STEPS**

**Based on console output:**

1. **404 errors** → Re-upload Web Resources
2. **Permission errors** → Fix Security Roles  
3. **React undefined** → Check JS Web Resource
4. **Blank + no errors** → Check HTML loader
5. **App loads but breaks** → Check API configuration

Let me know console output và tôi sẽ help specific! 🚀

