import * as React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { FluentProvider, webLightTheme } from '@fluentui/react-components';
import GroupListPage from './pages/GroupListPage.tsx';
import GroupFormPage from './pages/GroupFormPage.tsx';
import './App.css';

function App() {
  return (
    <FluentProvider theme={webLightTheme}>
      <Router>
        <div className="App">
          <Routes>
            <Route path="*" element={<GroupListPage />} />
            <Route path="/form/:id" element={<GroupFormPage />} />
          </Routes>
        </div>
      </Router>
    </FluentProvider>
  );
}

export default App; 