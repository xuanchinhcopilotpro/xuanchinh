import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Field,
  Input,
  Button,
  Spinner,
  MessageBar,
  createTableColumn,
  DataGridCell,
} from '@fluentui/react-components';
import { SaveRegular, DeleteRegular, ArrowLeftRegular } from '@fluentui/react-icons';
import { Group, Benefit, User, SystemUser } from '../models/types.ts';
import { 
  mockGroupApi, 
  mockBenefitApi, 
  mockUserApi,
  mockSystemUserApi
} from '../api/mockApiService.ts';
import Subgrid from '../components/Subgrid.tsx';
import LookupField from '../components/LookupField.tsx';

const GroupFormPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [group, setGroup] = useState<Partial<Group>>({
    groupName: '',
    assignmentPriority: 0,
  });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [formData, setFormData] = useState<any>({});
  const [refreshUsersSubgrid, setRefreshUsersSubgrid] = useState(0);
  const [unsavedUsers, setUnsavedUsers] = useState<User[]>([]); // State for unsaved users
  const [userSelectionError, setUserSelectionError] = useState<string | null>(null); // Thêm state để lưu lỗi khi chọn user
  const [selectedUsers, setSelectedUsers] = useState<SystemUser[]>([]); // State for selected users

  const isNewGroup = id === 'new';

  // Check if a user is already added (either in unsaved or saved)
  const isUserAlreadyAdded = useCallback(async (systemUserId: string | number) => {
    // Check in unsaved users
    const isInUnsaved = unsavedUsers.some(user => user.systemUserId === systemUserId);
    if (isInUnsaved) return true;
    
    // For existing groups, also check saved users
    if (!isNewGroup) {
      try {
        const existingUsers = await mockUserApi.getByGroupId(id!);
        return existingUsers.some(user => user.systemUserId === systemUserId);
      } catch (error) {
        console.error('Error checking existing users:', error);
        return false;
      }
    }
    
    return false;
  }, [unsavedUsers, isNewGroup, id]);

  // Create user function that handles both new and existing groups
  const createUserForGroup = useCallback(async (userData: Omit<User, 'id'>, skipDuplicateCheck = false) => {
    try {
      setUserSelectionError(null); // Clear error trước khi tạo
      
      // Check if user is already added
      if (!skipDuplicateCheck && await isUserAlreadyAdded(userData.systemUserId)) {
        setUserSelectionError(`User ${userData.fullName} is already added to this group`);
        return null; // Return null để không tạo user
      }

      if (isNewGroup) {
        // For new groups, add to local state
        const newUser: User = {
          ...userData,
          id: `temp-${Date.now()}-${Math.random()}`,
          groupId: 'new'
        };
        setUnsavedUsers(prev => [...prev, newUser]);
        return newUser;
      } else {
        // For existing groups, create via API
        return await mockUserApi.create(userData);
      }
    } catch (error) {
      setUserSelectionError(`Failed to create user: ${error instanceof Error ? error.message : 'Unknown error'}`);
      return null;
    }
  }, [isNewGroup, isUserAlreadyAdded]);

  // Wrapper function for Subgrid to ensure it always gets a User or throws an error
  const createUserForGroupWrapper = useCallback(async (userData: Omit<User, 'id'>) => {
    // Kiểm tra duplicate trước khi tạo
    if (await isUserAlreadyAdded(userData.systemUserId)) {
      throw new Error(`User ${userData.fullName} is already added to this group`);
    }
    
    const result = await createUserForGroup(userData);
    if (!result) {
      throw new Error('Failed to create user');
    }
    return result;
  }, [createUserForGroup, isUserAlreadyAdded]);

  // Callback to refresh users subgrid
  const handleUsersDataChange = useCallback(() => {
    // Only increment if we're not in the middle of creating users
    if (selectedUsers.length === 0) {
      setRefreshUsersSubgrid(prev => prev + 1);
    }
  }, [selectedUsers.length]);

  // Custom fetch function for users that combines saved and unsaved users
  const fetchUsersForGroup = useCallback(async (groupId: string | number) => {
    if (groupId === 'new') {
      // Get the current unsavedUsers value directly from the state
      return unsavedUsers;
    } else {
      // Return saved users from API for existing groups
      return await mockUserApi.getByGroupId(groupId);
    }
  }, [unsavedUsers]);

  // Custom update function for users
  const updateUserForGroup = useCallback(async (id: string | number, user: Partial<User>) => {
    if (isNewGroup) {
      // For new groups, update in local state
      setUnsavedUsers(prev => prev.map(u => u.id === id ? { ...u, ...user } : u));
      const updatedUser = unsavedUsers.find(u => u.id === id);
      return updatedUser!;
    } else {
      // For existing groups, update via API
      return await mockUserApi.update(id, user);
    }
  }, [isNewGroup, unsavedUsers]);

  // Custom delete function for users
  const deleteUserForGroup = useCallback(async (id: string | number) => {
    if (isNewGroup) {
      // For new groups, remove from local state
      setUnsavedUsers(prev => prev.filter(u => u.id !== id));
    } else {
      // For existing groups, delete via API
      await mockUserApi.delete(id);
    }
  }, [isNewGroup]);

  // Memoize API service functions to prevent unnecessary re-renders
  const userApiServiceFunctions = useMemo(() => ({
    fetch: fetchUsersForGroup,
    create: createUserForGroupWrapper,
    update: updateUserForGroup,
    delete: deleteUserForGroup,
  }), [fetchUsersForGroup, createUserForGroupWrapper, updateUserForGroup, deleteUserForGroup]);

  const benefitApiServiceFunctions = useMemo(() => ({
    fetch: mockBenefitApi.getByGroupId,
    create: mockBenefitApi.create,
    update: mockBenefitApi.update,
    delete: mockBenefitApi.delete,
  }), []);

  const loadGroup = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await mockGroupApi.getById(id!);
      setGroup(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load group');
    } finally {
      setLoading(false);
    }
  }, [id]);

  // Load group data if editing
  useEffect(() => {
    if (!isNewGroup && id) {
      loadGroup();
    }
  }, [id, isNewGroup, loadGroup]);

  // Handle field change with useCallback to prevent unnecessary re-renders
  const handleFieldChange = useCallback((field: keyof Group, value: any) => {
    setGroup(prev => ({ ...prev, [field]: value }));
  }, []);

  // Optimize form data updates
  const handleFormDataChange = useCallback((field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  }, []);

  // Handle user selection change
  const handleUserSelectionChange = useCallback((users: SystemUser | SystemUser[] | null) => {
    if (Array.isArray(users)) {
      setSelectedUsers(users);
      setUserSelectionError(null); // Clear error khi user thay đổi selection
    } else {
      setSelectedUsers(users ? [users] : []);
      setUserSelectionError(null); // Clear error khi user thay đổi selection
    }
  }, []);

  // Optimize benefit selection change
  const handleBenefitSelectionChange = useCallback((benefit: Benefit | Benefit[] | null) => {
    if (benefit && !Array.isArray(benefit)) {
      setFormData(prev => ({
        ...prev,
        benefitId: benefit.id,
        benefitName: benefit.benefitName,
        description: benefit.description,
      }));
    }
  }, []);

  // Optimize system user selection change
  const handleSystemUserSelectionChange = useCallback((systemUser: SystemUser | SystemUser[] | null) => {
    if (systemUser && !Array.isArray(systemUser)) {
      setFormData(prev => ({
        ...prev,
        systemUserId: systemUser.id,
        fullName: systemUser.fullName,
        userCode: systemUser.userCode,
      }));
    }
  }, []);

  // Optimize input change handlers
  const handleRatioChange = useCallback((e: React.ChangeEvent<HTMLInputElement>, data: { value: string }) => {
    const value = data?.value ?? e.target?.value ?? '1.0';
    handleFormDataChange('ratio', parseFloat(value) || 1.0);
  }, [handleFormDataChange]);

  const handleCasesChange = useCallback((e: React.ChangeEvent<HTMLInputElement>, data: { value: string }) => {
    const value = data?.value ?? e.target?.value ?? '0';
    handleFormDataChange('cases', parseInt(value) || 0);
  }, [handleFormDataChange]);

  // Reset selected users when opening create dialog
  const resetSelectedUsers = useCallback(() => {
    setSelectedUsers([]);
    setUserSelectionError(null);
    setFormData(prev => ({
      ...prev,
      ratio: 1.0,
      cases: 0,
    }));
  }, []);

  // Save group
  const handleSave = async () => {
    try {
      setSaving(true);
      setError(null);
      setSuccess(null);

      if (isNewGroup) {
        const newGroup = await mockGroupApi.create(group as Omit<Group, 'id'>);
        setSuccess('Group created successfully!');
        setGroup(newGroup);
        
        // Save all unsaved users with the new group ID
        if (unsavedUsers.length > 0) {
          try {
            for (const unsavedUser of unsavedUsers) {
              const userToCreate: Omit<User, 'id'> = {
                groupId: newGroup.id,
                systemUserId: unsavedUser.systemUserId,
                fullName: unsavedUser.fullName,
                userCode: unsavedUser.userCode,
                ratio: unsavedUser.ratio,
                cases: unsavedUser.cases,
              };
              await mockUserApi.create(userToCreate);
            }
            // Clear unsaved users after successful creation
            setUnsavedUsers([]);
            setSuccess(`Group and ${unsavedUsers.length} users created successfully!`);
          } catch (userError: any) {
            setError(`Group created but failed to save users: ${userError.message}`);
          }
        }
        
        // Update URL to show the new ID
        navigate(`/form/${newGroup.id}`, { replace: true });
      } else {
        await mockGroupApi.update(id!, group);
        setSuccess('Group updated successfully!');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to save group');
    } finally {
      setSaving(false);
    }
  };

  // Save and close
  const handleSaveAndClose = async () => {
    await handleSave();
    if (!error) {
      navigate('/');
    }
  };

  // Delete group
  const handleDelete = async () => {
    if (isNewGroup) return;

    if (window.confirm('Are you sure you want to delete this group?')) {
      try {
        setSaving(true);
        setError(null);
        await mockGroupApi.delete(id!);
        navigate('/');
      } catch (err: any) {
        setError(err.message || 'Failed to delete group');
        setSaving(false);
      }
    }
  };



  // Helper: columns cho LookupField Benefit
  const getBenefitLookupColumns = () => [
    createTableColumn<Benefit>({
      columnId: 'benefitName',
      renderCell: (item) => <DataGridCell>{item.benefitName}</DataGridCell>,
    }),
    createTableColumn<Benefit>({
      columnId: 'description',
      renderCell: (item) => <DataGridCell>{item.description}</DataGridCell>,
    }),
  ];

  // Helper: columns cho LookupField User
  const getSystemUserLookupColumns = () => [
    createTableColumn<SystemUser>({
      columnId: 'fullName',
      renderCell: (item) => <DataGridCell>{item.fullName}</DataGridCell>,
    }),
    createTableColumn<SystemUser>({
      columnId: 'userCode',
      renderCell: (item) => <DataGridCell>{item.userCode}</DataGridCell>,
    }),
  ];

  // Helper: fetchItems cho LookupField Benefit (từ D365)
  const fetchAllBenefits = useCallback(async () => {
    try {
      const data = await mockBenefitApi.getAll();
      return data || [];
    } catch (error) {
      console.error('Error fetching benefits:', error);
      return [];
    }
  }, []);

  // Helper: fetchItems cho LookupField User (từ D365)
  const fetchAllSystemUsers = useCallback(async () => {
    try {
      const data = await mockSystemUserApi.getAll();
      return data || [];
    } catch (error) {
      console.error('Error fetching system users:', error);
      return [];
    }
  }, []);

  // Memoize columns to prevent unnecessary re-renders
  const benefitLookupColumns = useMemo(() => getBenefitLookupColumns(), []);
  const systemUserLookupColumns = useMemo(() => getSystemUserLookupColumns(), []);

  // Memoize grid columns to prevent unnecessary re-renders
  const benefitGridColumns = useMemo(() => [
    createTableColumn<Benefit>({
      columnId: 'benefitName',
      compare: (a, b) => a.benefitName.localeCompare(b.benefitName),
      renderHeaderCell: () => 'Benefit Name',
      renderCell: (item) => item.benefitName,
    }),
    createTableColumn<Benefit>({
      columnId: 'description',
      compare: (a, b) => a.description.localeCompare(b.description),
      renderHeaderCell: () => 'Description',
      renderCell: (item) => item.description,
    }),
  ], []);

  const userGridColumns = useMemo(() => [
    createTableColumn<User>({
      columnId: 'fullName',
      compare: (a, b) => a.fullName.localeCompare(b.fullName),
      renderHeaderCell: () => 'Full Name',
      renderCell: (item) => item.fullName,
    }),
    createTableColumn<User>({
      columnId: 'userCode',
      compare: (a, b) => a.userCode.localeCompare(b.userCode),
      renderHeaderCell: () => 'User Code',
      renderCell: (item) => item.userCode,
    }),
    createTableColumn<User>({
      columnId: 'cases',
      compare: (a, b) => (a.cases || 0) - (b.cases || 0),
      renderHeaderCell: () => 'Cases',
      renderCell: (item) => item.cases || 0,
    }),
    createTableColumn<User>({
      columnId: 'ratio',
      compare: (a, b) => (a.ratio || 0) - (b.ratio || 0),
      renderHeaderCell: () => 'Ratio',
      renderCell: (item) => (item.ratio || 0).toFixed(2),
    }),
  ], []);

  // Benefit create form fields
  const benefitCreateFormFields = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <LookupField<Benefit>
        label="Benefit"
        value={null}
        onChange={handleBenefitSelectionChange}
        fetchItems={fetchAllBenefits}
        displayField="benefitName"
        columns={benefitLookupColumns}
        required
        multiple={false}
      />
    </div>
  );

  // Benefit edit form fields
  const benefitEditFormFields = useMemo(() => (benefit: Benefit) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <LookupField<Benefit>
        label="Benefit"
        value={benefit}
        onChange={handleBenefitSelectionChange}
        fetchItems={fetchAllBenefits}
        displayField="benefitName"
        columns={benefitLookupColumns}
        required
        multiple={false}
      />
    </div>
  ), [handleBenefitSelectionChange, fetchAllBenefits, benefitLookupColumns]);

  // User create form fields
  const userCreateFormFields = useMemo(() => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <LookupField<SystemUser>
        label="System User"
        value={selectedUsers}
        onChange={handleUserSelectionChange}
        fetchItems={fetchAllSystemUsers}
        displayField="fullName"
        columns={systemUserLookupColumns}
        required
        multiple={true}
        error={userSelectionError} // Truyền lỗi duplicate user vào LookupField
      />
      <Field label="Ratio" required>
        <Input
          type="number"
          step="0.1"
          value={formData.ratio?.toString() || '1.0'}
          onChange={handleRatioChange}
        />
      </Field>
      <Field label="Cases" required>
        <Input
          type="number"
          step="1"
          value={formData.cases?.toString() || '0'}
          onChange={handleCasesChange}
        />
      </Field>
    </div>
  ), [selectedUsers, handleUserSelectionChange, fetchAllSystemUsers, systemUserLookupColumns, formData.ratio, formData.cases, handleRatioChange, handleCasesChange, userSelectionError]);

  // User edit form fields
  const userEditFormFields = useMemo(() => (user: User) => {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <LookupField<SystemUser>
          label="System User"
          value={null} // Sẽ được load từ API
          onChange={handleSystemUserSelectionChange}
          fetchItems={fetchAllSystemUsers}
          displayField="fullName"
          columns={systemUserLookupColumns}
          required
          multiple={false}
        />
        <Field label="Ratio" required>
          <Input
            type="number"
            step="0.1"
            value={formData.ratio?.toString() || user.ratio?.toString() || '0'}
            onChange={handleRatioChange}
          />
        </Field>
      </div>
    );
  }, [handleSystemUserSelectionChange, fetchAllSystemUsers, systemUserLookupColumns, formData.ratio, handleRatioChange]);

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '400px' }}>
        <Spinner size="large" label="Loading group..." />
      </div>
    );
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: '#f8f8f8' }}>
      {/* Header */}
      <div style={{ 
        padding: '8px 20px',
        backgroundColor: '#fff',
        borderBottom: '1px solid #e1e1e1',
        display: 'flex',
        alignItems: 'center',
        gap: '12px'
      }}>
        <Button
          appearance="subtle"
          icon={<ArrowLeftRegular />}
          onClick={() => navigate('/')}
        >
          Back to List
        </Button>
        <Button
          appearance="primary"
          icon={<SaveRegular />}
          onClick={handleSave}
          disabled={saving}
        >
          {saving ? 'Saving...' : 'Save'}
        </Button>
        <Button
          appearance="secondary"
          icon={<SaveRegular />}
          onClick={handleSaveAndClose}
          disabled={saving}
        >
          Save & Close
        </Button>
        {!isNewGroup && (
          <Button
            appearance="subtle"
            icon={<DeleteRegular />}
            onClick={handleDelete}
            disabled={saving}
          >
            Delete
          </Button>
        )}
      </div>

      {/* Title */}
      <div style={{ 
        padding: '16px 20px',
        backgroundColor: '#fff',
        borderBottom: '1px solid #e1e1e1',
        marginBottom: '1px'
      }}>
        <h1 style={{ 
          margin: 0,
          fontSize: '24px',
          fontWeight: '600'
        }}>{isNewGroup ? 'Create New Group' : 'Edit Group'}</h1>
      </div>

      {/* Messages */}
      <div style={{ padding: '0 20px' }}>
        {error && (
          <MessageBar intent="error" style={{ marginBottom: '16px' }}>
            {error}
          </MessageBar>
        )}

        {success && (
          <MessageBar intent="success" style={{ marginBottom: '16px' }}>
            {success}
          </MessageBar>
        )}
      </div>

      {/* Content */}
      <div style={{ 
        flex: 1,
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        gap: '24px',
        overflow: 'auto'
      }}>
        {/* Form Fields */}
        <div style={{ 
          backgroundColor: '#fff',
          padding: '20px',
          borderRadius: '2px',
          boxShadow: '0 1.6px 3.6px 0 rgba(0,0,0,0.132), 0 0.3px 0.9px 0 rgba(0,0,0,0.108)'
        }}>
          <div style={{ maxWidth: '400px' }}>
            <Field label="Group Name" required>
              <Input
                value={group.groupName || ''}
                onChange={(e, data) => {
                  const value = data?.value ?? e.target?.value ?? '';
                  handleFieldChange('groupName', value);
                }}
                placeholder="Enter group name"
              />
            </Field>
            <Field label="Assignment Priority" required style={{ marginTop: '16px' }}>
              <Input
                type="number"
                value={group.assignmentPriority?.toString() || '0'}
                onChange={(e, data) => {
                  const value = data?.value ?? e.target?.value ?? '0';
                  handleFieldChange('assignmentPriority', parseInt(value) || 0);
                }}
                placeholder="Enter priority"
              />
            </Field>
          </div>
        </div>

        {/* Subgrids */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
          {/* Benefits Subgrid */}
          <div style={{ 
            backgroundColor: '#fff',
            borderRadius: '2px',
            boxShadow: '0 1.6px 3.6px 0 rgba(0,0,0,0.132), 0 0.3px 0.9px 0 rgba(0,0,0,0.108)'
          }}>
            <Subgrid
              title="Benefits"
              groupId={isNewGroup ? 'new' : id!}
              columns={benefitGridColumns}
              apiServiceFunctions={benefitApiServiceFunctions}
              createFormFields={benefitCreateFormFields}
              editFormFields={benefitEditFormFields}
            />
          </div>

          {/* Users Subgrid */}
          <div style={{ 
            backgroundColor: '#fff',
            borderRadius: '2px',
            boxShadow: '0 1.6px 3.6px 0 rgba(0,0,0,0.132), 0 0.3px 0.9px 0 rgba(0,0,0,0.108)'
          }}>
            <Subgrid
              key={`users-${refreshUsersSubgrid}`}
              title="Users"
              groupId={isNewGroup ? 'new' : id!}
              columns={userGridColumns}
              apiServiceFunctions={userApiServiceFunctions}
              createFormFields={userCreateFormFields}
              editFormFields={userEditFormFields}
              onDataChange={handleUsersDataChange}
              getCreateData={() => {
                // Return the selected users with default ratio and cases
                const usersToCreate = selectedUsers.map(systemUser => ({
                  groupId: isNewGroup ? 'new' : id!,
                  systemUserId: systemUser.id,
                  fullName: systemUser.fullName,
                  userCode: systemUser.userCode,
                  ratio: formData.ratio || 1.0,
                  cases: formData.cases || 0,
                }));
                
                // Nếu có nhiều users, return mảng để Subgrid xử lý từng user một
                // Điều này sẽ cho phép hiển thị lỗi đúng cách
                if (usersToCreate.length > 1) {
                  return usersToCreate; // Return mảng thay vì null
                }
                
                return usersToCreate[0] || {};
              }}
              onOpenCreateDialog={resetSelectedUsers} // Pass the reset function
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default React.memo(GroupFormPage); 