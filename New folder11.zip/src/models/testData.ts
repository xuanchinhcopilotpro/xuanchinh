import { Group, Benefit, User, SystemUser } from './types';

// Test data for Groups
export const testGroups: Group[] = [
  {
    id: 1,
    groupName: 'Test Group 1',
    assignmentPriority: 1,
    createdOn: '2024-01-01T00:00:00Z',
  },
  {
    id: 2,
    groupName: 'Test Group 2',
    assignmentPriority: 2,
    createdOn: '2024-01-02T00:00:00Z',
  },
];

// Test data for Benefits
export const testBenefits: Benefit[] = [
  {
    id: 1,
    benefitName: 'Test Benefit 1',
    description: 'Test Description 1',
    groupId: 1,
  },
  {
    id: 2,
    benefitName: 'Test Benefit 2',
    description: 'Test Description 2',
    groupId: 1,
  },
];

// Test data for System Users
export const testSystemUsers: SystemUser[] = [
  {
    id: 1,
    fullName: 'Test User 1',
    userCode: 'TU001',
  },
  {
    id: 2,
    fullName: 'Test User 2',
    userCode: 'TU002',
  },
];

// Test data for Users
export const testUsers: User[] = [
  {
    id: 1,
    systemUserId: 1,
    fullName: 'Test User 1',
    userCode: 'TU001',
    ratio: 1.0,
    cases: 10,
    groupId: 1,
  },
  {
    id: 2,
    systemUserId: 2,
    fullName: 'Test User 2',
    userCode: 'TU002',
    ratio: 1.5,
    cases: 15,
    groupId: 1,
  },
];
