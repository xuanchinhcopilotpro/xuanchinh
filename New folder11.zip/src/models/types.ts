// src/models/types.ts
export interface Group {
  id: string | number;
  groupName: string;
  assignmentPriority: number;
  createdOn: string; // ISO date string
}

export interface Benefit {
  id: string | number;
  benefitName: string;
  description: string;
  groupId: string | number; // Foreign key liên kết với Group
}

export interface SystemUser {
  id: string | number;
  fullName: string;
  userCode: string;
}

export interface User {
  id: string | number;
  systemUserId: string | number; // Reference to SystemUser
  fullName: string; // From SystemUser
  userCode: string; // From SystemUser
  ratio: number;
  cases: number;
  groupId: string | number; // Foreign key liên kết với Group
}

// API Response types
export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
}

export interface ApiError {
  message: string;
  status: number;
} 