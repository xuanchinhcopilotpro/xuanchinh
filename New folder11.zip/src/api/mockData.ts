import { Group, SystemUser, Benefit, User } from '../models/types';

// Mock data cho Groups - chỉ dùng cho development/testing
export const mockGroups: Group[] = [
  {
    id: 1,
    groupName: 'Nhóm Kinh Doanh',
    assignmentPriority: 1,
    createdOn: '2024-02-01T08:00:00Z',
  },
  {
    id: 2,
    groupName: 'Nhóm Kỹ Thuật',
    assignmentPriority: 2,
    createdOn: '2024-02-02T09:30:00Z',
  },
  {
    id: 3,
    groupName: 'Nhóm Hỗ Trợ',
    assignmentPriority: 3,
    createdOn: '2024-02-03T10:15:00Z',
  },
];

// Mock data cho SystemUsers - chỉ dùng cho development/testing
export const mockSystemUsers: SystemUser[] = [
  {
    id: 1,
    fullName: 'Nguyễn Văn A',
    userCode: 'NV001',
  },
  {
    id: 2,
    fullName: 'Trần Thị B',
    userCode: 'NV002',
  },
  {
    id: 3,
    fullName: 'Lê Văn C',
    userCode: 'NV003',
  },
  {
    id: 4,
    fullName: 'Phạm Thị D',
    userCode: 'NV004',
  },
  {
    id: 5,
    fullName: 'Hoàng Văn E',
    userCode: 'NV005',
  },
];

// Mock data cho Benefits - chỉ dùng cho development/testing
export const mockBenefits: Benefit[] = [
  {
    id: 1,
    benefitName: 'Bảo hiểm y tế',
    description: 'Bảo hiểm y tế cho nhân viên',
    groupId: 1,
  },
  {
    id: 2,
    benefitName: 'Bảo hiểm xã hội',
    description: 'Bảo hiểm xã hội bắt buộc',
    groupId: 1,
  },
  {
    id: 3,
    benefitName: 'Thưởng tháng 13',
    description: 'Thưởng cuối năm',
    groupId: 2,
  },
  {
    id: 4,
    benefitName: 'Bảo hiểm nhân thọ',
    description: 'Bảo hiểm nhân thọ tự nguyện',
    groupId: 3,
  },
  {
    id: 5,
    benefitName: 'Du lịch hàng năm',
    description: 'Chuyến du lịch hàng năm cho nhân viên',
    groupId: 3,
  },
];

// Mock data cho Users - chỉ dùng cho development/testing
export const mockUsers: User[] = [
  {
    id: 1,
    systemUserId: 1,
    fullName: 'Nguyễn Văn A',
    userCode: 'NV001',
    ratio: 1.0,
    cases: 10,
    groupId: 1,
  },
  {
    id: 2,
    systemUserId: 2,
    fullName: 'Trần Thị B',
    userCode: 'NV002',
    ratio: 1.2,
    cases: 15,
    groupId: 1,
  },
  {
    id: 3,
    systemUserId: 3,
    fullName: 'Lê Văn C',
    userCode: 'NV003',
    ratio: 0.8,
    cases: 8,
    groupId: 2,
  },
];