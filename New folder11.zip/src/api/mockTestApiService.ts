import { Group, Benefit, User } from '../models/types';
import { testGroups, testBenefits, testUsers } from '../models/testData';

// Mock API functions for testing
export const mockTestGroupApi = {
  getAll: jest.fn().mockResolvedValue(testGroups),
  getById: jest.fn().mockImplementation((id: string | number) => {
    const group = testGroups.find(g => g.id === id);
    return group ? Promise.resolve(group) : Promise.reject(new Error('Group not found'));
  }),
  create: jest.fn().mockImplementation((group: Omit<Group, 'id'>) => {
    const newGroup = { ...group, id: Date.now() };
    return Promise.resolve(newGroup);
  }),
  update: jest.fn().mockImplementation((id: string | number, group: Partial<Group>) => {
    const existingGroup = testGroups.find(g => g.id === id);
    if (!existingGroup) {
      return Promise.reject(new Error('Group not found'));
    }
    const updatedGroup = { ...existingGroup, ...group };
    return Promise.resolve(updatedGroup);
  }),
  delete: jest.fn().mockResolvedValue(undefined),
};

export const mockTestBenefitApi = {
  getByGroupId: jest.fn().mockImplementation((groupId: string | number) => {
    const benefits = testBenefits.filter(b => b.groupId === groupId);
    return Promise.resolve(benefits);
  }),
  create: jest.fn().mockImplementation((benefit: Omit<Benefit, 'id'>) => {
    const newBenefit = { ...benefit, id: Date.now() };
    return Promise.resolve(newBenefit);
  }),
  update: jest.fn().mockImplementation((id: string | number, benefit: Partial<Benefit>) => {
    const existingBenefit = testBenefits.find(b => b.id === id);
    if (!existingBenefit) {
      return Promise.reject(new Error('Benefit not found'));
    }
    const updatedBenefit = { ...existingBenefit, ...benefit };
    return Promise.resolve(updatedBenefit);
  }),
  delete: jest.fn().mockResolvedValue(undefined),
};

export const mockTestUserApi = {
  getByGroupId: jest.fn().mockImplementation((groupId: string | number) => {
    const users = testUsers.filter(u => u.groupId === groupId);
    return Promise.resolve(users);
  }),
  create: jest.fn().mockImplementation((user: Omit<User, 'id'>) => {
    const newUser = { ...user, id: Date.now() };
    return Promise.resolve(newUser);
  }),
  update: jest.fn().mockImplementation((id: string | number, user: Partial<User>) => {
    const existingUser = testUsers.find(u => u.id === id);
    if (!existingUser) {
      return Promise.reject(new Error('User not found'));
    }
    const updatedUser = { ...existingUser, ...user };
    return Promise.resolve(updatedUser);
  }),
  delete: jest.fn().mockResolvedValue(undefined),
};
