import { Group, Benefit, User, SystemUser, ApiError } from '../models/types.ts';

// Cấu hình API
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:3001/api';
const D365_API_BASE_URL = process.env.REACT_APP_D365_API_BASE_URL || 'https://your-org.crm.dynamics.com/api/data/v9.2';

// Token configuration - có thể thay đổi token ở đây hoặc qua environment variable
const getToken = (): string => {
  // Ưu tiên lấy từ environment variable
  const envToken = process.env.REACT_APP_D365_TOKEN;
  if (envToken) {
    return envToken;
  }
  
  // Hoặc lấy từ localStorage (cho development)
  const storedToken = localStorage.getItem('d365_token');
  if (storedToken) {
    return storedToken;
  }
  
  // Token mặc định - thay đổi token ở đây
  return 'YOUR_D365_TOKEN_HERE';
};

// Helper function để xử lý Dynamics 365 response
const handleD365Response = async <T>(response: Response): Promise<T> => {
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const apiError: ApiError = {
      message: errorData.error?.message || `HTTP error! status: ${response.status}`,
      status: response.status,
    };
    throw apiError;
  }
  
  // Dynamics 365 trả về data trực tiếp, không có wrapper
  const data = await response.json();
  return data.value || data; // D365 thường wrap data trong 'value' property
};

// Helper function để xử lý External API response
const handleExternalResponse = async <T>(response: Response): Promise<T> => {
  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const apiError: ApiError = {
      message: errorData.message || `HTTP error! status: ${response.status}`,
      status: response.status,
    };
    throw apiError;
  }
  
  const data = await response.json();
  return data.data || data; // External API thường wrap data trong 'data' property
};

// Helper function để tạo request options cho D365
const createD365RequestOptions = (method: string, body?: any): RequestInit => {
  const token = getToken();
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'OData-MaxVersion': '4.0',
      'OData-Version': '4.0',
      'Accept': 'application/json',
    },
  };
  
  if (body) {
    options.body = JSON.stringify(body);
  }
  
  return options;
};

// Helper function để tạo request options cho External API
const createExternalRequestOptions = (method: string, body?: any): RequestInit => {
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    },
  };
  
  if (body) {
    options.body = JSON.stringify(body);
  }
  
  return options;
};

// ==================== D365 APIs (CHO LOOKUP FIELDS) ====================

// SystemUser API functions - D365
export const systemUserApi = {
  // Lấy danh sách tất cả system users từ D365
  getAll: async (): Promise<SystemUser[]> => {
    const options = createD365RequestOptions('GET');
    const response = await fetch(`${D365_API_BASE_URL}/systemusers?$select=systemuserid,fullname,employeeid`, options);
    return handleD365Response<SystemUser[]>(response);
  },

  // Lấy chi tiết một system user theo ID từ D365
  getById: async (id: string | number): Promise<SystemUser> => {
    const options = createD365RequestOptions('GET');
    const response = await fetch(`${D365_API_BASE_URL}/systemusers(${id})?$select=systemuserid,fullname,employeeid`, options);
    return handleD365Response<SystemUser>(response);
  },
};

// Benefit lookup API functions - D365
export const benefitLookupApi = {
  // Lấy danh sách tất cả benefits từ D365 (cho lookup)
  getAll: async (): Promise<Benefit[]> => {
    const options = createD365RequestOptions('GET');
    const response = await fetch(`${D365_API_BASE_URL}/benefits?$top=1000`, options);
    return handleD365Response<Benefit[]>(response);
  },
};

// ==================== EXTERNAL APIs (CHO SUBGRID DATA) ====================

// Group API functions - External API
export const groupApi = {
  // Lấy danh sách tất cả groups
  getAll: async (): Promise<Group[]> => {
    const options = createExternalRequestOptions('GET');
    const response = await fetch(`${API_BASE_URL}/groups`, options);
    return handleExternalResponse<Group[]>(response);
  },

  // Lấy chi tiết một group theo ID
  getById: async (id: string | number): Promise<Group> => {
    const options = createExternalRequestOptions('GET');
    const response = await fetch(`${API_BASE_URL}/groups/${id}`, options);
    return handleExternalResponse<Group>(response);
  },

  // Tạo mới group
  create: async (group: Omit<Group, 'id'>): Promise<Group> => {
    const options = createExternalRequestOptions('POST', group);
    const response = await fetch(`${API_BASE_URL}/groups`, options);
    return handleExternalResponse<Group>(response);
  },

  // Cập nhật group
  update: async (id: string | number, group: Partial<Group>): Promise<Group> => {
    const options = createExternalRequestOptions('PUT', group);
    const response = await fetch(`${API_BASE_URL}/groups/${id}`, options);
    return handleExternalResponse<Group>(response);
  },

  // Xóa group
  delete: async (id: string | number): Promise<void> => {
    const options = createExternalRequestOptions('DELETE');
    const response = await fetch(`${API_BASE_URL}/groups/${id}`, options);
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const apiError: ApiError = {
        message: errorData.message || `HTTP error! status: ${response.status}`,
        status: response.status,
      };
      throw apiError;
    }
  },
};

// Benefit API functions - External API (cho subgrid)
export const benefitApi = {
  // Lấy danh sách benefits của một group
  getByGroupId: async (groupId: string | number): Promise<Benefit[]> => {
    const options = createExternalRequestOptions('GET');
    const response = await fetch(`${API_BASE_URL}/groups/${groupId}/benefits`, options);
    return handleExternalResponse<Benefit[]>(response);
  },

  // Tạo mới benefit
  create: async (benefit: Omit<Benefit, 'id'>): Promise<Benefit> => {
    const options = createExternalRequestOptions('POST', benefit);
    const response = await fetch(`${API_BASE_URL}/benefits`, options);
    return handleExternalResponse<Benefit>(response);
  },

  // Cập nhật benefit
  update: async (id: string | number, benefit: Partial<Benefit>): Promise<Benefit> => {
    const options = createExternalRequestOptions('PUT', benefit);
    const response = await fetch(`${API_BASE_URL}/benefits/${id}`, options);
    return handleExternalResponse<Benefit>(response);
  },

  // Xóa benefit
  delete: async (id: string | number): Promise<void> => {
    const options = createExternalRequestOptions('DELETE');
    const response = await fetch(`${API_BASE_URL}/benefits/${id}`, options);
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const apiError: ApiError = {
        message: errorData.message || `HTTP error! status: ${response.status}`,
        status: response.status,
      };
      throw apiError;
    }
  },
};

// User API functions - External API (cho subgrid)
export const userApi = {
  // Lấy danh sách users của một group
  getByGroupId: async (groupId: string | number): Promise<User[]> => {
    const options = createExternalRequestOptions('GET');
    const response = await fetch(`${API_BASE_URL}/groups/${groupId}/users`, options);
    return handleExternalResponse<User[]>(response);
  },

  // Tạo mới user
  create: async (user: Omit<User, 'id'>): Promise<User> => {
    const options = createExternalRequestOptions('POST', user);
    const response = await fetch(`${API_BASE_URL}/users`, options);
    return handleExternalResponse<User>(response);
  },

  // Cập nhật user
  update: async (id: string | number, user: Partial<User>): Promise<User> => {
    const options = createExternalRequestOptions('PUT', user);
    const response = await fetch(`${API_BASE_URL}/users/${id}`, options);
    return handleExternalResponse<User>(response);
  },

  // Xóa user
  delete: async (id: string | number): Promise<void> => {
    const options = createExternalRequestOptions('DELETE');
    const response = await fetch(`${API_BASE_URL}/users/${id}`, options);
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const apiError: ApiError = {
        message: errorData.message || `HTTP error! status: ${response.status}`,
        status: response.status,
      };
      throw apiError;
    }
  },
};

// Export default object để tương thích với code cũ
const apiClient = {
  get: async (url: string) => {
    const options = createExternalRequestOptions('GET');
    const response = await fetch(`${API_BASE_URL}${url}`, options);
    return handleExternalResponse(response);
  },
  post: async (url: string, data: any) => {
    const options = createExternalRequestOptions('POST', data);
    const response = await fetch(`${API_BASE_URL}${url}`, options);
    return handleExternalResponse(response);
  },
  put: async (url: string, data: any) => {
    const options = createExternalRequestOptions('PUT', data);
    const response = await fetch(`${API_BASE_URL}${url}`, options);
    return handleExternalResponse(response);
  },
  patch: async (url: string, data: any) => {
    const options = createExternalRequestOptions('PATCH', data);
    const response = await fetch(`${API_BASE_URL}${url}`, options);
    return handleExternalResponse(response);
  },
  delete: async (url: string) => {
    const options = createExternalRequestOptions('DELETE');
    const response = await fetch(`${API_BASE_URL}${url}`, options);
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const apiError: ApiError = {
        message: errorData.message || `HTTP error! status: ${response.status}`,
        status: response.status,
      };
      throw apiError;
    }
  },
};

export default apiClient; 